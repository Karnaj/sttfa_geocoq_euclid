(*proposition__04 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong A) B) a) b) ==> (((((cong A) C) a) c) ==> (((((((congA B) A) C) b) a) c) ==> ((mat_and ((((cong B) C) b) c)) ((mat_and ((((((congA A) B) C) a) b) c)) ((((((congA A) C) B) a) c) b)))))))))))`*)
let proposition__04 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(a : mat_Point)` 
    (GEN `(b : mat_Point)` 
     (GEN `(c : mat_Point)` 
      (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
       (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
        (DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
         (MP  
          (DISCH `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
             (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))))))` 
              (MP  
               (MP  
                (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))))))) ==> (return : bool)))` 
                  (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))))))))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(U : mat_Point)` 
                   (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))))` 
                    (MP  
                     (MP  
                      (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool)))` 
                        (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))))))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(V : mat_Point)` 
                         (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))` 
                          (MP  
                           (MP  
                            (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool)))` 
                              (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(u : mat_Point)` 
                               (DISCH `ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool)))` 
                                    (SPEC `\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(v : mat_Point)` 
                                     (DISCH `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                         (SPEC `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))` 
                                          (SPEC `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                           (DISCH `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                               (SPEC `(mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                (SPEC `((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                 (DISCH `(mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                     (SPEC `(mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                      (SPEC `((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                       (DISCH `(mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                           (SPEC `(mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                            (SPEC `((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                             (DISCH `(mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                 (SPEC `(mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                  (SPEC `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                   (DISCH `(mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (a : mat_Point)) (c : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (a : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (b : mat_Point)) (c : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (V : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (a : mat_Point)) (a : mat_Point)) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `(eq (a : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (c : mat_Point)) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `(eq (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (b : mat_Point)) (b : mat_Point)) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `(eq (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (a : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (c : mat_Point)) (a : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (c : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (U0 : mat_Point)) (c : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (V0 : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))))))))))) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (x : mat_Point)) (c : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (V0 : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))))))))) ==> (ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (U0 : mat_Point)) (c : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (V0 : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (U0 : mat_Point)) (c : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (V0 : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (x : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))))))) ==> (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (V0 : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (V0 : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))))) ==> (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (a : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))) ==> (ex (\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (a : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v0 : mat_Point. ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (a : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (c : mat_Point)) (a : mat_Point)) (a : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (c : mat_Point)) (a : mat_Point)) (a : mat_Point))) ((mat_and (((out (c : mat_Point)) (b : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (c : mat_Point)) (b : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (c : mat_Point)) (a : mat_Point)) (a : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (c : mat_Point)) (a : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (c : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (c : mat_Point)) (b : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (b : mat_Point))) (((betS (c : mat_Point)) (b : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (b : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (a : mat_Point)) (a : mat_Point))) (((betS (c : mat_Point)) (a : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (a : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (a : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (a : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (a : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (a : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (a : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (a : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (a : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (a : mat_Point)) (a : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (c : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((out (b : mat_Point)) (c : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (c : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (b : mat_Point)) (c : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (a : mat_Point)) (a : mat_Point))) (((betS (b : mat_Point)) (a : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (a : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (a : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (a : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((out (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((neq (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (V : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (V : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (V : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (V : mat_Point))))) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ g : mat_Point. ((mat_and (((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (c : mat_Point))) ((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (V : mat_Point))) ==> (return : bool))) ==> ((ex (\ g : mat_Point. ((mat_and (((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ g : mat_Point. ((mat_and (((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(g : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (g : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (c : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (g : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (v : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (V : mat_Point)) (C : mat_Point)) (v : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (C : mat_Point)) (v : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (v : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__differenceofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (v : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (g : mat_Point)) (v : mat_Point)) ==> ((((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point)) ==> (((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> (((neq (a : mat_Point)) (g : mat_Point)) ==> ((((out (a : mat_Point)) (g : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (g : mat_Point)) ==> (((((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((betS (a : mat_Point)) (v : mat_Point)) (c : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (a : mat_Point)) (v : mat_Point)) (c : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> (((neq (a : mat_Point)) (v : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((betS (a : mat_Point)) (v : mat_Point)) (c : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (v : mat_Point)) ==> ((((betS (a : mat_Point)) (x : mat_Point)) (c : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> (((neq (a : mat_Point)) (x : mat_Point)) ==> ((((out (a : mat_Point)) (x : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (x : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((betS (a : mat_Point)) (v : mat_Point)) (c : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ g0 : mat_Point. ((((betS (a : mat_Point)) (g0 : mat_Point)) (c : mat_Point)) ==> (((((cong (a : mat_Point)) (g0 : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> (((neq (a : mat_Point)) (g0 : mat_Point)) ==> ((((out (a : mat_Point)) (g0 : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (g0 : mat_Point)) ==> (((((cong (a : mat_Point)) (g0 : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((betS (a : mat_Point)) (v : mat_Point)) (c : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (v : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (v : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (v : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (a : mat_Point)) (v : mat_Point)) (c : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (g : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (g : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (g : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (c : mat_Point)) (g : mat_Point))) (((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (c : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (g : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (g : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (g : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (g : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (g : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (g : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ g : mat_Point. ((mat_and (((betS (a : mat_Point)) (g : mat_Point)) (c : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (V : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (V : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (V : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (V : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (V : mat_Point)) (A : mat_Point)) (V : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (C : mat_Point)) (V : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (V : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (C : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (c : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (c : mat_Point)) ==> (((eq (c : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (a : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (c : mat_Point)) ==> (((eq (c : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (c : mat_Point)) ==> (((eq (c : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (v : mat_Point))) ==> (((neq (v : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (v : mat_Point))) ==> (((neq (v : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (v : mat_Point)) ==> (((eq (v : mat_Point)) (v : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (v : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> ((((out (a : mat_Point)) (x : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (x : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> ((((out (a : mat_Point)) (x : mat_Point)) (x : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (x : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ c0 : mat_Point. (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c0 : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (c0 : mat_Point)) ==> ((((out (a : mat_Point)) (c0 : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (c0 : mat_Point))) ==> (((neq (c0 : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (c0 : mat_Point))) ==> (((neq (c0 : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (c0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (c0 : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (c0 : mat_Point)) ==> (((eq (c0 : mat_Point)) (c0 : mat_Point)) ==> ((((out (a : mat_Point)) (c0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c0 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (b : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (v : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (a : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (v : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (b : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (v : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (v : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (v : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (V : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((out (A : mat_Point)) (V : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (V : mat_Point))) ==> (((neq (V : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (V : mat_Point))) ==> (((neq (V : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (V : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v : mat_Point)) ==> ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. (((((((congA (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((out (A : mat_Point)) (C0 : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (C0 : mat_Point))) ==> (((neq (C0 : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C0 : mat_Point))) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((((cong (B : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (v : mat_Point)) ==> ((((cong (B : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (v : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (V : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (B : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )))))))))
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (a : mat_Point)) (c : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (a : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (b : mat_Point)) (c : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (c : mat_Point)) ==> (((eq (c : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (a : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (c : mat_Point)) ==> (((eq (c : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (c : mat_Point)) ==> (((eq (c : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (v : mat_Point))) ==> (((neq (v : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (v : mat_Point))) ==> (((neq (v : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (v : mat_Point)) ==> (((eq (v : mat_Point)) (v : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (v : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> ((((out (a : mat_Point)) (x : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (x : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> ((((out (a : mat_Point)) (x : mat_Point)) (x : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ c0 : mat_Point. (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c0 : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (c0 : mat_Point)) ==> ((((out (a : mat_Point)) (c0 : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (c0 : mat_Point))) ==> (((neq (c0 : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (c0 : mat_Point))) ==> (((neq (c0 : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (c0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (a : mat_Point)) (c0 : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((neq (a : mat_Point)) (c0 : mat_Point)) ==> (((eq (c0 : mat_Point)) (c0 : mat_Point)) ==> ((((out (a : mat_Point)) (c0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (b : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (v : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (a : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (v : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (b : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (v : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (v : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (v : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (V : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (v : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((((congA (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((out (A : mat_Point)) (V : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (V : mat_Point))) ==> (((neq (V : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (V : mat_Point))) ==> (((neq (V : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (V : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. (((((((congA (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((out (A : mat_Point)) (C0 : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (C0 : mat_Point))) ==> (((neq (C0 : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C0 : mat_Point))) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((((cong (B : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (v : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (V : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (B : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (v : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (a : mat_Point)) (c : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (a : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (b : mat_Point)) (c : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (c : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((neq (a : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((neq (a : mat_Point)) (c : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (V : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((neq (a : mat_Point)) (c : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (V : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (V : mat_Point))) ==> (((neq (V : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (V : mat_Point))) ==> (((neq (V : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> (mat_not ((eq (a : mat_Point)) (c : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (V : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((neq (a : mat_Point)) (c : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. (((((cong (A : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (C0 : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (C0 : mat_Point))) ==> (((neq (C0 : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C0 : mat_Point))) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((neq (a : mat_Point)) (c : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (V : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (B : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (a : mat_Point)) (c : mat_Point))`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (V : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (V : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (V : mat_Point))) ==> (((neq (V : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (V : mat_Point))) ==> (((neq (V : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (V : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (v : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. (((((cong (A : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (C0 : mat_Point)) (V : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (C0 : mat_Point))) ==> (((neq (C0 : mat_Point)) (A : mat_Point)) ==> ((mat_not ((eq (B : mat_Point)) (C0 : mat_Point))) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (v : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (V : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (B : mat_Point)) (V : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (V : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (V : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ g : mat_Point. ((mat_and (((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (v : mat_Point))) ((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ g : mat_Point. ((mat_and (((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ g : mat_Point. ((mat_and (((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(g : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (g : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (v : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (v : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (c : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (V : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__interior5
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (V : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__differenceofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (g : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (c : mat_Point)) ==> (((betS (a : mat_Point)) (c : mat_Point)) (v : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (a : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (g : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (c : mat_Point)) ==> (((betS (a : mat_Point)) (c : mat_Point)) (v : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (g : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (g : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (c : mat_Point)) ==> (((betS (a : mat_Point)) (c : mat_Point)) (v : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (g : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (g : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (g : mat_Point)) ==> ((((out (a : mat_Point)) (g : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (g : mat_Point))) ==> (((neq (g : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (g : mat_Point))) ==> (((neq (g : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (g : mat_Point)) ==> (((((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (g : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (g : mat_Point)) ==> (((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (g : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> ((((out (a : mat_Point)) (x : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (g : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (x : mat_Point)) ==> (((betS (a : mat_Point)) (x : mat_Point)) (v : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ c0 : mat_Point. (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c0 : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (c0 : mat_Point)) ==> ((((out (a : mat_Point)) (c0 : mat_Point)) (v : mat_Point)) ==> ((mat_not ((eq (a : mat_Point)) (c0 : mat_Point))) ==> (((neq (c0 : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (c0 : mat_Point))) ==> (((neq (c0 : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (c0 : mat_Point)) ==> (((((cong (a : mat_Point)) (c0 : mat_Point)) (a : mat_Point)) (g : mat_Point)) ==> ((((out (a : mat_Point)) (v : mat_Point)) (c0 : mat_Point)) ==> (((betS (a : mat_Point)) (c0 : mat_Point)) (v : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (b : mat_Point)) (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (g : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (a : mat_Point)) (g : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (g : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (b : mat_Point)) (g : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (g : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (v : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (a : mat_Point)) (c : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (a : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (b : mat_Point)) (c : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (v : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (v : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (v : mat_Point)) (g : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (a : mat_Point)) (g : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (g : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (g : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (v : mat_Point)) (g : mat_Point))) (((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (v : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (v : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (g : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (g : mat_Point)) (v : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((neq (a : mat_Point)) (v : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((neq (a : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (g : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (g : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((neq (a : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (g : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (g : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((neq (a : mat_Point)) (v : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (g : mat_Point)) (v : mat_Point))) ((mat_and ((neq (a : mat_Point)) (g : mat_Point))) ((neq (a : mat_Point)) (v : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(g : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ g : mat_Point. ((mat_and (((betS (a : mat_Point)) (g : mat_Point)) (v : mat_Point))) ((((cong (a : mat_Point)) (g : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (V : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (C : mat_Point)) (V : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (V : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (V : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (V : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (V : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (V : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray1
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (U : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (U : mat_Point))))) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ w : mat_Point. ((mat_and (((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point))) ==> (return : bool))) ==> ((ex (\ w : mat_Point. ((mat_and (((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ w : mat_Point. ((mat_and (((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(w : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (w : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (b : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (w : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (w : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (v : mat_Point)) (b : mat_Point))) ((((cong (V : mat_Point)) (B : mat_Point)) (b : mat_Point)) (v : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (V : mat_Point)) (B : mat_Point)) (v : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (B : mat_Point)) (u : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__differenceofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (w : mat_Point)) (u : mat_Point)) ==> ((((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (w : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (w : mat_Point)) ==> (((((cong (a : mat_Point)) (w : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> ((((betS (a : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ w0 : mat_Point. ((((betS (a : mat_Point)) (w0 : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (w0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (w0 : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (w0 : mat_Point)) ==> (((((cong (a : mat_Point)) (w0 : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (w : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (w : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (w : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (w : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (w : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (w : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (w : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (w : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (w : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (w : mat_Point))) ((neq (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (w : mat_Point))) ((neq (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (w : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (w : mat_Point))) ((neq (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (w : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (w : mat_Point))) ((neq (a : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (w : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (w : mat_Point))) ((neq (a : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(w : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ w : mat_Point. ((mat_and (((betS (a : mat_Point)) (w : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (w : mat_Point)) (A : mat_Point)) (U : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (U : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (U : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (U : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (U : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (b : mat_Point)) (u : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> (((neq (b : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((nCol (u : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (u : mat_Point)) ==> (((neq (a : mat_Point)) (u : mat_Point)) ==> (((neq (u : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (u : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((mat_or (((betS (a : mat_Point)) (u : mat_Point)) (u : mat_Point))) ((mat_or ((eq (u : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (u : mat_Point)) (u : mat_Point)))) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (u : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (x : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((nCol (x : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (x : mat_Point)) (u : mat_Point)) ==> (((neq (a : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (x : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (x : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((mat_or (((betS (a : mat_Point)) (u : mat_Point)) (x : mat_Point))) ((mat_or ((eq (x : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (x : mat_Point)) (u : mat_Point)))) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ b0 : mat_Point. (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b0 : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((nCol (b0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (a : mat_Point)) (b0 : mat_Point)) (u : mat_Point)) ==> (((neq (a : mat_Point)) (b0 : mat_Point)) ==> (((neq (b0 : mat_Point)) (a : mat_Point)) ==> ((mat_not ((eq (b0 : mat_Point)) (c : mat_Point))) ==> (((neq (c : mat_Point)) (b0 : mat_Point)) ==> (((((cong (a : mat_Point)) (b0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (a : mat_Point)) (b0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b0 : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b0 : mat_Point))) ((mat_or ((eq (b0 : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b0 : mat_Point)) (u : mat_Point)))) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (b0 : mat_Point)) (v : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (u : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (u : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (u : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (u : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_or (((betS (a : mat_Point)) (u : mat_Point)) (u : mat_Point))) ((mat_or ((eq (u : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (u : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)) ==> ((((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (U : mat_Point))) ==> ((mat_not ((eq (U : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (U : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((((((congA (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (U : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (x : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (U : mat_Point)) ==> ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> ((mat_not ((eq (B0 : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (B0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (u : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (u : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))))))))
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (b : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (b : mat_Point)) (c : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (b : mat_Point)) (u : mat_Point)) ==> mat_false) ==> ((eq (b : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((neq (b : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((eq (b : mat_Point)) (u : mat_Point))) ==> mat_false) ==> ((eq (b : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (u : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not ((eq (b : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (b : mat_Point)) (u : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((neq (b : mat_Point)) (u : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (b : mat_Point)) (u : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (b : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (u : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__partnotequalwhole
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (u : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (b : mat_Point)) (u : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (b : mat_Point)) (u : mat_Point)) ==> mat_false) ==> ((eq (b : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((neq (b : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((eq (b : mat_Point)) (u : mat_Point))) ==> mat_false) ==> ((eq (b : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (u : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not ((eq (b : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (b : mat_Point)) (u : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((neq (b : mat_Point)) (u : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (b : mat_Point)) (u : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and (mat_not (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ((mat_and (mat_not (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))) (mat_not (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)) ==> ((((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (U : mat_Point))) ==> ((mat_not ((eq (U : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (U : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (U : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (x : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (U : mat_Point)) ==> ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> ((mat_not ((eq (B0 : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)) ==> ((((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (U : mat_Point))) ==> ((mat_not ((eq (U : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (U : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (U : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (x : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (u : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (U : mat_Point)) ==> ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> ((mat_not ((eq (B0 : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (u : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)) ==> ((((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (U : mat_Point))) ==> ((mat_not ((eq (U : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (U : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (U : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (x : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (U : mat_Point)) ==> ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> ((mat_not ((eq (B0 : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> ((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))))))))
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)) ==> ((((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (U : mat_Point))) ==> ((mat_not ((eq (U : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (U : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (U : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (x : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (U : mat_Point)) ==> ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> ((mat_not ((eq (B0 : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> ((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))))))))
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)) ==> ((((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (U : mat_Point))) ==> ((mat_not ((eq (U : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (U : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (U : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (x : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (U : mat_Point)) ==> ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> ((mat_not ((eq (B0 : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__partnotequalwhole
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (a : mat_Point)) (u : mat_Point)) (b : mat_Point))) ((mat_or ((eq (b : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray1
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)) ==> ((((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (U : mat_Point))) ==> ((mat_not ((eq (U : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (U : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (U : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (x : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (U : mat_Point)) ==> ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> ((mat_not ((eq (B0 : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)) ==> ((((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (U : mat_Point))) ==> ((mat_not ((eq (U : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (U : mat_Point)) ==> (((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) ==> ((((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (U : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (x : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (U : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (U : mat_Point)) ==> ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> ((mat_not ((eq (B0 : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B0 : mat_Point)) ==> (((((cong (B0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (B0 : mat_Point)) ==> ((((cong (A : mat_Point)) (B0 : mat_Point)) (A : mat_Point)) (U : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)) ==> ((((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (U : mat_Point))) ==> ((mat_not ((eq (U : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (U : mat_Point)) ==> ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (U : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (x : mat_Point)) (U : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> ((mat_not ((eq (x : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((out (A : mat_Point)) (B0 : mat_Point)) (U : mat_Point)) ==> ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B0 : mat_Point))) ==> ((mat_not ((eq (B0 : mat_Point)) (C : mat_Point))) ==> (((neq (C : mat_Point)) (B0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (U : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (U : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (U : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (U : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (U : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (U : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)) ==> ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ f : mat_Point. ((mat_and (((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (u : mat_Point))) ((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ f : mat_Point. ((mat_and (((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ f : mat_Point. ((mat_and (((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(f : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (u : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (b : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (f : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (f : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__interior5
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (f : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (f : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) ==> (((((cong (a : mat_Point)) (f : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (b : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (x : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (x : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ f0 : mat_Point. ((((betS (a : mat_Point)) (f0 : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (f0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (f0 : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (f0 : mat_Point)) ==> (((((cong (a : mat_Point)) (f0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (f : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (u : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (f : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (f : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (f : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) ==> (((((cong (a : mat_Point)) (f : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (b : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (x : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (x : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ f0 : mat_Point. ((((betS (a : mat_Point)) (f0 : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (f0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (f0 : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (f0 : mat_Point)) ==> (((((cong (a : mat_Point)) (f0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (f : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (u : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (f : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__differenceofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (f : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (f : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) ==> (((((cong (a : mat_Point)) (f : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (b : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) ==> (((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (x : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (x : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> (((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ f0 : mat_Point. ((((betS (a : mat_Point)) (f0 : mat_Point)) (u : mat_Point)) ==> (((((cong (a : mat_Point)) (f0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((out (a : mat_Point)) (u : mat_Point)) (f0 : mat_Point)) ==> ((((out (a : mat_Point)) (b : mat_Point)) (f0 : mat_Point)) ==> (((((cong (a : mat_Point)) (f0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (u : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (f : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (u : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (f : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__layoffunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (u : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (u : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (f : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (u : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (u : mat_Point)) (f : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (f : mat_Point)) (u : mat_Point))) (((betS (a : mat_Point)) (u : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (f : mat_Point)) (u : mat_Point))) ((mat_and ((neq (a : mat_Point)) (f : mat_Point))) ((neq (a : mat_Point)) (u : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (f : mat_Point))) ((neq (a : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (f : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (f : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (f : mat_Point))) ((neq (a : mat_Point)) (u : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (u : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (f : mat_Point))) ((neq (a : mat_Point)) (u : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (f : mat_Point)) (u : mat_Point))) ((mat_and ((neq (a : mat_Point)) (f : mat_Point))) ((neq (a : mat_Point)) (u : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ f : mat_Point. ((mat_and (((betS (a : mat_Point)) (f : mat_Point)) (u : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (U : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (U : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (U : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (U : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (U : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (U : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray1
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> ((neq (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (b : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (b : mat_Point)) (a : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (b : mat_Point)) (c : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (a : mat_Point)) (c : mat_Point))) ==> ((neq (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (a : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (b : mat_Point)) (a : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (a : mat_Point)) (c : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))`
                                             ))))
                                       ) (ASSUME `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))`
                                       ))))
                                 ) (ASSUME `ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))`
                                 ))))
                           ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))`
                           ))))
                     ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))))`
                     ))))
               ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((out (A : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (a : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and (((out (a : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (U : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (a : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))))))))))`
               )))
            ) (ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
            ))
          ) (MP  
             (SPEC `(c : mat_Point)` 
              (SPEC `(a : mat_Point)` (SPEC `(b : mat_Point)` (nCol__notCol))
              )
             ) (MP  
                (SPEC `(c : mat_Point)` 
                 (SPEC `(a : mat_Point)` 
                  (SPEC `(b : mat_Point)` (nCol__not__Col)))
                ) (MP  
                   (SPEC `(c : mat_Point)` 
                    (SPEC `(a : mat_Point)` 
                     (SPEC `(b : mat_Point)` 
                      (SPEC `(C : mat_Point)` 
                       (SPEC `(A : mat_Point)` 
                        (SPEC `(B : mat_Point)` (lemma__equalanglesNC))))))
                   ) (ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                   )))))))))))))
 ;;


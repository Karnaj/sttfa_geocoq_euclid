(*proposition__42B :  |- `! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! J : mat_Point. (! K : mat_Point. (! R : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! e : mat_Point. ((((triangle a) b) c) ==> ((((midpoint b) e) c) ==> ((((nCol J) D) K) ==> ((((midpoint B) E) C) ==> (((((cong E) C) e) c) ==> ((((nCol R) E) C) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG X) E) C) Z)) ((mat_and ((((((((eF a) b) e) c) X) E) C) Z)) ((mat_and ((((((congA C) E) X) J) D) K)) ((((oS R) X) E) C))))))))))))))))))))))))`*)
let proposition__42B =

 GEN `(B : mat_Point)` 
 (GEN `(C : mat_Point)` 
  (GEN `(D : mat_Point)` 
   (GEN `(E : mat_Point)` 
    (GEN `(J : mat_Point)` 
     (GEN `(K : mat_Point)` 
      (GEN `(R : mat_Point)` 
       (GEN `(a : mat_Point)` 
        (GEN `(b : mat_Point)` 
         (GEN `(c : mat_Point)` 
          (GEN `(e : mat_Point)` 
           (DISCH `((triangle (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
            (DISCH `((midpoint (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
             (DISCH `((nCol (J : mat_Point)) (D : mat_Point)) (K : mat_Point)` 
              (DISCH `((midpoint (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
               (DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                (DISCH `((nCol (R : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                 (MP  
                  (DISCH `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                   (MP  
                    (DISCH `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))` 
                     (MP  
                      (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                       (MP  
                        (DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                         (MP  
                          (DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                             (DISCH `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (DISCH `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                (MP  
                                 (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                    (DISCH `((col (E : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                     (MP  
                                      (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                       (MP  
                                        (DISCH `ex (\ P : mat_Point. (ex (\ H15 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H15 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H15 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ H16 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H16 : mat_Point))) ((mat_and ((((((congA (x : mat_Point)) (B : mat_Point)) (H16 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (x : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. (ex (\ H16 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H16 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H16 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))) ==> (return : bool)))` 
                                             (SPEC `\ P : mat_Point. (ex (\ H16 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H16 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H16 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                               (ex__ind))))
                                           ) (GEN `(P : mat_Point)` 
                                              (DISCH `ex (\ H16 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H16 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H16 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ==> (return : bool))) ==> ((ex (\ H17 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H17 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))))) ==> (return : bool)))` 
                                                   (SPEC `\ H17 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H17 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                    (PINST [(`:mat_Point`,`:A`)] [] 
                                                     (ex__ind))))
                                                 ) (GEN `(H17 : mat_Point)` 
                                                    (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (H17 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                        (SPEC `(mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                         (SPEC `((out (B : mat_Point)) (C : mat_Point)) (H17 : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (H17 : mat_Point)` 
                                                          (DISCH `(mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                              (SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                (DISCH `(((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                   (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (H17 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ A : mat_Point. ((mat_and (((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (B : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (a : mat_Point))) ==> (return : bool))) ==> ((ex (\ A : mat_Point. ((mat_and (((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ A : mat_Point. ((mat_and (((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (b : mat_Point)) (e : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or ((eq (e : mat_Point)) (c : mat_Point))) ((mat_or (((betS (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (b : mat_Point)) (b : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `(eq (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (b : mat_Point))) ((mat_or ((eq (c : mat_Point)) (b : mat_Point))) ((mat_or (((betS (c : mat_Point)) (b : mat_Point)) (b : mat_Point))) ((mat_or (((betS (b : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((betS (b : mat_Point)) (b : mat_Point)) (c : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (b : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `(((((cong__3 (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `(((((cong__3 (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (E : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (E : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `(((tS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (e : mat_Point)) (e : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `(eq (e : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (e : mat_Point))) ((mat_or ((eq (a : mat_Point)) (e : mat_Point))) ((mat_or ((eq (e : mat_Point)) (e : mat_Point))) ((mat_or (((betS (e : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_or (((betS (a : mat_Point)) (e : mat_Point)) (e : mat_Point))) (((betS (a : mat_Point)) (e : mat_Point)) (e : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (e : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (b : mat_Point)) (X : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (e : mat_Point)) (X : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `(((tS (b : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ G : mat_Point. ((mat_and ((((pG (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (x : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (x : mat_Point)) (G : mat_Point)) (A : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(F : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (x : mat_Point)) (A : mat_Point))))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Z : mat_Point. ((mat_and ((((pG (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (x : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (x : mat_Point)) (E : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))) ==> (ex (\ Z : mat_Point. ((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ Z : mat_Point. ((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (F : mat_Point)) ==> ((((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)) ==> (((((cong (E : mat_Point)) (A : mat_Point)) (e : mat_Point)) (a : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)) ==> ((((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> ((((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)) ==> ((((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((triangle (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((((cong__3 (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) ==> (((((((eT (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) ==> ((((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((triangle (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((cong__3 (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> (((((((eT (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> ((((col (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) ==> (((((tS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> (((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> ((((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)) ==> (((((oS (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((oS (R : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (R : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> (((((oS (R : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (B : mat_Point)) (P : mat_Point)) (F : mat_Point)) ==> (((((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((congA (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (F : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (F : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (C : mat_Point)) (F : mat_Point)) (c : mat_Point)) (a : mat_Point)) ==> (((((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (a : mat_Point)) ==> (((((cong (F : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)) ==> ((((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) ==> ((((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((nCol (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((triangle (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((((cong__3 (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) ==> (((((((eT (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> ((((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((nCol (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((triangle (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((cong__3 (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> (((((((eT (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> ((((col (F : mat_Point)) (E : mat_Point)) (E : mat_Point)) ==> (((((tS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((((eF (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> (((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((((eF (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> ((((col (F : mat_Point)) (G : mat_Point)) (F : mat_Point)) ==> (((((oS (R : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((oS (F : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((oS (F : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((col (G : mat_Point)) (F : mat_Point)) (F : mat_Point)) ==> (((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)))))))))))))))))))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (F : mat_Point)) ==> ((((out (B : mat_Point)) (P : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((congA (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((nCol (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (c : mat_Point)) (a : mat_Point)) ==> (((((cong (E : mat_Point)) (x : mat_Point)) (e : mat_Point)) (a : mat_Point)) ==> (((((cong (x : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)) ==> ((((nCol (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((nCol (B : mat_Point)) (E : mat_Point)) (x : mat_Point)) ==> ((((nCol (x : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((triangle (x : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((((cong__3 (x : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) ==> (((((((eT (x : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((nCol (C : mat_Point)) (E : mat_Point)) (x : mat_Point)) ==> ((((nCol (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((triangle (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((cong__3 (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> (((((((eT (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> ((((col (x : mat_Point)) (E : mat_Point)) (E : mat_Point)) ==> (((((tS (B : mat_Point)) (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((((eF (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> (((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((((eF (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> ((((col (F : mat_Point)) (G : mat_Point)) (x : mat_Point)) ==> (((((oS (R : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((oS (R : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (R : mat_Point)) (x : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((oS (x : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((oS (x : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((col (G : mat_Point)) (F : mat_Point)) (x : mat_Point)) ==> (((((oS (R : mat_Point)) (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. ((((out (B : mat_Point)) (P : mat_Point)) (A0 : mat_Point)) ==> (((((cong (B : mat_Point)) (A0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> (((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((congA (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((nCol (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (C : mat_Point)) (A0 : mat_Point)) (c : mat_Point)) (a : mat_Point)) ==> (((((cong (E : mat_Point)) (A0 : mat_Point)) (e : mat_Point)) (a : mat_Point)) ==> (((((cong (A0 : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)) ==> ((((nCol (B : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) ==> ((((nCol (B : mat_Point)) (E : mat_Point)) (A0 : mat_Point)) ==> ((((nCol (A0 : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((((triangle (A0 : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((((cong__3 (A0 : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) ==> (((((((eT (A0 : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (A0 : mat_Point)) ==> ((((nCol (C : mat_Point)) (E : mat_Point)) (A0 : mat_Point)) ==> ((((nCol (A0 : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((triangle (A0 : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((cong__3 (A0 : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> (((((((eT (A0 : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> ((((col (A0 : mat_Point)) (E : mat_Point)) (E : mat_Point)) ==> (((((tS (B : mat_Point)) (A0 : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((((eF (A0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> (((((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((((((eF (A0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> ((((col (F : mat_Point)) (G : mat_Point)) (A0 : mat_Point)) ==> (((((oS (R : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((oS (R : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (R : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((oS (A0 : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (((((oS (A0 : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((col (G : mat_Point)) (F : mat_Point)) (A0 : mat_Point)) ==> (((((oS (R : mat_Point)) (A0 : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (P : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (F : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((cong__3 (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((cong__3 (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (e : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((cong__3 (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((cong__3 (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__samesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((oS (F : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (F : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (F : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (F : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (F : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (R : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and ((((oS (F : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (R : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (F : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__samesidetransitive
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) ==> ((((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (A : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))) ((((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (A : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))) ((((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))) ((((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))) ((((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))) ((((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (A : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))) ((((oS (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__paralleldef2B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and ((((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and ((((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (F : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    eq__or__neq
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (C : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (C : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (C : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (C : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((par (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((par (C : mat_Point)) (E : mat_Point)) (G : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)) ==> ((((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__samesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((oS (R : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (R : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (R : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (R : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (R : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (A : mat_Point)) (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and ((((oS (R : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((oS (A : mat_Point)) (R : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__samesidecollinear
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((oS (R : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (R : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((oS (P : mat_Point)) (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (R : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (R : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((oS (P : mat_Point)) (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (R : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (P : mat_Point)) (R : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((oS (P : mat_Point)) (R : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((oS (R : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (P : mat_Point)) (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (R : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((oS (R : mat_Point)) (P : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((oS (P : mat_Point)) (R : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((oS (R : mat_Point)) (P : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    axiom__EFtransitive
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and ((((pG (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) (J : mat_Point)) (D : mat_Point)) (K : mat_Point))) (((col (F : mat_Point)) (G : mat_Point)) (A : mat_Point))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__42
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (J : mat_Point)) (D : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__paste3
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((eq (E : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (a : mat_Point)) (e : mat_Point))) ((eq (e : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (e : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (e : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (e : mat_Point)) (e : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (b : mat_Point)) (x : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (e : mat_Point)) (x : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (b : mat_Point)) (X : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (e : mat_Point)) (X : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (b : mat_Point)) (X : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (e : mat_Point)) (X : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (e : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (e : mat_Point)) (e : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (e : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (a : mat_Point)) (e : mat_Point))) ((mat_or ((eq (e : mat_Point)) (e : mat_Point))) ((mat_or (((betS (e : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_or (((betS (a : mat_Point)) (e : mat_Point)) (e : mat_Point))) (((betS (a : mat_Point)) (e : mat_Point)) (e : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (e : mat_Point)) (e : mat_Point))) ((mat_or (((betS (e : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_or (((betS (a : mat_Point)) (e : mat_Point)) (e : mat_Point))) (((betS (a : mat_Point)) (e : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (e : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_or (((betS (a : mat_Point)) (e : mat_Point)) (e : mat_Point))) (((betS (a : mat_Point)) (e : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (e : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (e : mat_Point)) (e : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__congruentequal
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((cong__3 (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (a : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__congruentequal
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((cong__3 (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (e : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (e : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (e : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (e : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (e : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (e : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (e : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (e : mat_Point))) (((nCol (a : mat_Point)) (e : mat_Point)) (b : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (e : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (e : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (e : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (e : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (b : mat_Point)) (e : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (e : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (b : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (e : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (e : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (e : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (b : mat_Point))) ((mat_or ((eq (c : mat_Point)) (b : mat_Point))) ((mat_or (((betS (c : mat_Point)) (b : mat_Point)) (b : mat_Point))) ((mat_or (((betS (b : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((betS (b : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (c : mat_Point)) (b : mat_Point))) ((mat_or (((betS (c : mat_Point)) (b : mat_Point)) (b : mat_Point))) ((mat_or (((betS (b : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((betS (b : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (b : mat_Point)) (b : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (c : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) (((nCol (c : mat_Point)) (b : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or ((eq (e : mat_Point)) (c : mat_Point))) ((mat_or (((betS (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (e : mat_Point)) (c : mat_Point))) ((mat_or (((betS (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (e : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (B : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (E : mat_Point)) (B : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (B : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (e : mat_Point)) (a : mat_Point))) ((((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (e : mat_Point)) (a : mat_Point))) ((((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (e : mat_Point)) (a : mat_Point))) ((((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (e : mat_Point)) (a : mat_Point))) ((((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (e : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (e : mat_Point)) (a : mat_Point))) ((((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (e : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (e : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__interior5
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))))))))))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(a0 : mat_Point)` 
                                                                    (
                                                                    GEN `(b0 : mat_Point)` 
                                                                    (
                                                                    GEN `(c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) (b0 : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) (b0 : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(b0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(a0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H17 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (H17 : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ A : mat_Point. ((mat_and (((out (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (b : mat_Point)) (a : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (P : mat_Point))) ((mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (P : mat_Point))) ((mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (P : mat_Point))) ((mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (P : mat_Point))) ((mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (P : mat_Point))) ((mat_and ((neq (B : mat_Point)) (P : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (P : mat_Point)) (C : mat_Point))) ((neq (P : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (U : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((betS (P : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (R : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (P : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H17 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (H17 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(H17 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (c : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (H17 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                      ))))
                                                ) (ASSUME `ex (\ H16 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H16 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H16 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                ))))
                                          ) (ASSUME `ex (\ P : mat_Point. (ex (\ H15 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H15 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H15 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
                                          ))
                                        ) (MP  
                                           (MP  
                                            (SPEC `ex (\ P : mat_Point. (ex (\ H15 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H15 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H15 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                             (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                              (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                               (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `ex (\ P : mat_Point. (ex (\ H17 : mat_Point. ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (H17 : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (B : mat_Point)) (H17 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((oS (P : mat_Point)) (R : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                   (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(R : mat_Point)` 
                                                          (SPEC `(c : mat_Point)` 
                                                           (SPEC `(a : mat_Point)` 
                                                            (SPEC `(b : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (proposition__23C
                                                               ))))))
                                                         ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                         )
                                                        ) (ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                        )
                                                       ) (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                                           )))
                                      ) (MP  
                                         (MP  
                                          (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                           (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                            (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                             (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                              (MP  
                                               (MP  
                                                (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                 (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                    (MP  
                                                     (SPEC `(R : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (nCol__notCol)))
                                                     ) (MP  
                                                        (SPEC `(R : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (nCol__not__Col)))
                                                        ) (MP  
                                                           (MP  
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(R : mat_Point)` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (lemma__NChelper
                                                                   )))))
                                                              ) (ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                              )
                                                             ) (ASSUME `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                             )
                                                            ) (ASSUME `((col (E : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                            )
                                                           ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                           ))))))
                                               ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                                         ))))
                                   ) (MP  
                                      (SPEC `(mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point)))))` 
                                       (SPEC `(eq (E : mat_Point)) (C : mat_Point)` 
                                        (or__intror))
                                      ) (MP  
                                         (SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))))` 
                                          (SPEC `(eq (E : mat_Point)) (C : mat_Point)` 
                                           (or__intror))
                                         ) (MP  
                                            (SPEC `(mat_or (((betS (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point)))` 
                                             (SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                              (or__introl))
                                            ) (ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                            )))))
                                 ) (MP  
                                    (MP  
                                     (SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                       (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                        (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                         (MP  
                                          (MP  
                                           (CONV_CONV_rule `((((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((eq (C : mat_Point)) (C : mat_Point)))) ==> (((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))) ==> ((eq (C : mat_Point)) (C : mat_Point)))` 
                                            (SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                              (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                               (and__ind))))
                                           ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                              (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (eq__refl)))))
                                          ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                                    )))
                               ) (MP  
                                  (MP  
                                   (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                     (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                      (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                           (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                   (SPEC `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                        (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                         (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                          (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                              (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                               (SPEC `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                   (DISCH `((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (B : mat_Point)))))`
                                                ))
                                              ) (MP  
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(E : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (lemma__collinearorder)))
                                                 ) (ASSUME `((col (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                 )))))
                                        ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                                  ))))
                            ) (MP  
                               (MP  
                                (SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                 (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                  (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                   (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (MP  
                                      (SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                       (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                        (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                         (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                          (MP  
                                           (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                            (SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                             (or__intror))
                                           ) (MP  
                                              (SPEC `(mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                               (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                (or__intror))
                                              ) (MP  
                                                 (SPEC `(mat_or (((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                  (SPEC `(eq (E : mat_Point)) (C : mat_Point)` 
                                                   (or__intror))
                                                 ) (MP  
                                                    (SPEC `(mat_or (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                     (SPEC `((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (or__intror))
                                                    ) (MP  
                                                       (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                        (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                         (or__introl))
                                                       ) (ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                       ))))))))
                                     ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                                     ))))
                               ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                               )))
                          ) (MP  
                             (MP  
                              (SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                               (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                 (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                     (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                      (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (DISCH `(mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point)))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                             (SPEC `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point))))` 
                                              (SPEC `((nCol (E : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((nCol (E : mat_Point)) (R : mat_Point)) (C : mat_Point)` 
                                               (DISCH `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                   (SPEC `(mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point)))` 
                                                    (SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                     (DISCH `(mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                         (SPEC `(mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point))` 
                                                          (SPEC `((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                           (DISCH `(mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)` 
                                                               (SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                (SPEC `((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                 (DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                  (ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point)`
                                                                  )))
                                                             ) (ASSUME `(mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point)))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point))))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (R : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (E : mat_Point)) (R : mat_Point)))))`
                                           ))
                                         ) (MP  
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(E : mat_Point)` 
                                              (SPEC `(R : mat_Point)` 
                                               (lemma__NCorder)))
                                            ) (ASSUME `((nCol (R : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                            )))))
                                   ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                   ))))
                             ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                             )))
                        ) (MP  
                           (MP  
                            (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                             (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                              (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                               (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                (MP  
                                 (MP  
                                  (CONV_CONV_rule `((((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> (((triangle (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))) ==> (((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))) ==> (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                   (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                    (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                     (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                      (and__ind))))
                                  ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                     (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                      (ASSUME `((triangle (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                      )))
                                 ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                 ))))
                           ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                           )))
                      ) (MP  
                         (MP  
                          (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                           (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                            (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                             (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                              (MP  
                               (MP  
                                (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                  (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                   (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (DISCH `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                          (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                           (DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                 (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                  (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                  )))
                                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                             ))))
                                       ) (ASSUME `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                       ))
                                     ) (MP  
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(E : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (lemma__betweennotequal)))
                                        ) (ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                        )))))
                               ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                               ))))
                         ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                         )))
                    ) (MP  
                       (DISCH `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                        (MP  
                         (DISCH `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                          (MP  
                           (MP  
                            (SPEC `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))` 
                             (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                              (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                               (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (CONV_CONV_rule `(((midpoint (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)))` 
                                  (DISCH `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                   (MP  
                                    (DISCH `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))` 
                                        (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `(((midpoint (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> ((mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)))` 
                                             (DISCH `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))` 
                                              (MP  
                                               (DISCH `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))` 
                                                   (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                    (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                     (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                         (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                          (conj))
                                                        ) (ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                                                 ))
                                               ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                                               )))
                                            ) (ASSUME `((midpoint (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                            ))))
                                      ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                      ))
                                    ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                    )))
                                 ) (ASSUME `((midpoint (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                 ))))
                           ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                           ))
                         ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                         ))
                       ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                       )))
                  ) (MP  
                     (CONV_CONV_rule `(((midpoint (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) ==> ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                      (DISCH `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                       (MP  
                        (DISCH `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                         (MP  
                          (MP  
                           (SPEC `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                            (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                             (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                              (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (CONV_CONV_rule `(((midpoint (b : mat_Point)) (e : mat_Point)) (c : mat_Point)) ==> ((mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                 (DISCH `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))` 
                                  (MP  
                                   (DISCH `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                       (SPEC `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                        (SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                         (DISCH `(((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                          (MP  
                                           (MP  
                                            (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                             (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                              (conj))
                                            ) (ASSUME `((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                            )
                                           ) (ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                           ))))
                                     ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                                     ))
                                   ) (ASSUME `(mat_and (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (e : mat_Point)) (e : mat_Point)) (c : mat_Point))`
                                   )))
                                ) (ASSUME `((midpoint (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                ))))
                          ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                          ))
                        ) (ASSUME `(mat_and (((betS (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                        )))
                     ) (ASSUME `((midpoint (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                     )))))))))))))))))))
 ;;


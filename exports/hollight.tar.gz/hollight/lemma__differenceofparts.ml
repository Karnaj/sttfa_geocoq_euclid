(*lemma__differenceofparts :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong A) B) a) b) ==> (((((cong A) C) a) c) ==> ((((betS A) B) C) ==> ((((betS a) b) c) ==> ((((cong B) C) b) c))))))))))`*)
let lemma__differenceofparts =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(a : mat_Point)` 
    (GEN `(b : mat_Point)` 
     (GEN `(c : mat_Point)` 
      (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
       (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
        (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
         (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
          (MP  
           (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
            (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
            )
           ) (MP  
              (DISCH `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
               (MP  
                (DISCH `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                 (MP  
                  (DISCH `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))` 
                   (MP  
                    (MP  
                     (MP  
                      (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                       (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                        (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                         (or__ind)))
                      ) (DISCH `(eq (B : mat_Point)) (A : mat_Point)` 
                         (MP  
                          (DISCH `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                           (MP  
                            (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                             (MP  
                              (CONV_CONV_rule `(((neq (a : mat_Point)) (b : mat_Point)) ==> mat_false) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                               (DISCH `mat_not ((neq (a : mat_Point)) (b : mat_Point))` 
                                (MP  
                                 (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                      (MP  
                                       (DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                        (MP  
                                         (DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                          (MP  
                                           (DISCH `(((cong (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                            (MP  
                                             (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                              (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                              )
                                             ) (MP  
                                                (MP  
                                                 (SPEC `(c : mat_Point)` 
                                                  (SPEC `(b : mat_Point)` 
                                                   (SPEC `(c : mat_Point)` 
                                                    (SPEC `(a : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (lemma__congruencetransitive
                                                       ))))))
                                                 ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                 )
                                                ) (ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                )))
                                           ) (MP  
                                              (SPEC `(c : mat_Point)` 
                                               (SPEC `(c : mat_Point)` 
                                                (SPEC `(b : mat_Point)` 
                                                 (SPEC `(a : mat_Point)` 
                                                  (lemma__congruencesymmetric
                                                  ))))
                                              ) (ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                              )))
                                         ) (MP  
                                            (SPEC `(a : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `((((cong (b : mat_Point)) (c : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (! x : mat_Point. (((eq (x : mat_Point)) (b : mat_Point)) ==> ((((cong (b : mat_Point)) (c : mat_Point)) (x : mat_Point)) (c : mat_Point))))` 
                                               (SPEC `\ X : mat_Point. ((((cong (b : mat_Point)) (c : mat_Point)) (X : mat_Point)) (c : mat_Point))` 
                                                (SPEC `(b : mat_Point)` 
                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                  (eq__ind__r))))
                                              ) (ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                              ))
                                            ) (MP  
                                               (CONV_CONV_rule `(mat_not ((neq (a : mat_Point)) (b : mat_Point))) ==> ((eq (a : mat_Point)) (b : mat_Point))` 
                                                (SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                                 (nNPP))
                                               ) (ASSUME `mat_not ((neq (a : mat_Point)) (b : mat_Point))`
                                               ))))
                                       ) (SPEC `(c : mat_Point)` 
                                          (SPEC `(b : mat_Point)` 
                                           (cn__congruencereflexive))))
                                     ) (MP  
                                        (MP  
                                         (MP  
                                          (MP  
                                           (CONV_CONV_rule `((eq (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)))))` 
                                            (SPEC `(B : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `(((((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((cong (x : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)))))))` 
                                               (SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)))))` 
                                                (SPEC `(A : mat_Point)` 
                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                  (eq__ind__r))))
                                              ) (DISCH `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                 (DISCH `((betS (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                   (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                   ))))))
                                           ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`
                                           )
                                          ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                          )
                                         ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                         )
                                        ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                        )))
                                   ) (MP  
                                      (MP  
                                       (MP  
                                        (CONV_CONV_rule `((eq (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                         (SPEC `(B : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `(((((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((cong (x : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                            (SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                             (SPEC `(A : mat_Point)` 
                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                               (eq__ind__r))))
                                           ) (DISCH `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                              (DISCH `((betS (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                               (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                               )))))
                                        ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`
                                        )
                                       ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                       )
                                      ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                      )))
                                 ) (SPEC `(C : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (cn__congruencereflexive)))))
                              ) (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                 (MP  
                                  (DISCH `(neq (A : mat_Point)) (A : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                     (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                      (MP  
                                       (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                        (ASSUME `(neq (A : mat_Point)) (A : mat_Point)`
                                        )
                                       ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                       )))
                                    ) (MP  
                                       (DISCH `mat_false` 
                                        (MP  
                                         (DISCH `mat_false` 
                                          (SPEC `(A : mat_Point)` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (eq__refl)))) (ASSUME `mat_false`
                                         ))
                                       ) (MP  
                                          (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                             (ASSUME `(neq (A : mat_Point)) (A : mat_Point)`
                                             )
                                            ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                            ))
                                          ) (SPEC `(A : mat_Point)` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (eq__refl))))))
                                  ) (MP  
                                     (MP  
                                      (SPEC `(A : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (SPEC `(b : mat_Point)` 
                                         (SPEC `(a : mat_Point)` 
                                          (axiom__nocollapse))))
                                      ) (ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                      )
                                     ) (ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                     )))))
                            ) (MP  
                               (SPEC `(b : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(A : mat_Point)` 
                                  (SPEC `(a : mat_Point)` 
                                   (lemma__congruencesymmetric))))
                               ) (ASSUME `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                               )))
                          ) (MP  
                             (MP  
                              (MP  
                               (CONV_CONV_rule `((eq (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                (SPEC `(B : mat_Point)` 
                                 (MP  
                                  (CONV_CONV_rule `(((((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))))))` 
                                   (SPEC `\ B0 : mat_Point. (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((betS (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                    (SPEC `(A : mat_Point)` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (eq__ind__r))))
                                  ) (DISCH `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                     (DISCH `((betS (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                      (ASSUME `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                      )))))
                               ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`
                               )
                              ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                              )
                             ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             ))))
                     ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                        (MP  
                         (CONV_CONV_rule `(((eq (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                          (DISCH `mat_not ((eq (C : mat_Point)) (A : mat_Point))` 
                           (MP  
                            (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                             (MP  
                              (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                   (SPEC `\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)
                                    )))
                                 ) (GEN `(E : mat_Point)` 
                                    (DISCH `(mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                        (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                          (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                               (MP  
                                                (DISCH `(neq (c : mat_Point)) (a : mat_Point)` 
                                                 (MP  
                                                  (DISCH `ex (\ e : mat_Point. ((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (c : mat_Point))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((((cong (a : mat_Point)) (x : mat_Point)) (a : mat_Point)) (c : mat_Point))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (c : mat_Point))))) ==> (return : bool)))` 
                                                       (SPEC `\ e : mat_Point. ((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (c : mat_Point)))` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (ex__ind))))
                                                     ) (GEN `(e : mat_Point)` 
                                                        (DISCH `(mat_and (((betS (c : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (c : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                            (SPEC `(((cong (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                             (SPEC `((betS (c : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((betS (c : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                              (DISCH `(((cong (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (a : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (a : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (c : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (A : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (e : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (e : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (C : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (e : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    axiom__innertransitivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__innertransitivity
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (e : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (a : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (c : mat_Point)) (e : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (a : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (a : mat_Point)) (a : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                   ) (
                                                                   ASSUME `(((cong (E : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                  )))
                                                                ) (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))))
                                                          ) (ASSUME `(mat_and (((betS (c : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (c : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `ex (\ e : mat_Point. ((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (c : mat_Point))))`
                                                    ))
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(c : mat_Point)` 
                                                       (SPEC `(a : mat_Point)` 
                                                        (SPEC `(c : mat_Point)` 
                                                         (lemma__localextension
                                                         )))
                                                      ) (ASSUME `(neq (c : mat_Point)) (a : mat_Point)`
                                                      )
                                                     ) (ASSUME `(neq (a : mat_Point)) (c : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (SPEC `(c : mat_Point)` 
                                                    (SPEC `(a : mat_Point)` 
                                                     (lemma__inequalitysymmetric
                                                     ))
                                                   ) (ASSUME `(neq (a : mat_Point)) (c : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `(c : mat_Point)` 
                                                   (SPEC `(a : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (axiom__nocollapse))))
                                                  ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                  )
                                                 ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                 )))
                                            ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                            ))))
                                      ) (ASSUME `(mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                      ))))
                                ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                ))
                              ) (MP  
                                 (MP  
                                  (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (A : mat_Point))) ==> (((neq (A : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (SPEC `(C : mat_Point)` 
                                      (lemma__localextension))))
                                  ) (ASSUME `mat_not ((eq (C : mat_Point)) (A : mat_Point))`
                                  )
                                 ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                 )))
                            ) (MP  
                               (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (A : mat_Point))) ==> ((neq (A : mat_Point)) (C : mat_Point))` 
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (lemma__inequalitysymmetric)))
                               ) (ASSUME `mat_not ((eq (C : mat_Point)) (A : mat_Point))`
                               ))))
                         ) (DISCH `(eq (C : mat_Point)) (A : mat_Point)` 
                            (MP  
                             (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                              (MP  
                               (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                (MP  
                                 (CONV_CONV_rule `(((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                  (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                  )
                                 ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                 ))
                               ) (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (axiom__betweennessidentity))))
                             ) (MP  
                                (MP  
                                 (MP  
                                  (CONV_CONV_rule `((eq (C : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                   (SPEC `(C : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `(((((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                                      (SPEC `\ C0 : mat_Point. (((((cong (A : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                       (SPEC `(A : mat_Point)` 
                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                         (eq__ind__r))))
                                     ) (DISCH `(((cong (A : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                        (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                         (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                         )))))
                                  ) (ASSUME `(eq (C : mat_Point)) (A : mat_Point)`
                                  )
                                 ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                 )
                                ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                ))))))
                    ) (ASSUME `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))`
                    ))
                  ) (ASSUME `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))`
                  ))
                ) (ASSUME `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (A : mat_Point))`
                ))
              ) (SPEC `(A : mat_Point)` 
                 (SPEC `(B : mat_Point)` (eq__or__neq))))))))))))))
 ;;


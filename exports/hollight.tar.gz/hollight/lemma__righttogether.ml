(*lemma__righttogether :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! G : mat_Point. ((((per G) A) B) ==> ((((per B) A) C) ==> (((((tS G) B) A) C) ==> ((mat_and ((((((rT G) A) B) B) A) C)) (((betS G) A) C))))))))`*)
let lemma__righttogether =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(G : mat_Point)` 
    (DISCH `((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
     (DISCH `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
      (DISCH `(((tS (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
       (MP  
        (DISCH `((per (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
         (MP  
          (DISCH `(neq (A : mat_Point)) (G : mat_Point)` 
           (MP  
            (DISCH `(neq (G : mat_Point)) (A : mat_Point)` 
             (MP  
              (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `(mat_and ((((((rT (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (G : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (G : mat_Point)) (A : mat_Point))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (G : mat_Point)) (A : mat_Point))))) ==> (return : bool)))` 
                   (SPEC `\ D : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(D : mat_Point)` 
                    (DISCH `(mat_and (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `(mat_and ((((((rT (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (G : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                        (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                         (SPEC `((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                          (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((mat_and ((((((rT (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (G : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                             (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                (MP  
                                 (DISCH `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                  (MP  
                                   (CONV_CONV_rule `((mat_and (((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) ==> ((mat_and ((((((rT (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (G : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                    (DISCH `((((supp (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                     (MP  
                                      (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                       (MP  
                                        (DISCH `((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (MP  
                                          (DISCH `(((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (A : mat_Point))) ((mat_or ((eq (G : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (G : mat_Point)) (D : mat_Point)) (A : mat_Point))))))) ==> ((mat_and ((((((rT (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (G : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                             (DISCH `((col (G : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                              (MP  
                                               (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                (MP  
                                                 (DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                  (MP  
                                                   (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (MP  
                                                     (DISCH `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))) ==> ((mat_and ((((((rT (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (G : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                          (DISCH `(((((rT (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(((tS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                             (MP  
                                                              (DISCH `((betS (G : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((betS (G : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `(((((rT (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                   (conj))
                                                                 ) (ASSUME `(((((rT (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((betS (G : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                ))
                                                              ) (MP  
                                                                 (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! E : mat_Point. (((((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E : mat_Point)) ==> ((((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> (((((tS (E : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) ==> (((betS (A0 : mat_Point)) (B0 : mat_Point)) (E : mat_Point)))))))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! E : mat_Point. (((((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E : mat_Point)) ==> ((((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> (((((tS (E : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) ==> (((betS (A0 : mat_Point)) (B0 : mat_Point)) (E : mat_Point)))))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((((rT (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((tS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                                   ))
                                                                 ) (GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (E : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((((supp (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((((supp (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (A0 : mat_Point)) (B0 : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__14
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((((rT (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (E : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                            ) (MP  
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(G : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (lemma__oppositesidesymmetric
                                                                   ))))
                                                               ) (ASSUME `(((tS (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                               ))))
                                                         ) (MP  
                                                            (SPEC `(G : mat_Point)` 
                                                             (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (x : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))))` 
                                                              (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (X : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))))` 
                                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                                (ex__intro)))
                                                             )
                                                            ) (MP  
                                                               (SPEC `(A : mat_Point)` 
                                                                (CONV_CONV_rule `! x : mat_Point. ((ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (x : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (x : mat_Point)) (Z : mat_Point)))))))))) ==> (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))))))` 
                                                                 (SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (Y : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (Y : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))))` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (ex__intro
                                                                   ))))
                                                               ) (MP  
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (A : mat_Point)) (U : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (A : mat_Point)) (x : mat_Point)))))))) ==> (ex (\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (A : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (A : mat_Point)) (Z : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ Z : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (A : mat_Point)) (U : mat_Point)) (V : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (A : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (A : mat_Point)) (x : mat_Point)) (V : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (A : mat_Point)) (D : mat_Point)))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (A : mat_Point)) (U : mat_Point)) (V : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (A : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (A : mat_Point)) (U : mat_Point)) (V : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (A : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (CONV_CONV_rule `! x : mat_Point. (((mat_and (((((supp (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ==> (ex (\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (V : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (A : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((((supp (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (V : mat_Point)) (D : mat_Point))) ((mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (V : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and ((((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((((supp (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((((supp (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `(((((congA (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                  )))))))))
                                                       ) (MP  
                                                          (MP  
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (lemma__Euclid4
                                                                 ))))))
                                                           ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                           )
                                                          ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                          )))
                                                     ) (MP  
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(D : mat_Point)` 
                                                           (lemma__8__2)))
                                                        ) (ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                        )))
                                                   ) (MP  
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(G : mat_Point)` 
                                                            (lemma__collinearright
                                                            ))))
                                                        ) (ASSUME `((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                        )
                                                       ) (ASSUME `((col (G : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                       )
                                                      ) (ASSUME `(neq (D : mat_Point)) (A : mat_Point)`
                                                      )))
                                                 ) (MP  
                                                    (SPEC `(D : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (lemma__inequalitysymmetric
                                                      ))
                                                    ) (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                    )))
                                               ) (MP  
                                                  (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (G : mat_Point)) (D : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (G : mat_Point)) (D : mat_Point))` 
                                                       (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `(mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (G : mat_Point)) (D : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                            (SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                                             (SPEC `(neq (G : mat_Point)) (A : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(neq (G : mat_Point)) (A : mat_Point)` 
                                                              (DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                                               (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                               )))
                                                          ) (ASSUME `(mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (G : mat_Point)) (D : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (A : mat_Point))) ((neq (G : mat_Point)) (D : mat_Point)))`
                                                    ))
                                                  ) (MP  
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (SPEC `(G : mat_Point)` 
                                                        (lemma__betweennotequal
                                                        )))
                                                     ) (ASSUME `((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                     )))))
                                            ) (MP  
                                               (SPEC `(mat_or ((eq (G : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (G : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                (SPEC `(eq (G : mat_Point)) (A : mat_Point)` 
                                                 (or__intror))
                                               ) (MP  
                                                  (SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (G : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                   (SPEC `(eq (G : mat_Point)) (D : mat_Point)` 
                                                    (or__intror))
                                                  ) (MP  
                                                     (SPEC `(mat_or (((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (G : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                      (SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                       (or__intror))
                                                     ) (MP  
                                                        (SPEC `(mat_or (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (G : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                         (SPEC `((betS (A : mat_Point)) (G : mat_Point)) (D : mat_Point)` 
                                                          (or__intror))
                                                        ) (MP  
                                                           (SPEC `((betS (G : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                            (SPEC `((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                             (or__introl))
                                                           ) (ASSUME `((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                           )))))))
                                          ) (MP  
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(A : mat_Point)` 
                                               (SPEC `(G : mat_Point)` 
                                                (lemma__equalanglesreflexive)
                                               ))
                                             ) (ASSUME `((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                             )))
                                        ) (MP  
                                           (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                               (SPEC `(mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                 (DISCH `(mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `(mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                      (SPEC `((nCol (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((nCol (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                       (DISCH `(mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `(mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                            (SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((nCol (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                             (DISCH `(mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                  (SPEC `((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                             ))
                                           ) (MP  
                                              (SPEC `(G : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (lemma__NCorder)))
                                              ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (CONV_CONV_rule `((((tS (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                          (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))` 
                                           (MP  
                                            (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (G : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))) ==> (return : bool)))` 
                                                 (SPEC `\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point))))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__ind))))
                                               ) (GEN `(x : mat_Point)` 
                                                  (DISCH `(mat_and (((betS (G : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                      (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                                       (SPEC `((betS (G : mat_Point)) (x : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((betS (G : mat_Point)) (x : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                            (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                             (SPEC `((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                                              (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                               (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                                               )))
                                                          ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((betS (G : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))`
                                                    ))))
                                              ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))`
                                              ))
                                            ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))`
                                            )))
                                         ) (ASSUME `(((tS (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                         ))))
                                   ) (MP  
                                      (MP  
                                       (SPEC `((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                        (SPEC `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                         (conj))
                                       ) (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                       )
                                      ) (ASSUME `((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                      )))
                                 ) (MP  
                                    (MP  
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(A : mat_Point)` (lemma__ray4))
                                      )
                                     ) (MP  
                                        (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                          (or__intror))
                                        ) (MP  
                                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                            (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                             (or__introl))
                                           ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                           )))
                                    ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                    )))
                               ) (MP  
                                  (CONV_CONV_rule `(((per (B : mat_Point)) (A : mat_Point)) (G : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point))` 
                                   (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))))` 
                                    (MP  
                                     (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))))) ==> (return : bool)))` 
                                          (SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point)))))` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (ex__ind))))
                                        ) (GEN `(x : mat_Point)` 
                                           (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                               (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point)))` 
                                                (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                                 (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `(mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))` 
                                                      (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)` 
                                                       (DISCH `(mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                            (SPEC `(((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point)` 
                                                             (DISCH `(neq (A : mat_Point)) (G : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `(((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                                                                 (MP  
                                                                  (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                  ) (
                                                                  ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                                                                  )))
                                                               ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point)))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))`
                                             ))))
                                       ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))))`
                                       ))
                                     ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))))`
                                     )))
                                  ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
                                  ))))
                            ) (SPEC `(B : mat_Point)` 
                               (PINST [(`:mat_Point`,`:A`)] [] (eq__refl)))))
                       )
                      ) (ASSUME `(mat_and (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (G : mat_Point)) (A : mat_Point))`
                      ))))
                ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (G : mat_Point)) (A : mat_Point))))`
                ))
              ) (MP  
                 (MP  
                  (SPEC `(A : mat_Point)` 
                   (SPEC `(G : mat_Point)` 
                    (SPEC `(A : mat_Point)` 
                     (SPEC `(G : mat_Point)` (lemma__extension))))
                  ) (ASSUME `(neq (G : mat_Point)) (A : mat_Point)`)
                 ) (ASSUME `(neq (G : mat_Point)) (A : mat_Point)`)))
            ) (MP  
               (SPEC `(G : mat_Point)` 
                (SPEC `(A : mat_Point)` (lemma__inequalitysymmetric))
               ) (ASSUME `(neq (A : mat_Point)) (G : mat_Point)`)))
          ) (MP  
             (CONV_CONV_rule `(((per (B : mat_Point)) (A : mat_Point)) (G : mat_Point)) ==> ((neq (A : mat_Point)) (G : mat_Point))` 
              (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))))` 
               (MP  
                (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))))` 
                 (MP  
                  (MP  
                   (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                    (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))))) ==> (return : bool)))` 
                     (SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point)))))` 
                      (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                   ) (GEN `(x : mat_Point)` 
                      (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                          (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point)))` 
                           (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                            (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point)))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                (SPEC `(mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))` 
                                 (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)` 
                                  (DISCH `(mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                      (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                       (SPEC `(((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point)` 
                                        (DISCH `(neq (A : mat_Point)) (G : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `(((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((neq (A : mat_Point)) (G : mat_Point))` 
                                           (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                                            (MP  
                                             (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                 (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
                                                  (SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (ex__ind))))
                                                ) (GEN `(x0 : mat_Point)` 
                                                   (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                       (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                        (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)` 
                                                         (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                             (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                              (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point)` 
                                                               (DISCH `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                   (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((neq (A : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (x1 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (x1 : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (B : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x0 : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))`
                                                     ))))
                                               ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                                               ))
                                             ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))))`
                                             )))
                                          ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                          ))))
                                    ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))`
                                    ))))
                              ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point)))`
                              ))))
                        ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (x : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))`
                        ))))
                  ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))))`
                  ))
                ) (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (G : mat_Point)) (X : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (G : mat_Point))))))`
                )))
             ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (G : mat_Point)`
             )))
        ) (MP  
           (SPEC `(B : mat_Point)` 
            (SPEC `(A : mat_Point)` (SPEC `(G : mat_Point)` (lemma__8__2)))
           ) (ASSUME `((per (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
           )))))))))
 ;;


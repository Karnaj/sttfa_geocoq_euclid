(*lemma__rightangleNC :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((per A) B) C) ==> (((nCol A) B) C))))`*)
let lemma__rightangleNC =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
      (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))` 
       (MP  
        (MP  
         (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))) ==> (return : bool)))` 
           (SPEC `\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))))` 
            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
         ) (GEN `(D : mat_Point)` 
            (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))` 
             (MP  
              (MP  
               (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                 (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                  (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                   (MP  
                    (MP  
                     (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                       (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                        (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                         (MP  
                          (MP  
                           (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                             (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                              (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                 (MP  
                                  (CONV_CONV_rule `((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                   (DISCH `((midpoint (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `((((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                      (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                       (MP  
                                        (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `(((eq (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                           (DISCH `mat_not ((eq (C : mat_Point)) (A : mat_Point))` 
                                            (MP  
                                             (CONV_CONV_rule `(((eq (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                              (DISCH `mat_not ((eq (C : mat_Point)) (D : mat_Point))` 
                                               (MP  
                                                (CONV_CONV_rule `((((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                 (DISCH `mat_not (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                  (MP  
                                                   (CONV_CONV_rule `((((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                    (DISCH `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                     (MP  
                                                      (CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                       (DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                        (MP  
                                                         (SPEC `(C : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (nCol__notCol)))
                                                         ) (ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                         )))
                                                      ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                                                           (DISCH `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                              (MP  
                                                               (DISCH `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (A : mat_Point))) ==> ((mat_not (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((neq (A : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (A : mat_Point))) ==> ((mat_not (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((neq (A : mat_Point)) (C : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((midpoint (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (C : mat_Point))) ==> ((mat_not (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((mat_not (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ==> ((((col (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> ((((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (mat_not ((eq (C : mat_Point)) (C : mat_Point))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((per (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((midpoint (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (x : mat_Point))) ==> ((mat_not (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> ((mat_not (((betS (x : mat_Point)) (D : mat_Point)) (C : mat_Point))) ==> ((((col (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((neq (x : mat_Point)) (C : mat_Point))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. ((((per (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((midpoint (A0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A0 : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((neq (A0 : mat_Point)) (B : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (A0 : mat_Point))) ==> ((mat_not (((betS (C : mat_Point)) (A0 : mat_Point)) (D : mat_Point))) ==> ((mat_not (((betS (A0 : mat_Point)) (D : mat_Point)) (C : mat_Point))) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (B : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (A0 : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (A0 : mat_Point)) ==> ((((col (A0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((neq (A0 : mat_Point)) (C : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((per (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((midpoint (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((eq (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (C : mat_Point))`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (CONV_CONV_rule `((((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                   ) (
                                                                   DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                               ) (MP  
                                                                  (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                  ))))
                                                             ) (MP  
                                                                (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   )))))
                                                          ) (MP  
                                                             (SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                                              (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                               (or__intror))
                                                             ) (MP  
                                                                (SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                                 (SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                  (or__intror
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `((betS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                   ))))))))))
                                                   ) (DISCH `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (DISCH `((betS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                          (MP  
                                                           (DISCH `mat_not ((((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                            (MP  
                                                             (CONV_CONV_rule `((((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                              (ASSUME `mat_not ((((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                              )
                                                             ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(A : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (lemma__partnotequalwhole
                                                                 )))
                                                              ) (ASSUME `((betS (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                              )))
                                                         ) (MP  
                                                            (DISCH `(mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                   )))
                                                              ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                              ))
                                                            ) (MP  
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (lemma__doublereverse
                                                                   ))))
                                                               ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                               ))))
                                                       ) (MP  
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (axiom__betweennesssymmetry
                                                             )))
                                                          ) (ASSUME `((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                          ))))))
                                                ) (DISCH `((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (MP  
                                                      (DISCH `mat_not ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                       (MP  
                                                        (CONV_CONV_rule `((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                         (ASSUME `mat_not ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                         )
                                                        ) (ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                        ))
                                                      ) (MP  
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (lemma__partnotequalwhole
                                                            )))
                                                         ) (ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                            (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                             (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                  (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (lemma__congruenceflip
                                                              ))))
                                                          ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                          )))))))
                                             ) (DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `(((neq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                                    (DISCH `mat_not ((neq (A : mat_Point)) (C : mat_Point))` 
                                                     (MP  
                                                      (CONV_CONV_rule `((eq (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                       (DISCH `(eq (C : mat_Point)) (A : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `((eq (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                          (ASSUME `mat_not ((eq (C : mat_Point)) (A : mat_Point))`
                                                          )
                                                         ) (ASSUME `(eq (C : mat_Point)) (A : mat_Point)`
                                                         )))
                                                      ) (MP  
                                                         (DISCH `mat_false` 
                                                          (MP  
                                                           (DISCH `mat_false` 
                                                            (MP  
                                                             (SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                                              (false__ind)
                                                             ) (ASSUME `mat_false`
                                                             ))
                                                           ) (ASSUME `mat_false`
                                                           ))
                                                         ) (MP  
                                                            (CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                                             (DISCH `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
                                                              (MP  
                                                               (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                                (ASSUME `mat_not ((neq (A : mat_Point)) (C : mat_Point))`
                                                                )
                                                               ) (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                                                               )))
                                                            ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((eq (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                 (ASSUME `mat_not ((eq (C : mat_Point)) (A : mat_Point))`
                                                                 )
                                                                ) (MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__sym))
                                                                    )
                                                                   ) (
                                                                   ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                                   ))))))))
                                                   ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(neq (D : mat_Point)) (D : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                          (DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                             (ASSUME `(neq (D : mat_Point)) (D : mat_Point)`
                                                             )
                                                            ) (ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                            )))
                                                         ) (MP  
                                                            (DISCH `mat_false` 
                                                             (MP  
                                                              (DISCH `mat_false` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (eq__refl)))
                                                              ) (ASSUME `mat_false`
                                                              ))
                                                            ) (MP  
                                                               (DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                  (ASSUME `(neq (D : mat_Point)) (D : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                 ))
                                                               ) (SPEC `(D : mat_Point)` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (eq__refl)
                                                                  )))))
                                                       ) (MP  
                                                          (MP  
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (axiom__nocollapse
                                                               ))))
                                                           ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                          )))))
                                                 ) (MP  
                                                    (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (A : mat_Point))) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (CONV_CONV_rule `((eq (C : mat_Point)) (D : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((mat_not ((eq (C : mat_Point)) (A : mat_Point))) ==> ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)))))))` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (MP  
                                                             (CONV_CONV_rule `((((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))) ==> ((mat_not ((eq (D : mat_Point)) (A : mat_Point))) ==> ((((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (D : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> ((mat_not ((eq (x : mat_Point)) (A : mat_Point))) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (D : mat_Point)))))))))` 
                                                              (SPEC `\ C0 : mat_Point. ((((per (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (D : mat_Point)) (C0 : mat_Point)) ==> (((neq (B : mat_Point)) (C0 : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (C0 : mat_Point)) (D : mat_Point))) ==> ((mat_not ((eq (C0 : mat_Point)) (A : mat_Point))) ==> ((((cong (A : mat_Point)) (C0 : mat_Point)) (D : mat_Point)) (D : mat_Point)))))))` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (eq__ind__r)
                                                                )))
                                                             ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                 (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                  (DISCH `mat_not (((betS (A : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                   (DISCH `mat_not ((eq (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    ))))))))
                                                          ) (ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                                          )
                                                         ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                        )
                                                       ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                       )
                                                      ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                      ))
                                                    ) (ASSUME `mat_not ((eq (C : mat_Point)) (A : mat_Point))`
                                                    ))))))
                                          ) (DISCH `(eq (C : mat_Point)) (A : mat_Point)` 
                                             (MP  
                                              (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (CONV_CONV_rule `(((neq (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                                   (DISCH `mat_not ((neq (D : mat_Point)) (C : mat_Point))` 
                                                    (MP  
                                                     (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (CONV_CONV_rule `((eq (D : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                        (DISCH `(eq (D : mat_Point)) (A : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((eq (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                           (DISCH `(eq (A : mat_Point)) (D : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `((eq (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                )
                                                               ) (ASSUME `(eq (A : mat_Point)) (D : mat_Point)`
                                                               ))
                                                             ) (MP  
                                                                (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                   )))))
                                                          ) (MP  
                                                             (MP  
                                                              (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (D : mat_Point)) (A : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((((cong (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((mat_not ((neq (D : mat_Point)) (C : mat_Point))) ==> ((eq (A : mat_Point)) (D : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((mat_not ((neq (A : mat_Point)) (C : mat_Point))) ==> ((eq (A : mat_Point)) (A : mat_Point))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point))) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((mat_not ((neq (x : mat_Point)) (C : mat_Point))) ==> ((eq (A : mat_Point)) (x : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ D0 : mat_Point. ((((betS (A : mat_Point)) (B : mat_Point)) (D0 : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (D0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (D0 : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D0 : mat_Point)) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (D0 : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D0 : mat_Point))) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (D0 : mat_Point)) (C : mat_Point)) ==> (((((cong (D0 : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((mat_not ((neq (D0 : mat_Point)) (C : mat_Point))) ==> ((eq (A : mat_Point)) (D0 : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((midpoint (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> ((eq (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (A : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> ((((midpoint (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((mat_not ((neq (A : mat_Point)) (C : mat_Point))) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((eq (A : mat_Point)) (C : mat_Point)) ==> ((eq (A : mat_Point)) (A : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not (((betS (C : mat_Point)) (C : mat_Point)) (C : mat_Point))) ==> ((((midpoint (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((mat_not ((neq (C : mat_Point)) (C : mat_Point))) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((eq (C : mat_Point)) (C : mat_Point)) ==> ((eq (C : mat_Point)) (C : mat_Point)))))))))))))) ==> (! y : mat_Point. (((eq (C : mat_Point)) (y : mat_Point)) ==> ((((per (y : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (y : mat_Point)) (C : mat_Point)) (y : mat_Point)) (C : mat_Point)) ==> (((((cong (y : mat_Point)) (B : mat_Point)) (y : mat_Point)) (B : mat_Point)) ==> ((((betS (y : mat_Point)) (B : mat_Point)) (y : mat_Point)) ==> ((mat_not (((betS (y : mat_Point)) (C : mat_Point)) (y : mat_Point))) ==> ((((midpoint (y : mat_Point)) (B : mat_Point)) (y : mat_Point)) ==> (((((cong (y : mat_Point)) (B : mat_Point)) (B : mat_Point)) (y : mat_Point)) ==> (((neq (y : mat_Point)) (B : mat_Point)) ==> ((mat_not ((neq (y : mat_Point)) (C : mat_Point))) ==> (((((cong (y : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (y : mat_Point)) (C : mat_Point)) ==> (((eq (y : mat_Point)) (C : mat_Point)) ==> ((eq (y : mat_Point)) (y : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ A0 : mat_Point. ((((per (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) ==> ((((betS (A0 : mat_Point)) (B : mat_Point)) (A0 : mat_Point)) ==> ((mat_not (((betS (A0 : mat_Point)) (C : mat_Point)) (A0 : mat_Point))) ==> ((((midpoint (A0 : mat_Point)) (B : mat_Point)) (A0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A0 : mat_Point)) ==> (((neq (A0 : mat_Point)) (B : mat_Point)) ==> ((mat_not ((neq (A0 : mat_Point)) (C : mat_Point))) ==> (((((cong (A0 : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) (C : mat_Point)) ==> (((eq (A0 : mat_Point)) (C : mat_Point)) ==> ((eq (A0 : mat_Point)) (A0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind))
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((betS (C : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((midpoint (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((neq (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                 )
                                                                ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                )
                                                               ) (ASSUME `(((cong (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                               )
                                                              ) (ASSUME `(((cong (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                              )
                                                             ) (ASSUME `mat_not ((neq (D : mat_Point)) (C : mat_Point))`
                                                             ))))
                                                       ) (MP  
                                                          (DISCH `(eq (D : mat_Point)) (C : mat_Point)` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(A : mat_Point)` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (eq__trans))
                                                               ))
                                                             ) (ASSUME `(eq (D : mat_Point)) (C : mat_Point)`
                                                             )
                                                            ) (MP  
                                                               (CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> ((eq (C : mat_Point)) (A : mat_Point))` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (eq__sym))
                                                                 ))
                                                               ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (CONV_CONV_rule `(mat_not ((neq (D : mat_Point)) (C : mat_Point))) ==> ((eq (D : mat_Point)) (C : mat_Point))` 
                                                              (SPEC `(eq (D : mat_Point)) (C : mat_Point)` 
                                                               (nNPP))
                                                             ) (ASSUME `mat_not ((neq (D : mat_Point)) (C : mat_Point))`
                                                             ))))
                                                     ) (MP  
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (lemma__equalitysymmetric
                                                          ))
                                                        ) (ASSUME `(eq (C : mat_Point)) (A : mat_Point)`
                                                        ))))
                                                  ) (DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(neq (C : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                         (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                            (ASSUME `(neq (C : mat_Point)) (C : mat_Point)`
                                                            )
                                                           ) (ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                           )))
                                                        ) (MP  
                                                           (DISCH `mat_false` 
                                                            (MP  
                                                             (DISCH `mat_false` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                                (eq__refl)))
                                                             ) (ASSUME `mat_false`
                                                             ))
                                                           ) (MP  
                                                              (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                 (ASSUME `(neq (C : mat_Point)) (C : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                ))
                                                              ) (SPEC `(C : mat_Point)` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (eq__refl))
                                                              ))))
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(D : mat_Point)` 
                                                              (axiom__nocollapse
                                                              ))))
                                                          ) (ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                          )
                                                         ) (ASSUME `(((cong (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                         )))))
                                                ) (MP  
                                                   (SPEC `(C : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(D : mat_Point)` 
                                                       (lemma__congruencesymmetric
                                                       ))))
                                                   ) (ASSUME `(((cong (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (MP  
                                                  (MP  
                                                   (MP  
                                                    (MP  
                                                     (CONV_CONV_rule `((eq (C : mat_Point)) (A : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((((cong (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((((per (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> (((neq (B : mat_Point)) (A : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ==> ((((cong (A : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (A : mat_Point)) ==> ((((per (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> ((((cong (x : mat_Point)) (x : mat_Point)) (D : mat_Point)) (x : mat_Point))))))))` 
                                                         (SPEC `\ C0 : mat_Point. ((((per (A : mat_Point)) (B : mat_Point)) (C0 : mat_Point)) ==> (((((cong (A : mat_Point)) (C0 : mat_Point)) (D : mat_Point)) (C0 : mat_Point)) ==> (((neq (B : mat_Point)) (C0 : mat_Point)) ==> ((mat_not (((betS (A : mat_Point)) (C0 : mat_Point)) (D : mat_Point))) ==> ((((cong (C0 : mat_Point)) (C0 : mat_Point)) (D : mat_Point)) (C0 : mat_Point))))))` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (eq__ind__r))))
                                                        ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                           (DISCH `(((cong (A : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                            (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                             (DISCH `mat_not (((betS (A : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                              (ASSUME `(((cong (A : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                              )))))))
                                                     ) (ASSUME `(eq (C : mat_Point)) (A : mat_Point)`
                                                     )
                                                    ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                    )
                                                   ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                   )
                                                  ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                  )
                                                 ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                 )))))
                                        ) (MP  
                                           (DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                               (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                       (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                        (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))`
                                             ))
                                           ) (MP  
                                              (SPEC `(D : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (lemma__betweennotequal)))
                                              ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                              )))))
                                     ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (MP  
                                         (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `((mat_and (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                            (DISCH `((midpoint (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                             (MP  
                                              (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                 (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                 )
                                                ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                ))
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(D : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (lemma__midpointunique)
                                                     )))
                                                  ) (ASSUME `((midpoint (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                  )
                                                 ) (ASSUME `((midpoint (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                 ))))
                                           ) (MP  
                                              (MP  
                                               (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (conj))
                                               ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                               )
                                              ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                              )))
                                         ) (MP  
                                            (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                 (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                              ))
                                            ) (MP  
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(D : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (lemma__congruenceflip))))
                                               ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                               )))))))
                                  ) (MP  
                                     (MP  
                                      (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                       (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                        (conj))
                                      ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                      )
                                     ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                     )))
                                ) (MP  
                                   (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                       (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                        (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                         (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                              (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                               (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                )))
                                           ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                           ))))
                                     ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                     ))
                                   ) (MP  
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(D : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (lemma__congruenceflip))))
                                      ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                      ))))))
                          ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                          ))))
                    ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                    ))))
              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))`
              ))))
        ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))))))`
        )))
     ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`)))))
 ;;


(*lemma__Playfairhelper :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (((((par A) B) C) D) ==> (((((par A) B) C) E) ==> (((((cR A) D) B) C) ==> (((((cR A) E) B) C) ==> (((col C) D) E)))))))))`*)
let lemma__Playfairhelper =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
       (DISCH `(((cR (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
        (DISCH `(((cR (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
         (MP  
          (CONV_CONV_rule `((((cR (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
           (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
            (MP  
             (MP  
              (SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                (SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
              ) (GEN `(M : mat_Point)` 
                 (DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                  (MP  
                   (MP  
                    (SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                     (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                      (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                       (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                        (MP  
                         (CONV_CONV_rule `((((cR (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                          (DISCH `ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))` 
                           (MP  
                            (MP  
                             (SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                               (SPEC `\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                             ) (GEN `(m : mat_Point)` 
                                (DISCH `(mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                    (SPEC `((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                     (SPEC `((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point)` 
                                      (DISCH `((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                         (MP  
                                          (DISCH `((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                           (MP  
                                            (DISCH `((betS (D : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))))))) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                               (DISCH `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (m : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (m : mat_Point)) (C : mat_Point))) ((mat_or (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (m : mat_Point))))))) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                  (DISCH `((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                           (MP  
                                                            (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                             (MP  
                                                              (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                 (DISCH `(((tS (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (D : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ e : mat_Point. ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (C : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ e : mat_Point. ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (E : mat_Point))))))) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (e : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (e : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (e : mat_Point)) (e : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (e : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (e : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (e : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (e : mat_Point)) (D : mat_Point)) ==> ((((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point)) ==> (((((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((((congA (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((((congA (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (E : mat_Point)) (e : mat_Point)) ==> (((neq (C : mat_Point)) (e : mat_Point)) ==> ((((nCol (C : mat_Point)) (e : mat_Point)) (B : mat_Point)) ==> ((((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((triangle (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)) ==> ((((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point)) ==> (((((oS (e : mat_Point)) (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (e : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (e : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((out (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> (((((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> (((neq (C : mat_Point)) (D : mat_Point)) ==> ((((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((out (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((oS (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (D : mat_Point)) ==> ((((out (C : mat_Point)) (E : mat_Point)) (x : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((((congA (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((((congA (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (E : mat_Point)) (x : mat_Point)) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> ((((nCol (C : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((nCol (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((triangle (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((out (C : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> (((((oS (x : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (x : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (x : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ e0 : mat_Point. ((((out (C : mat_Point)) (E : mat_Point)) (e0 : mat_Point)) ==> (((((cong (C : mat_Point)) (e0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (e0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((((congA (e0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((((congA (e0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (E : mat_Point)) (e0 : mat_Point)) ==> (((neq (C : mat_Point)) (e0 : mat_Point)) ==> ((((nCol (C : mat_Point)) (e0 : mat_Point)) (B : mat_Point)) ==> ((((nCol (e0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((triangle (e0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (e0 : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> ((((nCol (C : mat_Point)) (B : mat_Point)) (e0 : mat_Point)) ==> ((((out (C : mat_Point)) (e0 : mat_Point)) (E : mat_Point)) ==> (((((oS (e0 : mat_Point)) (e0 : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (e0 : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((oS (e0 : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((((cong (e0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> (((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((out (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (e : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (e : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (e : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (e : mat_Point)) (e : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (e : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (e : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    proposition__07
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (e : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (e : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (e : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (e : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (e : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (e : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (e : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (e : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (e : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (e : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__samesidetransitive
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (e : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__sameside2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((oS (e : mat_Point)) (e : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__samesidereflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (e : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (e : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (e : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (e : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((mat_and (((nCol (C : mat_Point)) (e : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (e : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (A : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (A : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((betS (D : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point))) ((mat_and (((betS (D : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (D : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(a : mat_Point)` 
                                                                    (
                                                                    GEN `(b : mat_Point)` 
                                                                    (
                                                                    GEN `(c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (e : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (e : mat_Point))) (((nCol (B : mat_Point)) (e : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (e : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (e : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__raystrict
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (e : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (e : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ e : mat_Point. ((mat_and (((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((((cong (C : mat_Point)) (e : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__layoff
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((neq (E : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    proposition__29B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    proposition__29B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((par (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((par (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((par (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((par (E : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (D : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (D : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (D : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                   ))))))
                                                                ) (MP  
                                                                   (SPEC `(m : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (m : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                   )))))
                                                              ) (MP  
                                                                 (DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                            ) (MP  
                                                               (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                  ))))
                                                          ) (MP  
                                                             (DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                 (SPEC `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                  (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                   (DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(E : mat_Point)` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (lemma__NCorder
                                                                   )))
                                                                ) (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                ))))
                                                        ) (MP  
                                                           (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                               (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(E : mat_Point)` 
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (lemma__parallelNC
                                                                  ))))
                                                              ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                              ))))
                                                      ) (MP  
                                                         (DISCH `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point)))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                             (SPEC `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point))))` 
                                                              (SPEC `((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                   (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((col (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (m : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (m : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (m : mat_Point))) (((col (C : mat_Point)) (m : mat_Point)) (B : mat_Point)))))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(m : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (lemma__collinearorder
                                                               )))
                                                            ) (ASSUME `((col (B : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                           (SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                            (SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                  (SPEC `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(M : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (lemma__collinearorder
                                                             )))
                                                          ) (ASSUME `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                          )))))
                                                 ) (MP  
                                                    (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (m : mat_Point)) (C : mat_Point))) ((mat_or (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (m : mat_Point)))))` 
                                                     (SPEC `(eq (B : mat_Point)) (m : mat_Point)` 
                                                      (or__intror))
                                                    ) (MP  
                                                       (SPEC `(mat_or ((eq (m : mat_Point)) (C : mat_Point))) ((mat_or (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (m : mat_Point))))` 
                                                        (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                         (or__intror))
                                                       ) (MP  
                                                          (SPEC `(mat_or (((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (m : mat_Point)))` 
                                                           (SPEC `(eq (m : mat_Point)) (C : mat_Point)` 
                                                            (or__intror))
                                                          ) (MP  
                                                             (SPEC `(mat_or (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (m : mat_Point))` 
                                                              (SPEC `((betS (m : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (or__intror))
                                                             ) (MP  
                                                                (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (m : mat_Point)` 
                                                                 (SPEC `((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                                                                  (or__introl
                                                                  ))
                                                                ) (ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                                                ))))))))
                                              ) (MP  
                                                 (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))))` 
                                                  (SPEC `(eq (B : mat_Point)) (M : mat_Point)` 
                                                   (or__intror))
                                                 ) (MP  
                                                    (SPEC `(mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))))` 
                                                     (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                      (or__intror))
                                                    ) (MP  
                                                       (SPEC `(mat_or (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                        (SPEC `(eq (M : mat_Point)) (C : mat_Point)` 
                                                         (or__intror))
                                                       ) (MP  
                                                          (SPEC `(mat_or (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                           (SPEC `((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (or__intror))
                                                          ) (MP  
                                                             (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                              (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                               (or__introl))
                                                             ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                             )))))))
                                            ) (MP  
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(M : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (axiom__betweennesssymmetry
                                                  )))
                                               ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                               )))
                                          ) (MP  
                                             (SPEC `(E : mat_Point)` 
                                              (SPEC `(m : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (axiom__betweennesssymmetry))
                                              )
                                             ) (ASSUME `((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point)`
                                             )))
                                        ) (MP  
                                           (DISCH `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                (SPEC `(neq (m : mat_Point)) (C : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (m : mat_Point)) (C : mat_Point)` 
                                                 (DISCH `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(neq (B : mat_Point)) (m : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(neq (B : mat_Point)) (m : mat_Point)` 
                                                       (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                        (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (m : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (m : mat_Point))) ((neq (B : mat_Point)) (C : mat_Point)))`
                                             ))
                                           ) (MP  
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(m : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (lemma__betweennotequal)))
                                              ) (ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                              ))))))
                                  ) (ASSUME `(mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))`
                                  ))))
                            ) (ASSUME `ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (E : mat_Point))) (((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point))))`
                            )))
                         ) (ASSUME `(((cR (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                         ))))
                   ) (ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))`
                   ))))
             ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))`
             )))
          ) (ASSUME `(((cR (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
          ))))))))))
 ;;


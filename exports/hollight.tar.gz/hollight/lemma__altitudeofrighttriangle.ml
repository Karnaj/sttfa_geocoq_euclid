(*lemma__altitudeofrighttriangle :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! M : mat_Point. (! p : mat_Point. ((((per B) A) C) ==> ((((per A) M) p) ==> ((((col B) C) p) ==> ((((col B) C) M) ==> (((betS B) M) C)))))))))`*)
let lemma__altitudeofrighttriangle =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(M : mat_Point)` 
    (GEN `(p : mat_Point)` 
     (DISCH `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
      (DISCH `((per (A : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
       (DISCH `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
        (DISCH `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
         (MP  
          (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
           (MP  
            (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
             (MP  
              (CONV_CONV_rule `(((eq (B : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
               (DISCH `mat_not ((eq (B : mat_Point)) (M : mat_Point))` 
                (MP  
                 (DISCH `((per (p : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                  (MP  
                   (DISCH `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                    (MP  
                     (DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                      (MP  
                       (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                        (MP  
                         (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                          (MP  
                           (DISCH `((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point)` 
                            (MP  
                             (DISCH `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (DISCH `((per (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                (MP  
                                 (DISCH `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                  (MP  
                                   (DISCH `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                    (MP  
                                     (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `((col (C : mat_Point)) (p : mat_Point)) (M : mat_Point)` 
                                        (MP  
                                         (DISCH `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                          (MP  
                                           (DISCH `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `(((eq (C : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                              (DISCH `mat_not ((eq (C : mat_Point)) (M : mat_Point))` 
                                               (MP  
                                                (DISCH `((per (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((per (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((per (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((lt (M : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(((lt (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(((lt (M : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(((cong (M : mat_Point)) (B : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(((lt (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((lt (M : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (C : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__tworays
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (M : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (M : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (M : mat_Point))) ==> (((out (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (M : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((lt (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((lt (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__trichotomy2
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((((cong (B : mat_Point)) (X : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (M : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (M : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false) ==> (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))) (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not (((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (M : mat_Point))) ==> (((out (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((lt (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((lt (C : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (C : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((lt (C : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__trichotomy2
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__lessthantransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (C : mat_Point)) (M : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    lemma__legsmallerhypotenuse
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (M : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (C : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    lemma__legsmallerhypotenuse
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)`
                                                                    )))))))))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                   ) (
                                                                   ASSUME `(((lt (M : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((cong (M : mat_Point)) (B : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                  )))
                                                                ) (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(M : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__lessthantransitive
                                                                    ))))))
                                                                  ) (
                                                                  ASSUME `(((lt (M : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                 )))
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(B : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                ) (ASSUME `(((lt (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                )
                                                               ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                               )))
                                                          ) (SPEC `(A : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (cn__equalityreverse
                                                              ))))
                                                        ) (MP  
                                                           (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)))))` 
                                                            (MP  
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)))))`
                                                                )))
                                                             ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                             ))
                                                           ) (GEN `(A0 : mat_Point)` 
                                                              (GEN `(B0 : mat_Point)` 
                                                               (GEN `(C0 : mat_Point)` 
                                                                (DISCH `((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                   (DISCH `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(C0 : mat_Point)` 
                                                                   (SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    lemma__legsmallerhypotenuse
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)`
                                                                  )))))))))
                                                      ) (MP  
                                                         (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)))))` 
                                                          (MP  
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(M : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)))))`
                                                              )))
                                                           ) (ASSUME `((per (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                           ))
                                                         ) (GEN `(A0 : mat_Point)` 
                                                            (GEN `(B0 : mat_Point)` 
                                                             (GEN `(C0 : mat_Point)` 
                                                              (DISCH `((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                  (SPEC `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                   (SPEC `(((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(((lt (A0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((lt (B0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)`
                                                                    )))
                                                                ) (MP  
                                                                   (SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    lemma__legsmallerhypotenuse
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((per (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)`
                                                                   )))))))))
                                                    ) (MP  
                                                       (SPEC `(A : mat_Point)` 
                                                        (SPEC `(M : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (lemma__8__2)))
                                                       ) (ASSUME `((per (C : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (SPEC `(A : mat_Point)` 
                                                      (SPEC `(M : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (lemma__8__2)))
                                                     ) (ASSUME `((per (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (M : mat_Point))) ==> (((per (C : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(A : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(M : mat_Point)` 
                                                         (SPEC `(p : mat_Point)` 
                                                          (lemma__collinearright
                                                          ))))
                                                      ) (ASSUME `((per (p : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                      )
                                                     ) (ASSUME `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                     ))
                                                   ) (ASSUME `mat_not ((eq (C : mat_Point)) (M : mat_Point))`
                                                   ))))
                                             ) (DISCH `(eq (C : mat_Point)) (M : mat_Point)` 
                                                (MP  
                                                 (DISCH `((per (A : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                  (MP  
                                                   (DISCH `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                    (MP  
                                                     (DISCH `((per (p : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                      (MP  
                                                       (DISCH `((per (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                        (MP  
                                                         (DISCH `mat_not (((per (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                          (MP  
                                                           (CONV_CONV_rule `(((per (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                            (ASSUME `mat_not (((per (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                            )
                                                           ) (ASSUME `((per (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (lemma__8__7))
                                                             )
                                                            ) (ASSUME `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                            )))
                                                       ) (MP  
                                                          (MP  
                                                           (MP  
                                                            (MP  
                                                             (MP  
                                                              (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (M : mat_Point)) ==> ((((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> ((((col (C : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((((per (p : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> (((per (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (M : mat_Point)) (B : mat_Point)) ==> ((((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (M : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (M : mat_Point)) ==> ((((col (M : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> ((((per (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (p : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((per (p : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> (((per (B : mat_Point)) (M : mat_Point)) (A : mat_Point)))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (M : mat_Point)) ==> ((((per (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> ((((per (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (x : mat_Point)) (p : mat_Point)) ==> ((((col (p : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((per (p : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((per (B : mat_Point)) (x : mat_Point)) (A : mat_Point))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((per (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> ((((col (C0 : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (C0 : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (C0 : mat_Point)) ==> ((((col (C0 : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (C0 : mat_Point)) ==> ((((per (C0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (C0 : mat_Point)) (p : mat_Point)) ==> ((((col (p : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) ==> ((((per (p : mat_Point)) (C0 : mat_Point)) (A : mat_Point)) ==> (((per (B : mat_Point)) (C0 : mat_Point)) (A : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (p : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (p : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                )
                                                               ) (ASSUME `((col (C : mat_Point)) (p : mat_Point)) (M : mat_Point)`
                                                               )
                                                              ) (ASSUME `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                              )
                                                             ) (ASSUME `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                             )
                                                            ) (ASSUME `((per (A : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                            )
                                                           ) (ASSUME `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                           )
                                                          ) (ASSUME `((per (p : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                          )))
                                                     ) (MP  
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (MP  
                                                             (MP  
                                                              (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (M : mat_Point)) ==> ((((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> ((((col (C : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((per (p : mat_Point)) (C : mat_Point)) (A : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (M : mat_Point)) (B : mat_Point)) ==> ((((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (M : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (M : mat_Point)) ==> ((((col (M : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> ((((per (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (p : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> (((per (p : mat_Point)) (M : mat_Point)) (A : mat_Point))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (M : mat_Point)) ==> ((((per (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> ((((per (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (x : mat_Point)) (p : mat_Point)) ==> ((((col (p : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((per (p : mat_Point)) (x : mat_Point)) (A : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((per (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> ((((col (C0 : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (C0 : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (C0 : mat_Point)) ==> ((((col (C0 : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (C0 : mat_Point)) ==> ((((per (C0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (C0 : mat_Point)) (p : mat_Point)) ==> ((((col (p : mat_Point)) (C0 : mat_Point)) (B : mat_Point)) ==> (((per (p : mat_Point)) (C0 : mat_Point)) (A : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (p : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (p : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                )
                                                               ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                               )
                                                              ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                              )
                                                             ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                             )
                                                            ) (ASSUME `((col (C : mat_Point)) (p : mat_Point)) (M : mat_Point)`
                                                            )
                                                           ) (ASSUME `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                           )
                                                          ) (ASSUME `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                          )
                                                         ) (ASSUME `((per (A : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                         )
                                                        ) (ASSUME `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                        )))
                                                   ) (MP  
                                                      (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                          (SPEC `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                           (SPEC `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                            (DISCH `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                (SPEC `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                 (SPEC `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                        ))
                                                      ) (MP  
                                                         (SPEC `(p : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (lemma__collinearorder
                                                            )))
                                                         ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                         ))))
                                                 ) (MP  
                                                    (MP  
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (MP  
                                                             (MP  
                                                              (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (CONV_CONV_rule `((eq (C : mat_Point)) (M : mat_Point)) ==> ((((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> ((((col (C : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((per (A : mat_Point)) (C : mat_Point)) (p : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((per (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (M : mat_Point)) (B : mat_Point)) ==> ((((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> (((neq (M : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (M : mat_Point)) ==> ((((col (M : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (M : mat_Point)) ==> ((((per (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((per (A : mat_Point)) (M : mat_Point)) (p : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (M : mat_Point)) ==> ((((per (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> ((((per (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((per (A : mat_Point)) (x : mat_Point)) (p : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ C0 : mat_Point. ((((per (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> ((((col (C0 : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((col (C0 : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C0 : mat_Point)) ==> (((neq (C0 : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C0 : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (C0 : mat_Point)) ==> ((((col (C0 : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> ((((col (p : mat_Point)) (M : mat_Point)) (C0 : mat_Point)) ==> ((((per (C0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((per (A : mat_Point)) (C0 : mat_Point)) (p : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (p : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (A : mat_Point)) (M : mat_Point)) (p : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                   ) (
                                                                   ASSUME `(eq (C : mat_Point)) (M : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                )
                                                               ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                               )
                                                              ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                              )
                                                             ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                             )
                                                            ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                            )
                                                           ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                           )
                                                          ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                          )
                                                         ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                         )
                                                        ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                        )
                                                       ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                       )
                                                      ) (ASSUME `((col (C : mat_Point)) (p : mat_Point)) (M : mat_Point)`
                                                      )
                                                     ) (ASSUME `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                     )
                                                    ) (ASSUME `((per (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                    )))))
                                           ) (MP  
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (lemma__8__2)))
                                              ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                              )))
                                         ) (MP  
                                            (DISCH `(mat_and (((col (p : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point)))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(mat_and (((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point))))` 
                                                 (SPEC `((col (p : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (p : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                  (DISCH `(mat_and (((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point)))` 
                                                       (SPEC `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point)))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point))` 
                                                             (SPEC `((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                              (DISCH `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                                                   (SPEC `((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                ) (ASSUME `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point)))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point))))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((col (p : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (C : mat_Point)))))`
                                              ))
                                            ) (MP  
                                               (SPEC `(M : mat_Point)` 
                                                (SPEC `(p : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (lemma__collinearorder)))
                                               ) (ASSUME `((col (C : mat_Point)) (p : mat_Point)) (M : mat_Point)`
                                               ))))
                                       ) (MP  
                                          (CONV_CONV_rule `((((nCol (C : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (p : mat_Point)) (M : mat_Point))` 
                                           (SPEC `(M : mat_Point)` 
                                            (SPEC `(p : mat_Point)` 
                                             (SPEC `(C : mat_Point)` 
                                              (not__nCol__Col))))
                                          ) (DISCH `((nCol (C : mat_Point)) (p : mat_Point)) (M : mat_Point)` 
                                             (MP  
                                              (MP  
                                               (SPEC `(M : mat_Point)` 
                                                (SPEC `(p : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (col__nCol__False)))
                                               ) (ASSUME `((nCol (C : mat_Point)) (p : mat_Point)) (M : mat_Point)`
                                               )
                                              ) (MP  
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(M : mat_Point)` 
                                                    (SPEC `(p : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (lemma__collinear4))))
                                                   ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                   )
                                                  ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                  )
                                                 ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                 ))))))
                                     ) (MP  
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(C : mat_Point)` 
                                          (lemma__inequalitysymmetric))
                                        ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                        )))
                                   ) (MP  
                                      (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                          (SPEC `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                           (SPEC `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                            (DISCH `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                (SPEC `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                 (SPEC `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                  (DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                      (SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                       (SPEC `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                            (SPEC `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                                              (DISCH `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                               (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                               )))
                                                          ) (ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                              ))))
                                        ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                        ))
                                      ) (MP  
                                         (SPEC `(p : mat_Point)` 
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (lemma__collinearorder)))
                                         ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                         ))))
                                 ) (MP  
                                    (DISCH `(mat_and (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                        (SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))))` 
                                         (SPEC `((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                          (DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                              (SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)))` 
                                               (SPEC `((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                (DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                    (SPEC `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))` 
                                                     (SPEC `((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point)` 
                                                      (DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                          (SPEC `((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                           (SPEC `((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                            (DISCH `((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                             (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                                                             )))
                                                        ) (ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)))))`
                                      ))
                                    ) (MP  
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(M : mat_Point)` 
                                         (SPEC `(p : mat_Point)` 
                                          (lemma__collinearorder)))
                                       ) (ASSUME `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                       ))))
                               ) (MP  
                                  (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (M : mat_Point))) ==> (((per (B : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(A : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(M : mat_Point)` 
                                        (SPEC `(p : mat_Point)` 
                                         (lemma__collinearright))))
                                     ) (ASSUME `((per (p : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                     )
                                    ) (ASSUME `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                    ))
                                  ) (ASSUME `mat_not ((eq (B : mat_Point)) (M : mat_Point))`
                                  )))
                             ) (MP  
                                (DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(mat_and (((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point))))` 
                                     (SPEC `((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                      (DISCH `(mat_and (((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point)))` 
                                           (SPEC `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                            (DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                (SPEC `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point))` 
                                                 (SPEC `((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                  (DISCH `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                      (SPEC `((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point)` 
                                                        (DISCH `((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                         (ASSUME `((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and (((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point))))`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (p : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (p : mat_Point))) (((col (M : mat_Point)) (p : mat_Point)) (B : mat_Point)))))`
                                  ))
                                ) (MP  
                                   (SPEC `(M : mat_Point)` 
                                    (SPEC `(p : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (lemma__collinearorder)))
                                   ) (ASSUME `((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point)`
                                   ))))
                           ) (MP  
                              (CONV_CONV_rule `((((nCol (B : mat_Point)) (p : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (p : mat_Point)) (M : mat_Point))` 
                               (SPEC `(M : mat_Point)` 
                                (SPEC `(p : mat_Point)` 
                                 (SPEC `(B : mat_Point)` (not__nCol__Col))))
                              ) (DISCH `((nCol (B : mat_Point)) (p : mat_Point)) (M : mat_Point)` 
                                 (MP  
                                  (MP  
                                   (SPEC `(M : mat_Point)` 
                                    (SPEC `(p : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (col__nCol__False)))
                                   ) (ASSUME `((nCol (B : mat_Point)) (p : mat_Point)) (M : mat_Point)`
                                   )
                                  ) (MP  
                                     (MP  
                                      (MP  
                                       (SPEC `(M : mat_Point)` 
                                        (SPEC `(p : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(C : mat_Point)` 
                                           (lemma__collinear4))))
                                       ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                       )
                                      ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                      )
                                     ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                     ))))))
                         ) (MP  
                            (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                 (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                  (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                      (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                       (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                        (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                            (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                             (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                              (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                  (SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                    (DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                        (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                         (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                          (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                           (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                ))))
                                          ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))`
                                          ))))
                                    ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))`
                              ))
                            ) (MP  
                               (SPEC `(C : mat_Point)` 
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(B : mat_Point)` (lemma__NCdistinct))
                                )
                               ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                               ))))
                       ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                       ))
                     ) (MP  
                        (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                            (SPEC `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                             (SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                              (DISCH `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                  (SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                   (SPEC `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                    (DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                        (SPEC `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                         (SPEC `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (DISCH `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                              (SPEC `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                               (SPEC `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                (DISCH `((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                 (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((col (M : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                          ))
                        ) (MP  
                           (SPEC `(M : mat_Point)` 
                            (SPEC `(C : mat_Point)` 
                             (SPEC `(B : mat_Point)` (lemma__collinearorder))
                            )
                           ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                           ))))
                   ) (MP  
                      (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                       (MP  
                        (MP  
                         (SPEC `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                          (SPEC `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                           (SPEC `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                            (DISCH `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                (SPEC `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                 (SPEC `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                  (DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                      (SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                       (SPEC `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                            (SPEC `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                             (SPEC `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                              (DISCH `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                               (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                              ))))
                        ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                        ))
                      ) (MP  
                         (SPEC `(p : mat_Point)` 
                          (SPEC `(C : mat_Point)` 
                           (SPEC `(B : mat_Point)` (lemma__collinearorder)))
                         ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                         ))))
                 ) (MP  
                    (SPEC `(p : mat_Point)` 
                     (SPEC `(M : mat_Point)` 
                      (SPEC `(A : mat_Point)` (lemma__8__2)))
                    ) (ASSUME `((per (A : mat_Point)) (M : mat_Point)) (p : mat_Point)`
                    ))))
              ) (DISCH `(eq (B : mat_Point)) (M : mat_Point)` 
                 (MP  
                  (DISCH `((per (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                   (MP  
                    (DISCH `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (DISCH `((per (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                       (MP  
                        (DISCH `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                         (MP  
                          (DISCH `mat_not (((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                           (MP  
                            (CONV_CONV_rule `(((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false` 
                             (ASSUME `mat_not (((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                             )
                            ) (ASSUME `((per (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                            ))
                          ) (MP  
                             (SPEC `(B : mat_Point)` 
                              (SPEC `(A : mat_Point)` 
                               (SPEC `(C : mat_Point)` (lemma__8__7)))
                             ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                             )))
                        ) (MP  
                           (MP  
                            (MP  
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(p : mat_Point)` 
                                 (lemma__collinearright))))
                             ) (ASSUME `((per (p : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                             )
                            ) (ASSUME `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                            )
                           ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`)
                        ))
                      ) (MP  
                         (SPEC `(p : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` (lemma__8__2)))
                         ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                         )))
                    ) (MP  
                       (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                        (MP  
                         (MP  
                          (SPEC `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                           (SPEC `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                            (SPEC `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                             (DISCH `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                              (MP  
                               (MP  
                                (SPEC `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                  (SPEC `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                   (DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                        (SPEC `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (SPEC `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                              (SPEC `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point)` 
                                               (DISCH `((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                (ASSUME `((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                )))
                                           ) (ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                           ))))
                                     ) (ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                     ))))
                               ) (ASSUME `(mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                               ))))
                         ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (C : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (C : mat_Point))) (((col (p : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                         ))
                       ) (MP  
                          (SPEC `(p : mat_Point)` 
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` (lemma__collinearorder)))
                          ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                          ))))
                  ) (MP  
                     (MP  
                      (MP  
                       (MP  
                        (MP  
                         (MP  
                          (CONV_CONV_rule `((eq (B : mat_Point)) (M : mat_Point)) ==> ((((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> ((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (((per (A : mat_Point)) (B : mat_Point)) (p : mat_Point)))))))` 
                           (SPEC `(B : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((((per (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (M : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> ((((nCol (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (M : mat_Point)) ==> (((per (A : mat_Point)) (M : mat_Point)) (p : mat_Point))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (M : mat_Point)) ==> ((((per (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> ((((nCol (x : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (x : mat_Point)) ==> (((per (A : mat_Point)) (x : mat_Point)) (p : mat_Point)))))))))` 
                              (SPEC `\ B0 : mat_Point. ((((per (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> ((((col (B0 : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((col (B0 : mat_Point)) (C : mat_Point)) (M : mat_Point)) ==> ((((nCol (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> (((neq (C : mat_Point)) (B0 : mat_Point)) ==> (((per (A : mat_Point)) (B0 : mat_Point)) (p : mat_Point)))))))` 
                               (SPEC `(M : mat_Point)` 
                                (PINST [(`:mat_Point`,`:A`)] [] (eq__ind__r))
                               ))
                             ) (DISCH `((per (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                (DISCH `((col (M : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                 (DISCH `((col (M : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                  (DISCH `((nCol (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                   (DISCH `(neq (C : mat_Point)) (M : mat_Point)` 
                                    (ASSUME `((per (A : mat_Point)) (M : mat_Point)) (p : mat_Point)`
                                    ))))))))
                          ) (ASSUME `(eq (B : mat_Point)) (M : mat_Point)`)
                         ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                         )
                        ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (p : mat_Point)`
                        )
                       ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                       )
                      ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                      )) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`)))))
            ) (MP  
               (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))` 
                (MP  
                 (MP  
                  (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                   (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                    (SPEC `(neq (B : mat_Point)) (A : mat_Point)` (and__ind))
                   )
                  ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                     (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                      (MP  
                       (MP  
                        (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                         (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                          (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                           (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                            (MP  
                             (MP  
                              (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                               (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                     (SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                      (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                       (DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                           (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                            (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                             (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                              (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                              )))
                                         ) (ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                         ))))
                                   ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                   ))))
                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))`
                             ))))
                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))`
                       ))))
                 ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))`
                 ))
               ) (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(A : mat_Point)` 
                    (SPEC `(B : mat_Point)` (lemma__NCdistinct)))
                  ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                  ))))
          ) (MP  
             (SPEC `(C : mat_Point)` 
              (SPEC `(A : mat_Point)` 
               (SPEC `(B : mat_Point)` (lemma__rightangleNC)))
             ) (ASSUME `((per (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
             )))))))))))
 ;;


(*lemma__paralleldef2B :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((par A) B) C) D) ==> ((((tP A) B) C) D)))))`*)
let lemma__paralleldef2B =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
       (DISCH `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))))))))` 
        (MP  
         (MP  
          (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (x : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
            (SPEC `\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))))))))))))))` 
             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
          ) (GEN `(a : mat_Point)` 
             (DISCH `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))))))` 
              (MP  
               (MP  
                (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((neq (a : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (x : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                  (SPEC `\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))))))))))))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(b : mat_Point)` 
                   (DISCH `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))))` 
                    (MP  
                     (MP  
                      (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (x : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (x : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                        (SPEC `\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))))))))))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(c : mat_Point)` 
                         (DISCH `ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))` 
                          (MP  
                           (MP  
                            (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((neq (c : mat_Point)) (x : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (x : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))) ==> (return : bool)))` 
                              (SPEC `\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))))))))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(d : mat_Point)` 
                               (DISCH `ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (x : mat_Point)) (b : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))) ==> (return : bool)))` 
                                    (SPEC `\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))))))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(e : mat_Point)` 
                                     (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))))` 
                                          (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                           (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))` 
                                                (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))` 
                                                      (SPEC `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                       (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))` 
                                                            (SPEC `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))` 
                                                                  (SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ P : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((((cong (b : mat_Point)) (P : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((((cong (b : mat_Point)) (x : mat_Point)) (e : mat_Point)) (b : mat_Point))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((((cong (b : mat_Point)) (P : mat_Point)) (e : mat_Point)) (b : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ P : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((((cong (b : mat_Point)) (P : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((((cong (b : mat_Point)) (P : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (P : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (P : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point)) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (x : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (M : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (M : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (M : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (M : mat_Point))) ((mat_or ((eq (b : mat_Point)) (M : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (M : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point))) (((betS (a : mat_Point)) (M : mat_Point)) (b : mat_Point))))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (d : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    DISCH `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (C : mat_Point)) (d : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((neq (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (a : mat_Point)) (d : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (d : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__tarskiparallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelcollinear
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (! x : mat_Point. (((eq (x : mat_Point)) (d : mat_Point)) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (x : mat_Point))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (X : mat_Point))` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (C : mat_Point)) (d : mat_Point))) ==> ((eq (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (d : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (C : mat_Point)) (d : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (a : mat_Point)) (d : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (d : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__tarskiparallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelcollinear
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tP (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and ((((tP (A : mat_Point)) (B : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((((tP (B : mat_Point)) (A : mat_Point)) (d : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__tarskiparallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelcollinear
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (c : mat_Point)) (d : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (c : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear5
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ R : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ R : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (D : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__collinear5
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point))) ((mat_and (((col (d : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point))) ((mat_and (((col (d : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point))) ((mat_and (((col (d : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point))) ((mat_and (((col (d : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (D : mat_Point))) ((mat_and (((col (d : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (D : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((col (d : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (D : mat_Point))) (((col (d : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (c : mat_Point))) ((mat_and (((col (D : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (c : mat_Point)) (D : mat_Point))) (((col (c : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (D : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> mat_false) ==> (((col (D : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ R : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (P : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (P : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((mat_and (((betS (d : mat_Point)) (M : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((mat_and (((betS (d : mat_Point)) (M : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (d : mat_Point)) (M : mat_Point)) (P : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (d : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (c : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (d : mat_Point))`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (B : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(eq (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (a : mat_Point)) (A : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (A : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (a : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a : mat_Point)) ==> ((mat_not ((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((mat_not (((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point))) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((betS (M : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((col (a : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)) ==> (((neq (b : mat_Point)) (a : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (a : mat_Point)) ==> (((col (A : mat_Point)) (a : mat_Point)) (b : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (b : mat_Point)) ==> ((((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (B : mat_Point)) ==> ((mat_not ((((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((mat_not (((col (B : mat_Point)) (d : mat_Point)) (P : mat_Point))) ==> ((((betS (B : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((betS (M : mat_Point)) (b : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((neq (b : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> ((((betS (x : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (x : mat_Point)) ==> ((mat_not ((((meet (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((mat_not (((col (x : mat_Point)) (d : mat_Point)) (P : mat_Point))) ==> ((((betS (x : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((betS (M : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((neq (b : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> (((col (A : mat_Point)) (x : mat_Point)) (b : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ a0 : mat_Point. ((((col (A : mat_Point)) (B : mat_Point)) (a0 : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> ((((betS (a0 : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a0 : mat_Point)) ==> ((mat_not ((((meet (a0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((mat_not (((col (a0 : mat_Point)) (d : mat_Point)) (P : mat_Point))) ==> ((((betS (a0 : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((betS (M : mat_Point)) (b : mat_Point)) (a0 : mat_Point)) ==> ((((col (a0 : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (B : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (M : mat_Point)) ==> (((neq (b : mat_Point)) (a0 : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (a0 : mat_Point)) ==> (((col (A : mat_Point)) (a0 : mat_Point)) (b : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (d : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (b : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (M : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (b : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (a : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a : mat_Point)) ==> ((mat_not ((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((mat_not (((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point))) ==> ((((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((betS (M : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> ((((col (a : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)) ==> (((neq (b : mat_Point)) (a : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((neq (A : mat_Point)) (a : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (b : mat_Point)) ==> ((((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (B : mat_Point)) ==> ((mat_not ((((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((mat_not (((col (B : mat_Point)) (d : mat_Point)) (P : mat_Point))) ==> ((((betS (B : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((betS (M : mat_Point)) (b : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((neq (b : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> ((((betS (x : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (x : mat_Point)) ==> ((mat_not ((((meet (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((mat_not (((col (x : mat_Point)) (d : mat_Point)) (P : mat_Point))) ==> ((((betS (x : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((betS (M : mat_Point)) (b : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((neq (b : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((neq (A : mat_Point)) (x : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ a0 : mat_Point. ((((col (A : mat_Point)) (B : mat_Point)) (a0 : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> ((((betS (a0 : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a0 : mat_Point)) ==> ((mat_not ((((meet (a0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((mat_not (((col (a0 : mat_Point)) (d : mat_Point)) (P : mat_Point))) ==> ((((betS (a0 : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((betS (M : mat_Point)) (b : mat_Point)) (a0 : mat_Point)) ==> ((((col (a0 : mat_Point)) (b : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (B : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (M : mat_Point)) ==> (((neq (b : mat_Point)) (a0 : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((neq (A : mat_Point)) (a0 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (d : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (b : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (M : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (b : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    neq__or__eq
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (a : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point))) ((mat_and (((col (b : mat_Point)) (M : mat_Point)) (a : mat_Point))) ((mat_and (((col (M : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (M : mat_Point)) (a : mat_Point))) ((mat_and (((col (M : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (M : mat_Point)) (a : mat_Point))) ((mat_and (((col (M : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (M : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (M : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (M : mat_Point)) (a : mat_Point))) ((mat_and (((col (M : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (a : mat_Point)) (M : mat_Point))) ((mat_and (((col (b : mat_Point)) (M : mat_Point)) (a : mat_Point))) ((mat_and (((col (M : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (M : mat_Point)) (b : mat_Point))) (((col (M : mat_Point)) (b : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (a : mat_Point)) (M : mat_Point))) ((mat_or ((eq (b : mat_Point)) (M : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (M : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point))) (((betS (a : mat_Point)) (M : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (M : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (M : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point))) (((betS (a : mat_Point)) (M : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (b : mat_Point)) (a : mat_Point)) (M : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point))) (((betS (a : mat_Point)) (M : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point))) (((betS (a : mat_Point)) (M : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (a : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (M : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (M : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__outer
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (e : mat_Point))) ((mat_or ((eq (a : mat_Point)) (d : mat_Point))) ((mat_or ((eq (e : mat_Point)) (d : mat_Point))) ((mat_or (((betS (e : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_or (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (d : mat_Point)) (e : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (P : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (e : mat_Point)) (b : mat_Point))) ((mat_or ((eq (e : mat_Point)) (P : mat_Point))) ((mat_or ((eq (b : mat_Point)) (P : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (P : mat_Point))) ((mat_or (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) (((betS (e : mat_Point)) (P : mat_Point)) (b : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (e : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (d : mat_Point)) (P : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((eq (d : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (b : mat_Point))) ((mat_or ((eq (P : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (P : mat_Point)) (c : mat_Point))) ((mat_or (((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (P : mat_Point)) (c : mat_Point)) (b : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (c : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (a : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (a : mat_Point))) (((col (c : mat_Point)) (a : mat_Point)) (b : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> mat_false) ==> (((col (b : mat_Point)) (a : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (b : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (P : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (b : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (P : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (P : mat_Point)) (c : mat_Point))) ((mat_or (((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (P : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (P : mat_Point)) (c : mat_Point))) ((mat_or (((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (P : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (b : mat_Point)) (P : mat_Point)) (c : mat_Point))) ((mat_or (((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (P : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (P : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (P : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (P : mat_Point)) (b : mat_Point)) (a : mat_Point)) ==> mat_false) ==> (((col (P : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (P : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (P : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (d : mat_Point)) (P : mat_Point))) ==> (((col (P : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (d : mat_Point)) (P : mat_Point))`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(eq (d : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (c : mat_Point)) (b : mat_Point))) ((mat_or ((eq (c : mat_Point)) (P : mat_Point))) ((mat_or ((eq (b : mat_Point)) (P : mat_Point))) ((mat_or (((betS (b : mat_Point)) (c : mat_Point)) (P : mat_Point))) ((mat_or (((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point))) (((betS (c : mat_Point)) (P : mat_Point)) (b : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (b : mat_Point)) (e : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or ((eq (e : mat_Point)) (c : mat_Point))) ((mat_or (((betS (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (e : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (e : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (e : mat_Point)) (a : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (e : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (e : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (e : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> mat_false) ==> (((col (e : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (e : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (e : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (d : mat_Point)) (e : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (e : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (e : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (e : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (e : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (e : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (d : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and (((col (b : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((col (e : mat_Point)) (d : mat_Point)) (b : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (d : mat_Point)) (e : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (b : mat_Point)) (d : mat_Point)) (e : mat_Point)) ==> mat_false) ==> (((col (b : mat_Point)) (d : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (b : mat_Point)) (d : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (b : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (P : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (c : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (P : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((col (e : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and (((col (c : mat_Point)) (b : mat_Point)) (e : mat_Point))) ((mat_and (((col (b : mat_Point)) (c : mat_Point)) (e : mat_Point))) (((col (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or ((eq (e : mat_Point)) (c : mat_Point))) ((mat_or (((betS (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (e : mat_Point)) (c : mat_Point))) ((mat_or (((betS (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (e : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point))) (((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (e : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (d : mat_Point)) (P : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)) ==> (((neq (c : mat_Point)) (d : mat_Point)) ==> ((((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> ((((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point)) ==> ((((col (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> ((((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)) ==> (((neq (a : mat_Point)) (d : mat_Point)) ==> ((((col (d : mat_Point)) (P : mat_Point)) (e : mat_Point)) ==> ((((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)) ==> ((((col (P : mat_Point)) (d : mat_Point)) (b : mat_Point)) ==> ((((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)) ==> ((((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)) ==> (((col (c : mat_Point)) (b : mat_Point)) (d : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)) ==> (((neq (c : mat_Point)) (P : mat_Point)) ==> ((((betS (a : mat_Point)) (e : mat_Point)) (P : mat_Point)) ==> ((((col (a : mat_Point)) (P : mat_Point)) (P : mat_Point)) ==> ((((col (a : mat_Point)) (e : mat_Point)) (P : mat_Point)) ==> ((((col (a : mat_Point)) (P : mat_Point)) (e : mat_Point)) ==> (((neq (a : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (P : mat_Point)) (e : mat_Point)) ==> ((((col (e : mat_Point)) (P : mat_Point)) (P : mat_Point)) ==> ((((col (P : mat_Point)) (P : mat_Point)) (b : mat_Point)) ==> ((((col (P : mat_Point)) (P : mat_Point)) (b : mat_Point)) ==> ((((col (P : mat_Point)) (P : mat_Point)) (a : mat_Point)) ==> (((col (c : mat_Point)) (b : mat_Point)) (P : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (P : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point)) ==> (((neq (c : mat_Point)) (x : mat_Point)) ==> ((((betS (a : mat_Point)) (e : mat_Point)) (x : mat_Point)) ==> ((((col (a : mat_Point)) (x : mat_Point)) (P : mat_Point)) ==> ((((col (a : mat_Point)) (e : mat_Point)) (x : mat_Point)) ==> ((((col (a : mat_Point)) (x : mat_Point)) (e : mat_Point)) ==> (((neq (a : mat_Point)) (x : mat_Point)) ==> ((((col (x : mat_Point)) (P : mat_Point)) (e : mat_Point)) ==> ((((col (e : mat_Point)) (P : mat_Point)) (x : mat_Point)) ==> ((((col (P : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (x : mat_Point)) (P : mat_Point)) (b : mat_Point)) ==> ((((col (x : mat_Point)) (P : mat_Point)) (a : mat_Point)) ==> (((col (c : mat_Point)) (b : mat_Point)) (x : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ d0 : mat_Point. ((((col (C : mat_Point)) (D : mat_Point)) (d0 : mat_Point)) ==> (((neq (c : mat_Point)) (d0 : mat_Point)) ==> ((((betS (a : mat_Point)) (e : mat_Point)) (d0 : mat_Point)) ==> ((((col (a : mat_Point)) (d0 : mat_Point)) (P : mat_Point)) ==> ((((col (a : mat_Point)) (e : mat_Point)) (d0 : mat_Point)) ==> ((((col (a : mat_Point)) (d0 : mat_Point)) (e : mat_Point)) ==> (((neq (a : mat_Point)) (d0 : mat_Point)) ==> ((((col (d0 : mat_Point)) (P : mat_Point)) (e : mat_Point)) ==> ((((col (e : mat_Point)) (P : mat_Point)) (d0 : mat_Point)) ==> ((((col (P : mat_Point)) (d0 : mat_Point)) (b : mat_Point)) ==> ((((col (d0 : mat_Point)) (P : mat_Point)) (b : mat_Point)) ==> ((((col (d0 : mat_Point)) (P : mat_Point)) (a : mat_Point)) ==> (((col (c : mat_Point)) (b : mat_Point)) (d0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (a : mat_Point)) (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (P : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (P : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (e : mat_Point)) (P : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (P : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (b : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (d : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (P : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (d : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (c : mat_Point)) (P : mat_Point))) ((mat_or ((eq (b : mat_Point)) (P : mat_Point))) ((mat_or (((betS (b : mat_Point)) (c : mat_Point)) (P : mat_Point))) ((mat_or (((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point))) (((betS (c : mat_Point)) (P : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (P : mat_Point))) ((mat_or (((betS (b : mat_Point)) (c : mat_Point)) (P : mat_Point))) ((mat_or (((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point))) (((betS (c : mat_Point)) (P : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (b : mat_Point)) (c : mat_Point)) (P : mat_Point))) ((mat_or (((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point))) (((betS (c : mat_Point)) (P : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point))) (((betS (c : mat_Point)) (P : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (c : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (b : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (P : mat_Point))) ((mat_and (((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point))) ((mat_and (((col (P : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point))) ((mat_and (((col (P : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (a : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (a : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point))) ((mat_and (((col (P : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point))) ((mat_and (((col (P : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (P : mat_Point))) ((mat_and (((col (d : mat_Point)) (P : mat_Point)) (a : mat_Point))) ((mat_and (((col (P : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (a : mat_Point)) (P : mat_Point)) (d : mat_Point))) (((col (P : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((mat_and (((col (b : mat_Point)) (P : mat_Point)) (d : mat_Point))) ((mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((mat_and (((col (b : mat_Point)) (P : mat_Point)) (d : mat_Point))) ((mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((mat_and (((col (b : mat_Point)) (P : mat_Point)) (d : mat_Point))) ((mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (P : mat_Point)) (d : mat_Point))) ((mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (P : mat_Point)) (d : mat_Point))) ((mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (P : mat_Point)) (d : mat_Point))) ((mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((mat_and (((col (b : mat_Point)) (P : mat_Point)) (d : mat_Point))) ((mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (P : mat_Point)) (b : mat_Point))) ((mat_and (((col (d : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((mat_and (((col (b : mat_Point)) (P : mat_Point)) (d : mat_Point))) ((mat_and (((col (P : mat_Point)) (b : mat_Point)) (d : mat_Point))) (((col (b : mat_Point)) (d : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (d : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (P : mat_Point)) (d : mat_Point)) (b : mat_Point)) ==> mat_false) ==> (((col (P : mat_Point)) (d : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (P : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (P : mat_Point)) (d : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (e : mat_Point)) (P : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (P : mat_Point))) ((mat_and ((neq (e : mat_Point)) (b : mat_Point))) ((neq (e : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (e : mat_Point)) (b : mat_Point))) ((neq (e : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (e : mat_Point)) (b : mat_Point))) ((neq (e : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (e : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (e : mat_Point)) (b : mat_Point))) ((neq (e : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (P : mat_Point))) ((mat_and ((neq (e : mat_Point)) (b : mat_Point))) ((neq (e : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (e : mat_Point)) (P : mat_Point))) ((mat_and (((col (b : mat_Point)) (P : mat_Point)) (e : mat_Point))) ((mat_and (((col (P : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (P : mat_Point)) (e : mat_Point))) ((mat_and (((col (P : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (P : mat_Point)) (e : mat_Point))) ((mat_and (((col (P : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (P : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (P : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (P : mat_Point)) (e : mat_Point))) ((mat_and (((col (P : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (e : mat_Point)) (P : mat_Point))) ((mat_and (((col (b : mat_Point)) (P : mat_Point)) (e : mat_Point))) ((mat_and (((col (P : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((mat_and (((col (e : mat_Point)) (P : mat_Point)) (b : mat_Point))) (((col (P : mat_Point)) (b : mat_Point)) (e : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (e : mat_Point)) (b : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (e : mat_Point)) (P : mat_Point))) ((mat_or ((eq (b : mat_Point)) (P : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (P : mat_Point))) ((mat_or (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) (((betS (e : mat_Point)) (P : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (b : mat_Point)) (P : mat_Point))) ((mat_or (((betS (b : mat_Point)) (e : mat_Point)) (P : mat_Point))) ((mat_or (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) (((betS (e : mat_Point)) (P : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (b : mat_Point)) (e : mat_Point)) (P : mat_Point))) ((mat_or (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) (((betS (e : mat_Point)) (P : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) (((betS (e : mat_Point)) (P : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (b : mat_Point)) (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (e : mat_Point)) (P : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and (((col (P : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (P : mat_Point))) ((mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (P : mat_Point))) ((mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (P : mat_Point))) ((mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (P : mat_Point))) ((mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (P : mat_Point))) ((mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (d : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (d : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (P : mat_Point))) ((mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (P : mat_Point))) ((mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (d : mat_Point)) (e : mat_Point))) ((mat_and (((col (P : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (P : mat_Point))) ((mat_and (((col (d : mat_Point)) (e : mat_Point)) (P : mat_Point))) (((col (e : mat_Point)) (P : mat_Point)) (d : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (P : mat_Point)) (e : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (d : mat_Point)) (P : mat_Point)) (e : mat_Point)) ==> mat_false) ==> (((col (d : mat_Point)) (P : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (d : mat_Point)) (P : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (d : mat_Point)) (P : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (d : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (d : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (e : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (e : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (e : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((col (e : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((col (d : mat_Point)) (a : mat_Point)) (e : mat_Point))) ((mat_and (((col (a : mat_Point)) (d : mat_Point)) (e : mat_Point))) (((col (d : mat_Point)) (e : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (a : mat_Point)) (d : mat_Point))) ((mat_or ((eq (e : mat_Point)) (d : mat_Point))) ((mat_or (((betS (e : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_or (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (d : mat_Point)) (e : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (e : mat_Point)) (d : mat_Point))) ((mat_or (((betS (e : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_or (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (d : mat_Point)) (e : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (e : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_or (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (d : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (d : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (e : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (d : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__3__7b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (e : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((((cong (b : mat_Point)) (P : mat_Point)) (e : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ P : mat_Point. ((mat_and (((betS (e : mat_Point)) (b : mat_Point)) (P : mat_Point))) ((((cong (b : mat_Point)) (P : mat_Point)) (e : mat_Point)) (b : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (e : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (e : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ R : mat_Point. ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ R : mat_Point. ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (B : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(eq (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (R : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (B : mat_Point)) (R : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (R : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (a : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a : mat_Point)) ==> (((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> ((((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (a : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) ==> ((((col (A : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)) ==> ((((col (a : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (a : mat_Point)) ==> ((neq (a : mat_Point)) (A : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (b : mat_Point)) ==> ((((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (B : mat_Point)) ==> (((((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (b : mat_Point)) ==> ((((col (B : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((neq (B : mat_Point)) (A : mat_Point))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> ((((betS (x : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (x : mat_Point)) ==> (((((meet (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> ((((col (x : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((neq (x : mat_Point)) (A : mat_Point)))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ a0 : mat_Point. ((((col (A : mat_Point)) (B : mat_Point)) (a0 : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> ((((betS (a0 : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a0 : mat_Point)) ==> (((((meet (a0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (a0 : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (B : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (a0 : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (a0 : mat_Point)) ==> ((((col (A : mat_Point)) (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (A : mat_Point)) ==> ((((col (a0 : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (a0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (a0 : mat_Point)) ==> ((neq (a0 : mat_Point)) (A : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (b : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (a : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a : mat_Point)) ==> (((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> ((((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (a : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) ==> ((((col (A : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)) ==> ((((col (a : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((neq (A : mat_Point)) (a : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (b : mat_Point)) ==> ((((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (B : mat_Point)) ==> (((((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (b : mat_Point)) ==> ((((col (B : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point)))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> ((((betS (x : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (x : mat_Point)) ==> (((((meet (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> ((((col (x : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((neq (A : mat_Point)) (x : mat_Point))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ a0 : mat_Point. ((((col (A : mat_Point)) (B : mat_Point)) (a0 : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> ((((betS (a0 : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a0 : mat_Point)) ==> (((((meet (a0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (a0 : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (B : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (a0 : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (a0 : mat_Point)) ==> ((((col (A : mat_Point)) (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (A : mat_Point)) ==> ((((col (a0 : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> ((((col (a0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((neq (A : mat_Point)) (a0 : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (b : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (a : mat_Point)) (A : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (A : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (a : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a : mat_Point)) ==> (((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> ((((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (a : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)) ==> (((col (A : mat_Point)) (a : mat_Point)) (b : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (b : mat_Point)) ==> ((((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (B : mat_Point)) ==> (((((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (b : mat_Point)) ==> ((((col (B : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> ((((betS (x : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (x : mat_Point)) ==> (((((meet (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> ((((col (x : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((col (A : mat_Point)) (x : mat_Point)) (b : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ a0 : mat_Point. ((((col (A : mat_Point)) (B : mat_Point)) (a0 : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> ((((betS (a0 : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a0 : mat_Point)) ==> (((((meet (a0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (a0 : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (B : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (((neq (A : mat_Point)) (a0 : mat_Point)) ==> ((((col (B : mat_Point)) (A : mat_Point)) (a0 : mat_Point)) ==> (((col (A : mat_Point)) (a0 : mat_Point)) (b : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (b : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )))))))))
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (b : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (b : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (A : mat_Point))) ((mat_and (((col (b : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (b : mat_Point)) (B : mat_Point))) (((col (b : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (a : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> ((((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a : mat_Point)) ==> (((((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (a : mat_Point)) (b : mat_Point)) ==> ((((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((neq (A : mat_Point)) (a : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (B : mat_Point)) (b : mat_Point)) ==> ((((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (B : mat_Point)) ==> (((((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (B : mat_Point)) (b : mat_Point)) ==> ((((col (B : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((neq (A : mat_Point)) (B : mat_Point)))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> ((((betS (x : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (x : mat_Point)) ==> (((((meet (x : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (x : mat_Point)) (b : mat_Point)) ==> ((((col (x : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((neq (A : mat_Point)) (x : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ a0 : mat_Point. ((((col (A : mat_Point)) (B : mat_Point)) (a0 : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> ((((betS (a0 : mat_Point)) (e : mat_Point)) (d : mat_Point)) ==> (((neq (b : mat_Point)) (a0 : mat_Point)) ==> (((((meet (a0 : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((neq (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (a0 : mat_Point)) (b : mat_Point)) (R : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (R : mat_Point)) ==> ((((col (B : mat_Point)) (a0 : mat_Point)) (b : mat_Point)) ==> ((((col (b : mat_Point)) (a0 : mat_Point)) (B : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> ((((col (a0 : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> ((neq (A : mat_Point)) (a0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((meet (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (b : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(eq (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or ((neq (a : mat_Point)) (B : mat_Point))) ((eq (a : mat_Point)) (B : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    neq__or__eq
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (a : mat_Point)) (A : mat_Point))) ((mat_and (((col (a : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (B : mat_Point))) (((col (a : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (a : mat_Point)) (B : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (a : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (a : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and (((col (b : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (B : mat_Point)) (b : mat_Point)) (a : mat_Point))) (((col (b : mat_Point)) (a : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point))) ((mat_and (((col (b : mat_Point)) (R : mat_Point)) (a : mat_Point))) ((mat_and (((col (R : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (b : mat_Point)) (R : mat_Point)) (a : mat_Point))) ((mat_and (((col (R : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (b : mat_Point)) (R : mat_Point)) (a : mat_Point))) ((mat_and (((col (R : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (R : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (b : mat_Point)) (R : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (R : mat_Point)) (a : mat_Point))) ((mat_and (((col (R : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (b : mat_Point)) (a : mat_Point)) (R : mat_Point))) ((mat_and (((col (b : mat_Point)) (R : mat_Point)) (a : mat_Point))) ((mat_and (((col (R : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (a : mat_Point)) (R : mat_Point)) (b : mat_Point))) (((col (R : mat_Point)) (b : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ R : mat_Point. ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (a : mat_Point)) (b : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (R : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((meet (a : mat_Point)) (b : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (e : mat_Point)) (b : mat_Point))) ((mat_and ((neq (c : mat_Point)) (e : mat_Point))) ((neq (c : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (e : mat_Point))) ((neq (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (e : mat_Point))) ((neq (c : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (e : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (e : mat_Point))) ((neq (c : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (e : mat_Point)) (b : mat_Point))) ((mat_and ((neq (c : mat_Point)) (e : mat_Point))) ((neq (c : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point))))))))))`
                                             ))))
                                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))`
                                       ))))
                                 ) (ASSUME `ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))`
                                 ))))
                           ) (ASSUME `ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))`
                           ))))
                     ) (ASSUME `ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))))`
                     ))))
               ) (ASSUME `ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))))))`
               ))))
         ) (ASSUME `ex (\ a : mat_Point. (ex (\ b : mat_Point. (ex (\ c : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (c : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (e : mat_Point)) (b : mat_Point)))))))))))))))))))))`
         )))
      ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
      ))))))
 ;;


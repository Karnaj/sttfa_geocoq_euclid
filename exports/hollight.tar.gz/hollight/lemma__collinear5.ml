(*lemma__collinear5 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (((neq A) B) ==> ((((col A) B) C) ==> ((((col A) B) D) ==> ((((col A) B) E) ==> (((col C) D) E)))))))))`*)
let lemma__collinear5 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
      (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (DISCH `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
        (DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
         (MP  
          (DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
           (MP  
            (DISCH `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
             (MP  
              (DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
               (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
               )
              ) (MP  
                 (DISCH `(mat_or ((neq (B : mat_Point)) (C : mat_Point))) ((eq (B : mat_Point)) (C : mat_Point))` 
                  (MP  
                   (DISCH `(mat_or ((neq (B : mat_Point)) (C : mat_Point))) ((eq (B : mat_Point)) (C : mat_Point))` 
                    (MP  
                     (DISCH `(mat_or ((neq (B : mat_Point)) (C : mat_Point))) ((eq (B : mat_Point)) (C : mat_Point))` 
                      (MP  
                       (MP  
                        (MP  
                         (SPEC `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                          (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                           (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                            (or__ind)))
                         ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                            (MP  
                             (DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                              (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                              )
                             ) (MP  
                                (CONV_CONV_rule `((((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                 (SPEC `(E : mat_Point)` 
                                  (SPEC `(D : mat_Point)` 
                                   (SPEC `(C : mat_Point)` (not__nCol__Col)))
                                 )
                                ) (DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                   (MP  
                                    (MP  
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (col__nCol__False)))
                                     ) (ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                     )
                                    ) (MP  
                                       (MP  
                                        (MP  
                                         (SPEC `(E : mat_Point)` 
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (lemma__collinear4))))
                                         ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                         )
                                        ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                        )
                                       ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                       )))))))
                        ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                           (MP  
                            (DISCH `((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                             (MP  
                              (DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                               (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                               )
                              ) (MP  
                                 (MP  
                                  (MP  
                                   (MP  
                                    (MP  
                                     (MP  
                                      (MP  
                                       (MP  
                                        (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))))))))` 
                                         (SPEC `(B : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `(((neq (A : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (E : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (x : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (x : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))))))))))` 
                                            (SPEC `\ B0 : mat_Point. (((neq (A : mat_Point)) (B0 : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (B0 : mat_Point)) (E : mat_Point)) ==> ((((col (B0 : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (B0 : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> ((((col (B0 : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))))))))` 
                                             (SPEC `(C : mat_Point)` 
                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                               (eq__ind__r))))
                                           ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                              (DISCH `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                               (DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                 (DISCH `((col (C : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `((col (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                   (DISCH `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                    (ASSUME `((col (C : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                    ))))))))))
                                        ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                        )
                                       ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                       )
                                      ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                      )
                                     ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                     )
                                    ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                    )
                                   ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                   )
                                  ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                  )
                                 ) (ASSUME `((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                 )))
                            ) (MP  
                               (CONV_CONV_rule `((((nCol (B : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                (SPEC `(E : mat_Point)` 
                                 (SPEC `(D : mat_Point)` 
                                  (SPEC `(B : mat_Point)` (not__nCol__Col))))
                               ) (DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `(E : mat_Point)` 
                                     (SPEC `(D : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (col__nCol__False)))
                                    ) (ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                    )
                                   ) (MP  
                                      (MP  
                                       (MP  
                                        (SPEC `(E : mat_Point)` 
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (lemma__collinear4))))
                                        ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                        )
                                       ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                       )
                                      ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                      )))))))
                       ) (ASSUME `(mat_or ((neq (B : mat_Point)) (C : mat_Point))) ((eq (B : mat_Point)) (C : mat_Point))`
                       ))
                     ) (ASSUME `(mat_or ((neq (B : mat_Point)) (C : mat_Point))) ((eq (B : mat_Point)) (C : mat_Point))`
                     ))
                   ) (ASSUME `(mat_or ((neq (B : mat_Point)) (C : mat_Point))) ((eq (B : mat_Point)) (C : mat_Point))`
                   ))
                 ) (SPEC `(C : mat_Point)` 
                    (SPEC `(B : mat_Point)` (neq__or__eq)))))
            ) (MP  
               (CONV_CONV_rule `((((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                (SPEC `(E : mat_Point)` 
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(B : mat_Point)` (not__nCol__Col))))
               ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                  (MP  
                   (MP  
                    (SPEC `(E : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` (col__nCol__False)))
                    ) (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                    )
                   ) (MP  
                      (MP  
                       (MP  
                        (SPEC `(E : mat_Point)` 
                         (SPEC `(C : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` (lemma__collinear4))))
                        ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                        )
                       ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                       )) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`))))
            ))
          ) (MP  
             (CONV_CONV_rule `((((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
              (SPEC `(D : mat_Point)` 
               (SPEC `(C : mat_Point)` 
                (SPEC `(B : mat_Point)` (not__nCol__Col))))
             ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (MP  
                 (MP  
                  (SPEC `(D : mat_Point)` 
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(B : mat_Point)` (col__nCol__False)))
                  ) (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                  )
                 ) (MP  
                    (MP  
                     (MP  
                      (SPEC `(D : mat_Point)` 
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(A : mat_Point)` (lemma__collinear4))))
                      ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                      )
                     ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                     )) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`))))))
        ))))))))
 ;;


(*lemma__congruencetransitive :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (((((cong A) B) C) D) ==> (((((cong C) D) E) F) ==> ((((cong A) B) E) F))))))))`*)
let lemma__congruencetransitive =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
       (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
        (MP  
         (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
          (MP  
           (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
            (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
            )
           ) (MP  
              (MP  
               (SPEC `(D : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(F : mat_Point)` 
                  (SPEC `(E : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (cn__congruencetransitive))))))
               ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
               )
              ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
              )))
         ) (MP  
            (SPEC `(D : mat_Point)` 
             (SPEC `(B : mat_Point)` 
              (SPEC `(A : mat_Point)` 
               (SPEC `(C : mat_Point)` (lemma__congruencesymmetric))))
            ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
            ))))))))))
 ;;


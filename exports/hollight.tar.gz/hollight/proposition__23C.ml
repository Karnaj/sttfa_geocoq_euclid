(*proposition__23C :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! P : mat_Point. (((neq A) B) ==> ((((nCol D) C) E) ==> ((((nCol A) B) P) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out A) B) Y)) ((mat_and ((((((congA X) A) Y) D) C) E)) ((((oS X) P) A) B)))))))))))))))`*)
let proposition__23C =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(P : mat_Point)` 
      (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
       (DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
        (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
         (MP  
          (CONV_CONV_rule `(((eq (P : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))))))` 
           (DISCH `mat_not ((eq (P : mat_Point)) (A : mat_Point))` 
            (MP  
             (DISCH `ex (\ Q : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))))` 
              (MP  
               (MP  
                (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (P : mat_Point)) (A : mat_Point))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))))) ==> (return : bool)))` 
                  (SPEC `\ Q : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(Q : mat_Point)` 
                   (DISCH `(mat_and (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                    (MP  
                     (MP  
                      (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                       (SPEC `(((cong (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                        (SPEC `((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                         (DISCH `(((cong (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                          (MP  
                           (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))))))` 
                            (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                             (MP  
                              (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))))))` 
                               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                (MP  
                                 (CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))))))` 
                                  (DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                   (MP  
                                    (DISCH `ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ G : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (x : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))) ==> (return : bool)))` 
                                         (SPEC `\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (ex__ind))))
                                       ) (GEN `(F : mat_Point)` 
                                          (DISCH `ex (\ G : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                                              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))) ==> (return : bool)))` 
                                               (SPEC `\ G : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (ex__ind))))
                                             ) (GEN `(G : mat_Point)` 
                                                (DISCH `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                                                    (SPEC `(mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                     (SPEC `((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                      (DISCH `(mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                                                          (SPEC `(((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                           (SPEC `(((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                            (DISCH `(((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                             (MP  
                                                              (CONV_CONV_rule `((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))))))` 
                                                               (DISCH `ex (\ J : mat_Point. ((mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                                                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ J : mat_Point. ((mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                  ) (
                                                                  GEN `(J : mat_Point)` 
                                                                  (DISCH `(mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (F : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `(((oS (F : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (x : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (x : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (X : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (X : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (x : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (F : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ==> (ex (\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (F : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (Y : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (F : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((oS (F : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (F : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (F : mat_Point)) (P : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (F : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (F : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (F : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (F : mat_Point)) (U : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (F : mat_Point)) (U : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (V : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (F : mat_Point)) (J : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (J : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))`
                                                                 )))
                                                              ) (ASSUME `(((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))`
                                                  ))))
                                            ) (ASSUME `ex (\ G : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))`
                                            ))))
                                      ) (ASSUME `ex (\ F : mat_Point. (ex (\ G : mat_Point. ((mat_and (((out (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (A : mat_Point)) (G : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((tS (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))`
                                      ))
                                    ) (MP  
                                       (MP  
                                        (MP  
                                         (SPEC `(Q : mat_Point)` 
                                          (SPEC `(E : mat_Point)` 
                                           (SPEC `(D : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(A : mat_Point)` 
                                               (proposition__23B))))))
                                         ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                         )
                                        ) (ASSUME `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                        )
                                       ) (MP  
                                          (SPEC `(Q : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (nCol__notCol)))
                                          ) (ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                          )))))
                                 ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                    (MP  
                                     (CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (A : mat_Point))) ((mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (A : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
                                      (DISCH `((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                       (MP  
                                        (DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (MP  
                                          (DISCH `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                           (MP  
                                            (DISCH `(neq (A : mat_Point)) (Q : mat_Point)` 
                                             (MP  
                                              (DISCH `(neq (Q : mat_Point)) (A : mat_Point)` 
                                               (MP  
                                                (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(P : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (col__nCol__False)))
                                                   ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                   )
                                                  ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                  ))
                                                ) (MP  
                                                   (CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                    (SPEC `(P : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (not__nCol__Col))))
                                                   ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(P : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (col__nCol__False)
                                                          ))
                                                        ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                        )
                                                       ) (MP  
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(P : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (SPEC `(Q : mat_Point)` 
                                                                (lemma__collinear4
                                                                ))))
                                                            ) (ASSUME `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                            )
                                                           ) (ASSUME `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                           )
                                                          ) (ASSUME `(neq (Q : mat_Point)) (A : mat_Point)`
                                                          ))))))
                                              ) (MP  
                                                 (SPEC `(Q : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (lemma__inequalitysymmetric
                                                   ))
                                                 ) (ASSUME `(neq (A : mat_Point)) (Q : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (DISCH `(mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (A : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                   (SPEC `(mat_and ((neq (P : mat_Point)) (A : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                    (SPEC `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                     (DISCH `(mat_and ((neq (P : mat_Point)) (A : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (A : mat_Point)) (Q : mat_Point)` 
                                                         (SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                          (SPEC `(neq (P : mat_Point)) (A : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (P : mat_Point)) (A : mat_Point)` 
                                                           (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                            (ASSUME `(neq (A : mat_Point)) (Q : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and ((neq (P : mat_Point)) (A : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((neq (A : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (A : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))`
                                                 ))
                                               ) (MP  
                                                  (SPEC `(Q : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (SPEC `(P : mat_Point)` 
                                                     (lemma__betweennotequal)
                                                    ))
                                                  ) (ASSUME `((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                  ))))
                                          ) (MP  
                                             (DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                 (SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                                                  (SPEC `((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                   (DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                       (SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                        (SPEC `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                         (DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                             (SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                              (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                               (DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                   (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                   (ASSUME `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                   )))
                                                                 ) (ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)))))`
                                               ))
                                             ) (MP  
                                                (SPEC `(Q : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (SPEC `(P : mat_Point)` 
                                                   (lemma__collinearorder)))
                                                ) (ASSUME `((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                ))))
                                        ) (MP  
                                           (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                               (SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                 (DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                      (SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                       (DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                            (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                   (DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                             ))
                                           ) (MP  
                                              (SPEC `(Q : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (lemma__collinearorder)))
                                              ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                              )))))
                                     ) (MP  
                                        (SPEC `(mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (A : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)))))` 
                                         (SPEC `(eq (P : mat_Point)) (A : mat_Point)` 
                                          (or__intror))
                                        ) (MP  
                                           (SPEC `(mat_or ((eq (A : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))))` 
                                            (SPEC `(eq (P : mat_Point)) (Q : mat_Point)` 
                                             (or__intror))
                                           ) (MP  
                                              (SPEC `(mat_or (((betS (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)))` 
                                               (SPEC `(eq (A : mat_Point)) (Q : mat_Point)` 
                                                (or__intror))
                                              ) (MP  
                                                 (SPEC `(mat_or (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))` 
                                                  (SPEC `((betS (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                   (or__intror))
                                                 ) (MP  
                                                    (SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                     (SPEC `((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                      (or__introl))
                                                    ) (ASSUME `((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                                    ))))))))))
                              ) (MP  
                                 (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                  (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                   (or__intror))
                                 ) (MP  
                                    (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                     (SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                      (or__introl))
                                    ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                    )))))
                           ) (SPEC `(A : mat_Point)` 
                              (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))))
                     ) (ASSUME `(mat_and (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))`
                     ))))
               ) (ASSUME `ex (\ Q : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))))`
               ))
             ) (MP  
                (CONV_CONV_rule `(mat_not ((eq (P : mat_Point)) (A : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (P : mat_Point)) (A : mat_Point)))))` 
                 (MP  
                  (CONV_CONV_rule `(mat_not ((eq (P : mat_Point)) (A : mat_Point))) ==> (((neq (P : mat_Point)) (A : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (P : mat_Point)) (A : mat_Point))))))` 
                   (SPEC `(A : mat_Point)` 
                    (SPEC `(P : mat_Point)` 
                     (SPEC `(A : mat_Point)` 
                      (SPEC `(P : mat_Point)` (lemma__extension)))))
                  ) (ASSUME `mat_not ((eq (P : mat_Point)) (A : mat_Point))`)
                 )) (ASSUME `mat_not ((eq (P : mat_Point)) (A : mat_Point))`)
             )))
          ) (DISCH `(eq (P : mat_Point)) (A : mat_Point)` 
             (MP  
              (DISCH `(eq (A : mat_Point)) (P : mat_Point)` 
               (MP  
                (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                 (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                  (MP  
                   (MP  
                    (SPEC `(P : mat_Point)` 
                     (SPEC `(B : mat_Point)` 
                      (SPEC `(A : mat_Point)` (col__nCol__False)))
                    ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                    )
                   ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                   )))
                ) (MP  
                   (SPEC `(mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point)))))` 
                    (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__intror)
                    )
                   ) (MP  
                      (SPEC `(mat_or ((eq (B : mat_Point)) (P : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((betS (A : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                       (SPEC `(eq (A : mat_Point)) (P : mat_Point)` 
                        (or__introl))
                      ) (ASSUME `(eq (A : mat_Point)) (P : mat_Point)`))))
              ) (MP  
                 (SPEC `(P : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__equalitysymmetric))
                 ) (ASSUME `(eq (P : mat_Point)) (A : mat_Point)`))))))))))))
 )
 ;;


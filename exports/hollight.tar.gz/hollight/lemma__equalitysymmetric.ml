(*lemma__equalitysymmetric :  |- `! A : mat_Point. (! B : mat_Point. (((eq B) A) ==> ((eq A) B)))`*)
let lemma__equalitysymmetric =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (DISCH `(eq (B : mat_Point)) (A : mat_Point)` 
   (MP  
    (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((eq (A : mat_Point)) (B : mat_Point))` 
     (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
      (MP  
       (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> ((eq (A : mat_Point)) (B : mat_Point))` 
        (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
         (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`))
       ) (MP  
          (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((eq (A : mat_Point)) (B : mat_Point))` 
           (MP  
            (CONV_CONV_rule `((eq (B : mat_Point)) (A : mat_Point)) ==> (((eq (A : mat_Point)) (A : mat_Point)) ==> ((eq (A : mat_Point)) (B : mat_Point)))` 
             (SPEC `(A : mat_Point)` 
              (MP  
               (CONV_CONV_rule `(((eq (B : mat_Point)) (B : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point))) ==> (! y : mat_Point. (((eq (B : mat_Point)) (y : mat_Point)) ==> (((eq (y : mat_Point)) (y : mat_Point)) ==> ((eq (y : mat_Point)) (B : mat_Point)))))` 
                (SPEC `\ A0 : mat_Point. (((eq (A0 : mat_Point)) (A0 : mat_Point)) ==> ((eq (A0 : mat_Point)) (B : mat_Point)))` 
                 (SPEC `(B : mat_Point)` 
                  (PINST [(`:mat_Point`,`:A`)] [] (eq__ind))))
               ) (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                  (MP  
                   (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                    (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`)
                   ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`)))))
            ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`))
          ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`))))
    ) (SPEC `(A : mat_Point)` (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))))
 ;;


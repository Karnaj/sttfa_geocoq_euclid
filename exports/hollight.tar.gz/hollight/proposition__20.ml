(*proposition__20 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((triangle A) B) C) ==> ((((((tG B) A) A) C) B) C))))`*)
let proposition__20 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
      (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((eq (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
         (DISCH `mat_not ((eq (B : mat_Point)) (A : mat_Point))` 
          (MP  
           (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
            (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
             (MP  
              (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
               (MP  
                (CONV_CONV_rule `(((eq (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                 (DISCH `mat_not ((eq (C : mat_Point)) (A : mat_Point))` 
                  (MP  
                   (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                    (MP  
                     (MP  
                      (SPEC `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))) ==> (return : bool)))` 
                        (SPEC `\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(D : mat_Point)` 
                         (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                          (MP  
                           (MP  
                            (SPEC `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                              (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                               (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                (MP  
                                 (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                  (MP  
                                   (DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                    (MP  
                                     (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                      (MP  
                                       (DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                        (MP  
                                         (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `((((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                            (DISCH `mat_not (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                             (MP  
                                              (CONV_CONV_rule `(((eq (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                               (DISCH `mat_not ((eq (D : mat_Point)) (C : mat_Point))` 
                                                (MP  
                                                 (CONV_CONV_rule `(((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                  (DISCH `((triangle (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `((mat_and (((triangle (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                     (DISCH `((isosceles (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `((((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                          (DISCH `mat_not (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                           (MP  
                                                            (DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                               (MP  
                                                                (CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                 (DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((ltA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (D : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (U : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (V : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))))))))))) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (X : mat_Point)))))) ==> ((((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (x : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((lt (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__19
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((ltA (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence2
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence2
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (x : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (V : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (U : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (V : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (U : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (V : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (x : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (V : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (V : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and (((out (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (D : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (D : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (D : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (D : mat_Point)) (C : mat_Point))) ==> (((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (D : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) (((betS (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((betS (D : mat_Point)) (x : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (x : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (D : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (D : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (D : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))) ==> (ex (\ V : mat_Point. ((mat_and (((betS (D : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((betS (D : mat_Point)) (A : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))) ((mat_and (((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (D : mat_Point))) ==> (((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (D : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                   ) (
                                                                   SPEC `(B : mat_Point)` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                   ))))
                                                                ) (SPEC `(D : mat_Point)` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                   )))
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                  ) (
                                                                  ASSUME `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                 )))
                                                            ) (MP  
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(A : mat_Point)` 
                                                                  (lemma__ABCequalsCBA
                                                                  )))
                                                               ) (MP  
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                  ) (
                                                                  ASSUME `mat_not (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                  )))))
                                                         ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `(((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                (ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                )
                                                               ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                               ))
                                                             ) (MP  
                                                                (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                   ))))))
                                                       ) (MP  
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (proposition__05
                                                             )))
                                                          ) (ASSUME `((isosceles (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                          ))))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `((triangle (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                          (conj))
                                                        ) (ASSUME `((triangle (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                       ))))
                                                 ) (MP  
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(D : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (nCol__notCol)))
                                                    ) (ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                    ))))
                                              ) (DISCH `(eq (D : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))))) ==> mat_false` 
                                                   (DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `(((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                      (ASSUME `mat_not (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                      )
                                                     ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                     )))
                                                  ) (MP  
                                                     (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                      (SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                       (or__intror))
                                                     ) (MP  
                                                        (SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                         (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                          (or__intror))
                                                        ) (MP  
                                                           (SPEC `(mat_or (((betS (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                            (SPEC `(eq (D : mat_Point)) (C : mat_Point)` 
                                                             (or__introl))
                                                           ) (ASSUME `(eq (D : mat_Point)) (C : mat_Point)`
                                                           ))))))))
                                           ) (DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                              (MP  
                                               (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
                                                (DISCH `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                   (MP  
                                                    (DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (col__nCol__False
                                                                )))
                                                             ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                             )
                                                            ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                            ))
                                                          ) (MP  
                                                             (CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                              (SPEC `(C : mat_Point)` 
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (not__nCol__Col
                                                                 ))))
                                                             ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                  )
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                        ) (ASSUME `(neq (D : mat_Point)) (A : mat_Point)`
                                                        ))
                                                      ) (MP  
                                                         (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                             (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                              (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                               (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                   (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                   (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                   )))
                                                                 ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(D : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (lemma__betweennotequal
                                                               )))
                                                            ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                            (SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                  (SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (lemma__collinearorder
                                                             )))
                                                          ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                          ))))
                                                  ) (MP  
                                                     (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                         (SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                          (SPEC `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                (SPEC `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                 (DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) (((col (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                       ))
                                                     ) (MP  
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(A : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (lemma__collinearorder
                                                           )))
                                                        ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                        )))))
                                               ) (MP  
                                                  (SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                   (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                    (or__intror))
                                                  ) (MP  
                                                     (SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                      (SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                       (or__intror))
                                                     ) (MP  
                                                        (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                         (SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                          (or__intror))
                                                        ) (MP  
                                                           (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                            (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                             (or__intror))
                                                           ) (MP  
                                                              (SPEC `((betS (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                               (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                (or__introl))
                                                              ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                              )))))))))
                                         ) (MP  
                                            (DISCH `(mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                 (SPEC `(((cong (D : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `(mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                        (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                         (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                              ))
                                            ) (MP  
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (lemma__congruenceflip))))
                                               ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                               ))))
                                       ) (MP  
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (lemma__inequalitysymmetric))
                                          ) (ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                          )))
                                     ) (MP  
                                        (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                            (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                             (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                              (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                    (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                     (ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                     )))
                                                ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                          ))
                                        ) (MP  
                                           (SPEC `(D : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (lemma__betweennotequal)))
                                           ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                           ))))
                                   ) (MP  
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (lemma__inequalitysymmetric))
                                      ) (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                      )))
                                 ) (MP  
                                    (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                        (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                         (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                              (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                               (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                 (ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                      ))
                                    ) (MP  
                                       (SPEC `(D : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (lemma__betweennotequal)))
                                       ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                       ))))))
                           ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                           ))))
                     ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                     ))
                   ) (MP  
                      (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (A : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                       (MP  
                        (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (A : mat_Point))) ==> (((neq (C : mat_Point)) (A : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (A : mat_Point))))))` 
                         (SPEC `(A : mat_Point)` 
                          (SPEC `(C : mat_Point)` 
                           (SPEC `(A : mat_Point)` 
                            (SPEC `(B : mat_Point)` (lemma__extension)))))
                        ) (ASSUME `mat_not ((eq (B : mat_Point)) (A : mat_Point))`
                        ))
                      ) (ASSUME `mat_not ((eq (C : mat_Point)) (A : mat_Point))`
                      ))))
                ) (DISCH `(eq (C : mat_Point)) (A : mat_Point)` 
                   (MP  
                    (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                     (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                      (MP  
                       (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (MP  
                         (MP  
                          (SPEC `(C : mat_Point)` 
                           (SPEC `(B : mat_Point)` 
                            (SPEC `(A : mat_Point)` (col__nCol__False)))
                          ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                          )
                         ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                         ))
                       ) (MP  
                          (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                           (MP  
                            (MP  
                             (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                               (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                     (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                      (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                 (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                   (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                   )))
                                              ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                  ))))
                            ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                            ))
                          ) (MP  
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (lemma__collinearorder)))
                             ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                             )))))
                    ) (MP  
                       (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                        (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                         (or__intror))
                       ) (MP  
                          (SPEC `(mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                           (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                            (or__intror))
                          ) (MP  
                             (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                              (SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                               (or__introl))
                             ) (ASSUME `(eq (C : mat_Point)) (A : mat_Point)`
                             )))))))
              ) (MP  
                 (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> ((neq (C : mat_Point)) (B : mat_Point))` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` (lemma__inequalitysymmetric)))
                 ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`))
             ))
           ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
              (MP  
               (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (MP  
                  (MP  
                   (SPEC `(C : mat_Point)` 
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(A : mat_Point)` (col__nCol__False)))
                   ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                   )
                  ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )))
               ) (MP  
                  (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                   (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__intror))
                  ) (MP  
                     (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                      (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                       (or__intror))
                     ) (MP  
                        (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                         (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                          (or__introl))
                        ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`)))))
           )))
        ) (DISCH `(eq (B : mat_Point)) (A : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
             (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
              (MP  
               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (col__nCol__False)))
                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 ))
               ) (MP  
                  (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                   (MP  
                    (MP  
                     (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                             (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                              (DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                   (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                    (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                          (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                           )))
                                      ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                ))))
                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                          ))))
                    ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                    ))
                  ) (MP  
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(A : mat_Point)` 
                       (SPEC `(B : mat_Point)` (lemma__collinearorder)))
                     ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                     )))))
            ) (MP  
               (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                (SPEC `(eq (B : mat_Point)) (A : mat_Point)` (or__introl))
               ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`))))))
     ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
     )))))
 ;;


(*lemma__NChelper :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! P : mat_Point. (! Q : mat_Point. ((((nCol A) B) C) ==> ((((col A) B) P) ==> ((((col A) B) Q) ==> (((neq P) Q) ==> (((nCol P) Q) C)))))))))`*)
let lemma__NChelper =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(P : mat_Point)` 
    (GEN `(Q : mat_Point)` 
     (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
      (DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
       (DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
        (DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
         (MP  
          (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((nCol (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
           (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
            (MP  
             (DISCH `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
              (MP  
               (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                (MP  
                 (DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                  (MP  
                   (DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                    (MP  
                     (DISCH `((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                      (MP  
                       (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                        (MP  
                         (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                          (MP  
                           (CONV_CONV_rule `((((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((nCol (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                            (DISCH `mat_not (((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                             (MP  
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(Q : mat_Point)` 
                                (SPEC `(P : mat_Point)` (nCol__notCol)))
                              ) (ASSUME `mat_not (((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))`
                              )))
                           ) (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (MP  
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(B : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (col__nCol__False)))
                                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                  )
                                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                 ))
                               ) (MP  
                                  (CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(A : mat_Point)` (not__nCol__Col)
                                     )))
                                  ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (MP  
                                      (MP  
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (col__nCol__False)))
                                       ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                       )
                                      ) (MP  
                                         (MP  
                                          (MP  
                                           (MP  
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(A : mat_Point)` 
                                               (SPEC `(Q : mat_Point)` 
                                                (SPEC `(P : mat_Point)` 
                                                 (lemma__collinear5)))))
                                            ) (ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                            )
                                           ) (ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                           )
                                          ) (ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                          )
                                         ) (ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                         ))))))))
                         ) (MP  
                            (DISCH `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)))))` 
                             (MP  
                              (MP  
                               (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                (SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                 (SPEC `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                  (DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                      (SPEC `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                       (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                        (DISCH `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                            (SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                             (SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                              (DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                  (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                   (SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                    (DISCH `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                     (ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                     )))
                                                ) (ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)))`
                                          ))))
                                    ) (ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))))`
                                    ))))
                              ) (ASSUME `(mat_and (((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((mat_and (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)))))`
                              ))
                            ) (MP  
                               (SPEC `(Q : mat_Point)` 
                                (SPEC `(P : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (lemma__collinearorder)))
                               ) (ASSUME `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                               ))))
                       ) (MP  
                          (DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))))` 
                           (MP  
                            (MP  
                             (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                              (SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))))` 
                               (SPEC `((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                (DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                    (SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))` 
                                     (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                      (DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                          (SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                           (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                            (DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                (SPEC `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                 (SPEC `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                  (DISCH `((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                   (ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                   )))
                                              ) (ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point))))`
                                  ))))
                            ) (ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (P : mat_Point))) (((col (Q : mat_Point)) (P : mat_Point)) (A : mat_Point)))))`
                            ))
                          ) (MP  
                             (SPEC `(Q : mat_Point)` 
                              (SPEC `(P : mat_Point)` 
                               (SPEC `(A : mat_Point)` 
                                (lemma__collinearorder)))
                             ) (ASSUME `((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                             ))))
                     ) (MP  
                        (CONV_CONV_rule `((((nCol (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                         (SPEC `(Q : mat_Point)` 
                          (SPEC `(P : mat_Point)` 
                           (SPEC `(A : mat_Point)` (not__nCol__Col))))
                        ) (DISCH `((nCol (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                           (MP  
                            (MP  
                             (SPEC `(Q : mat_Point)` 
                              (SPEC `(P : mat_Point)` 
                               (SPEC `(A : mat_Point)` (col__nCol__False)))
                             ) (ASSUME `((nCol (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                             )
                            ) (MP  
                               (MP  
                                (MP  
                                 (SPEC `(Q : mat_Point)` 
                                  (SPEC `(P : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (lemma__collinear4))))
                                 ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                 )
                                ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                )
                               ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                               ))))))
                   ) (MP  
                      (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                       (MP  
                        (MP  
                         (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                          (SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                           (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                            (DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                (SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                 (SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                  (DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                      (SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                       (SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                        (DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                            (SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                             (SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                              (DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                               (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                              ))))
                        ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                        ))
                      ) (MP  
                         (SPEC `(Q : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` (lemma__collinearorder)))
                         ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                         ))))
                 ) (MP  
                    (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                     (MP  
                      (MP  
                       (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                        (SPEC `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                         (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                          (DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                           (MP  
                            (MP  
                             (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                              (SPEC `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                               (SPEC `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                (DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                    (SPEC `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                     (SPEC `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                      (DISCH `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                          (SPEC `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                           (SPEC `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                            (DISCH `((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                             (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                             )))
                                        ) (ASSUME `(mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                  ))))
                            ) (ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                            ))))
                      ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (B : mat_Point)) (P : mat_Point)) (A : mat_Point))) ((mat_and (((col (P : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) (((col (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                      ))
                    ) (MP  
                       (SPEC `(P : mat_Point)` 
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(A : mat_Point)` (lemma__collinearorder)))
                       ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                       ))))
               ) (MP  
                  (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> ((neq (B : mat_Point)) (A : mat_Point))` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (lemma__inequalitysymmetric)))
                  ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`)
               ))
             ) (MP  
                (CONV_CONV_rule `((((nCol (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                 (SPEC `(Q : mat_Point)` 
                  (SPEC `(P : mat_Point)` 
                   (SPEC `(B : mat_Point)` (not__nCol__Col))))
                ) (DISCH `((nCol (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                   (MP  
                    (MP  
                     (SPEC `(Q : mat_Point)` 
                      (SPEC `(P : mat_Point)` 
                       (SPEC `(B : mat_Point)` (col__nCol__False)))
                     ) (ASSUME `((nCol (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                     )
                    ) (MP  
                       (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))` 
                        (MP  
                         (MP  
                          (SPEC `(Q : mat_Point)` 
                           (SPEC `(P : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(A : mat_Point)` (lemma__collinear4))))
                          ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                          )
                         ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                         ))
                       ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                       )))))))
          ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
             (MP  
              (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (col__nCol__False)))
                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )))
              ) (MP  
                 (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                  (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__introl))
                 ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`))))))))))))
 )
 ;;


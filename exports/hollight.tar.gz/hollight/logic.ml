new_constant("mat_true",`:bool`);;

new_constant("mat_false",`:bool`);;

(*i :  |- `mat_true`*)
let i =

 new_axiom `mat_true`
 ;;

(*false__ind :  |- `! A : bool. (mat_false ==> A)`*)
let false__ind =

 new_axiom `! A : bool. (mat_false ==> (A : bool))`
 ;;

(*mat_not :  |- `mat_not = (\ x : bool. (x ==> mat_false))`*)
let mat_not =

 new_basic_definition `mat_not = (\ x : bool. ((x : bool) ==> mat_false))`
 ;;

let _ = (new_defs := ("mat_not",mat_not)::!new_defs);;

(*mat_and :  |- `mat_and = (\ x : bool. (\ y : bool. (! z : bool. ((x ==> (y ==> z)) ==> z))))`*)
let mat_and =

 new_basic_definition `mat_and = (\ x : bool. (\ y : bool. (! z : bool. (((x : bool) ==> ((y : bool) ==> (z : bool))) ==> (z : bool)))))`
 ;;

let _ = (new_defs := ("mat_and",mat_and)::!new_defs);;

(*mat_or :  |- `mat_or = (\ x : bool. (\ y : bool. (! z : bool. ((x ==> z) ==> ((y ==> z) ==> z)))))`*)
let mat_or =

 new_basic_definition `mat_or = (\ x : bool. (\ y : bool. (! z : bool. (((x : bool) ==> (z : bool)) ==> (((y : bool) ==> (z : bool)) ==> (z : bool))))))`
 ;;

let _ = (new_defs := ("mat_or",mat_or)::!new_defs);;

(*ex :  |- `ex = (\ f : A -> bool. (! z : bool. ((! x : A. ((f x) ==> z)) ==> z)))`*)
let ex =

 new_basic_definition `ex = (\ f : A -> bool. (! z : bool. ((! x : A. (((f : A -> bool) (x : A)) ==> (z : bool))) ==> (z : bool))))`
 ;;

let _ = (new_defs := ("ex",ex)::!new_defs);;

(*and__ind :  |- `! A : bool. (! B : bool. (! P : bool. ((A ==> (B ==> P)) ==> (((mat_and A) B) ==> P))))`*)
let and__ind =

 GEN `(A : bool)` 
 (GEN `(B : bool)` 
  (GEN `(P : bool)` 
   (DISCH `(A : bool) ==> ((B : bool) ==> (P : bool))` 
    (DISCH `(mat_and (A : bool)) (B : bool)` 
     (MP  
      (SPEC `(P : bool)` 
       (CONV_CONV_rule `! z : bool. (((A : bool) ==> ((B : bool) ==> (z : bool))) ==> (z : bool))` 
        (ASSUME `(mat_and (A : bool)) (B : bool)`))
      ) (ASSUME `(A : bool) ==> ((B : bool) ==> (P : bool))`))))))
 ;;

(*or__ind :  |- `! A : bool. (! B : bool. (! P : bool. ((A ==> P) ==> ((B ==> P) ==> (((mat_or A) B) ==> P)))))`*)
let or__ind =

 GEN `(A : bool)` 
 (GEN `(B : bool)` 
  (GEN `(P : bool)` 
   (DISCH `(A : bool) ==> (P : bool)` 
    (DISCH `(B : bool) ==> (P : bool)` 
     (DISCH `(mat_or (A : bool)) (B : bool)` 
      (MP  
       (MP  
        (SPEC `(P : bool)` 
         (CONV_CONV_rule `! z : bool. (((A : bool) ==> (z : bool)) ==> (((B : bool) ==> (z : bool)) ==> (z : bool)))` 
          (ASSUME `(mat_or (A : bool)) (B : bool)`))
        ) (ASSUME `(A : bool) ==> (P : bool)`)
       ) (ASSUME `(B : bool) ==> (P : bool)`)))))))
 ;;

(*ex__ind :  |- `! P : A -> bool. (! return : bool. ((! x : A. ((P x) ==> return)) ==> ((ex P) ==> return)))`*)
let ex__ind =

 GEN `(P : A -> bool)` 
 (GEN `(return : bool)` 
  (DISCH `! x : A. (((P : A -> bool) (x : A)) ==> (return : bool))` 
   (DISCH `(ex : (A -> bool) -> bool) (P : A -> bool)` 
    (MP  
     (SPEC `(return : bool)` 
      (CONV_CONV_rule `! z : bool. ((! x : A. (((P : A -> bool) (x : A)) ==> (z : bool))) ==> (z : bool))` 
       (ASSUME `(ex : (A -> bool) -> bool) (P : A -> bool)`))
     ) (ASSUME `! x : A. (((P : A -> bool) (x : A)) ==> (return : bool))`))))
 )
 ;;

(*conj :  |- `! A : bool. (! B : bool. (A ==> (B ==> ((mat_and A) B))))`*)
let conj =

 CONV_CONV_rule `! A : bool. (! B : bool. ((A : bool) ==> ((B : bool) ==> ((mat_and (A : bool)) (B : bool)))))` 
 (GEN `(A : bool)` 
  (GEN `(B : bool)` 
   (DISCH `(A : bool)` 
    (DISCH `(B : bool)` 
     (GEN `(C : bool)` 
      (DISCH `(A : bool) ==> ((B : bool) ==> (C : bool))` 
       (MP  
        (MP  
         (ASSUME `(A : bool) ==> ((B : bool) ==> (C : bool))`
         ) (ASSUME `(A : bool)`)) (ASSUME `(B : bool)`))))))))
 ;;

(*or__introl :  |- `! A : bool. (! B : bool. (A ==> ((mat_or A) B)))`*)
let or__introl =

 CONV_CONV_rule `! A : bool. (! B : bool. ((A : bool) ==> ((mat_or (A : bool)) (B : bool))))` 
 (GEN `(A : bool)` 
  (GEN `(B : bool)` 
   (DISCH `(A : bool)` 
    (GEN `(C : bool)` 
     (DISCH `(A : bool) ==> (C : bool)` 
      (DISCH `(B : bool) ==> (C : bool)` 
       (MP  (ASSUME `(A : bool) ==> (C : bool)`) (ASSUME `(A : bool)`))))))))
 ;;

(*or__intror :  |- `! A : bool. (! B : bool. (B ==> ((mat_or A) B)))`*)
let or__intror =

 CONV_CONV_rule `! A : bool. (! B : bool. ((B : bool) ==> ((mat_or (A : bool)) (B : bool))))` 
 (GEN `(A : bool)` 
  (GEN `(B : bool)` 
   (DISCH `(B : bool)` 
    (GEN `(C : bool)` 
     (DISCH `(A : bool) ==> (C : bool)` 
      (DISCH `(B : bool) ==> (C : bool)` 
       (MP  (ASSUME `(B : bool) ==> (C : bool)`) (ASSUME `(B : bool)`))))))))
 ;;

(*ex__intro :  |- `! P : A -> bool. (! x : A. ((P x) ==> (ex P)))`*)
let ex__intro =

 CONV_CONV_rule `! P : A -> bool. (! x0 : A. (((P : A -> bool) (x0 : A)) ==> ((ex : (A -> bool) -> bool) (P : A -> bool))))` 
 (GEN `(P : A -> bool)` 
  (GEN `(x : A)` 
   (DISCH `(P : A -> bool) (x : A)` 
    (GEN `(p : bool)` 
     (DISCH `! x0 : A. (((P : A -> bool) (x0 : A)) ==> (p : bool))` 
      (MP  
       (SPEC `(x : A)` 
        (ASSUME `! x0 : A. (((P : A -> bool) (x0 : A)) ==> (p : bool))`)
       ) (ASSUME `(P : A -> bool) (x : A)`)))))))
 ;;

(*eq :  |- `eq = (\ x : A. (\ y : A. (! P : A -> bool. ((P x) ==> (P y)))))`*)
let eq =

 new_basic_definition `eq = (\ x : A. (\ y : A. (! P : A -> bool. (((P : A -> bool) (x : A)) ==> ((P : A -> bool) (y : A))))))`
 ;;

let _ = (new_defs := ("eq",eq)::!new_defs);;

(*eq__refl :  |- `! x : A. ((eq x) x)`*)
let eq__refl =

 CONV_CONV_rule `! x : A. (((eq : A -> (A -> bool)) (x : A)) (x : A))` 
 (GEN `(x : A)` 
  (GEN `(P : A -> bool)` 
   (DISCH `(P : A -> bool) (x : A)` (ASSUME `(P : A -> bool) (x : A)`))))
 ;;

(*eq__trans :  |- `! x : A. (! y : A. (! z : A. (((eq x) y) ==> (((eq y) z) ==> ((eq x) z)))))`*)
let eq__trans =

 CONV_CONV_rule `! x : A. (! y : A. (! z : A. ((((eq : A -> (A -> bool)) (x : A)) (y : A)) ==> ((((eq : A -> (A -> bool)) (y : A)) (z : A)) ==> (((eq : A -> (A -> bool)) (x : A)) (z : A))))))` 
 (GEN `(x : A)` 
  (GEN `(y : A)` 
   (GEN `(z : A)` 
    (DISCH `((eq : A -> (A -> bool)) (x : A)) (y : A)` 
     (DISCH `((eq : A -> (A -> bool)) (y : A)) (z : A)` 
      (GEN `(P : A -> bool)` 
       (DISCH `(P : A -> bool) (x : A)` 
        (MP  
         (SPEC `(P : A -> bool)` 
          (CONV_CONV_rule `! P0 : A -> bool. (((P0 : A -> bool) (y : A)) ==> ((P0 : A -> bool) (z : A)))` 
           (ASSUME `((eq : A -> (A -> bool)) (y : A)) (z : A)`))
         ) (MP  
            (SPEC `(P : A -> bool)` 
             (CONV_CONV_rule `! P0 : A -> bool. (((P0 : A -> bool) (x : A)) ==> ((P0 : A -> bool) (y : A)))` 
              (ASSUME `((eq : A -> (A -> bool)) (x : A)) (y : A)`))
            ) (ASSUME `(P : A -> bool) (x : A)`))))))))))
 ;;

(*eq__ind :  |- `! x : A. (! P : A -> bool. ((P x) ==> (! y : A. (((eq x) y) ==> (P y)))))`*)
let eq__ind =

 GEN `(x : A)` 
 (GEN `(P : A -> bool)` 
  (DISCH `(P : A -> bool) (x : A)` 
   (GEN `(y : A)` 
    (DISCH `((eq : A -> (A -> bool)) (x : A)) (y : A)` 
     (MP  
      (SPEC `(P : A -> bool)` 
       (CONV_CONV_rule `! P0 : A -> bool. (((P0 : A -> bool) (x : A)) ==> ((P0 : A -> bool) (y : A)))` 
        (ASSUME `((eq : A -> (A -> bool)) (x : A)) (y : A)`))
      ) (ASSUME `(P : A -> bool) (x : A)`))))))
 ;;

(*eq__sym :  |- `! x : A. (! y : A. (((eq x) y) ==> ((eq y) x)))`*)
let eq__sym =

 GEN `(x : A)` 
 (GEN `(y : A)` 
  (DISCH `((eq : A -> (A -> bool)) (x : A)) (y : A)` 
   (MP  
    (SPEC `(y : A)` 
     (MP  
      (CONV_CONV_rule `(((eq : A -> (A -> bool)) (x : A)) (x : A)) ==> (! y0 : A. ((((eq : A -> (A -> bool)) (x : A)) (y0 : A)) ==> (((eq : A -> (A -> bool)) (y0 : A)) (x : A))))` 
       (SPEC `\ y0 : A. (((eq : A -> (A -> bool)) (y0 : A)) (x : A))` 
        (SPEC `(x : A)` (PINST [(`:A`,`:A`)] [] (eq__ind))))
      ) (SPEC `(x : A)` (PINST [(`:A`,`:A`)] [] (eq__refl))))
    ) (ASSUME `((eq : A -> (A -> bool)) (x : A)) (y : A)`))))
 ;;

(*eq__ind__r :  |- `! a : A. (! P : A -> bool. ((P a) ==> (! x : A. (((eq x) a) ==> (P x)))))`*)
let eq__ind__r =

 GEN `(a : A)` 
 (GEN `(P : A -> bool)` 
  (DISCH `(P : A -> bool) (a : A)` 
   (GEN `(x0 : A)` 
    (DISCH `((eq : A -> (A -> bool)) (x0 : A)) (a : A)` 
     (MP  
      (SPEC `(x0 : A)` 
       (MP  
        (CONV_CONV_rule `((P : A -> bool) (a : A)) ==> (! y : A. ((((eq : A -> (A -> bool)) (a : A)) (y : A)) ==> ((P : A -> bool) (y : A))))` 
         (SPEC `\ y0 : A. ((P : A -> bool) (y0 : A))` 
          (SPEC `(a : A)` (PINST [(`:A`,`:A`)] [] (eq__ind))))
        ) (ASSUME `(P : A -> bool) (a : A)`))
      ) (MP  
         (SPEC `(a : A)` (SPEC `(x0 : A)` (PINST [(`:A`,`:A`)] [] (eq__sym)))
         ) (ASSUME `((eq : A -> (A -> bool)) (x0 : A)) (a : A)`)))))))
 ;;


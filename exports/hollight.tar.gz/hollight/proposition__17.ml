(*proposition__17 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((triangle A) B) C) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA A) B) C) B) C) A) X) Y) Z))))))))))`*)
let proposition__17 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
      (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (MP  
        (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
         (MP  
          (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
           (MP  
            (MP  
             (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
              (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
               (SPEC `\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
             ) (GEN `(D : mat_Point)` 
                (DISCH `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                 (MP  
                  (MP  
                   (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                    (SPEC `(((cong (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                     (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                      (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (MP  
                        (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                           (DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                              (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                               (MP  
                                (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                 (DISCH `((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                  (MP  
                                   (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                    (MP  
                                     (DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                      (MP  
                                       (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                        (MP  
                                         (DISCH `(((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (MP  
                                           (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                            (MP  
                                             (DISCH `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (MP  
                                               (DISCH `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (x : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))) ==> (return : bool)))` 
                                                    (SPEC `\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))))))))` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (ex__ind))))
                                                  ) (GEN `(a : mat_Point)` 
                                                     (DISCH `ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))) ==> (return : bool)))` 
                                                          (SPEC `\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))))))` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (ex__ind))))
                                                        ) (GEN `(d : mat_Point)` 
                                                           (DISCH `ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))) ==> (return : bool)))` 
                                                                (SPEC `\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__ind)))
                                                               )
                                                              ) (GEN `(e : mat_Point)` 
                                                                 (DISCH `(mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (d : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (d : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (A : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `((triangle (a : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ E : mat_Point. ((mat_and (((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (C : mat_Point)) (e : mat_Point)) (x : mat_Point))) (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. ((mat_and (((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (E : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (E : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (e : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (a : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (C : mat_Point)) (e : mat_Point)) (a : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (a : mat_Point)) (C : mat_Point)) (e : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (e : mat_Point)) (e : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `(eq (e : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (e : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (e : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (e : mat_Point)) (a : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (E : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (F : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (F : mat_Point)) (C : mat_Point))) ((mat_or (((betS (F : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (F : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (E : mat_Point)) (E : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (X : mat_Point)) (B : mat_Point)))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))))` 
                                                                    (
                                                                    DISCH `((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (x : mat_Point)) (Z : mat_Point)))) ==> (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (Y : mat_Point)) (Z : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (Y : mat_Point)) (Z : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (ex (\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point)))))` 
                                                                    (
                                                                    SPEC `\ Z : mat_Point. (((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Z : mat_Point))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((((((((sumA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (x : mat_Point)) (B : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (X : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (X : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (E : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (E : mat_Point))) (((betS (C : mat_Point)) (E : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (E : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (F : mat_Point))) (((betS (C : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (F : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (F : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (F : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (F : mat_Point))) (((col (C : mat_Point)) (F : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (F : mat_Point)) (C : mat_Point))) ((mat_or (((betS (F : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (C : mat_Point))) ((mat_or (((betS (F : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (F : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (F : mat_Point)) (E : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (C : mat_Point)) (e : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (e : mat_Point)) (a : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (e : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (e : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (e : mat_Point)) (e : mat_Point))) (((betS (C : mat_Point)) (e : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (e : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (e : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (e : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (e : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (a : mat_Point)) (C : mat_Point)) (e : mat_Point)) (a : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (a : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (C : mat_Point))) ((mat_and (((col (a : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (C : mat_Point))) ((mat_and (((col (a : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (C : mat_Point))) ((mat_and (((col (a : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (a : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (a : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (a : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (a : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (a : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (a : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (a : mat_Point)) (C : mat_Point))) ((mat_and (((col (a : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (a : mat_Point))) ((mat_and (((col (A : mat_Point)) (a : mat_Point)) (C : mat_Point))) ((mat_and (((col (a : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (a : mat_Point)) (A : mat_Point))) (((col (a : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (e : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (e : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (e : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (e : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (e : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (e : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (e : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (e : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (e : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (e : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (e : mat_Point))) (((nCol (A : mat_Point)) (e : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (e : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (E : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (e : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (E : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_or (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (D : mat_Point)) (A : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (D : mat_Point))) ((mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ E : mat_Point. ((mat_and (((out (C : mat_Point)) (e : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__crossbar
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((triangle (a : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (a : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (d : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (C : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (C : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (C : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (d : mat_Point)) (C : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (d : mat_Point)) (C : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (d : mat_Point)) (C : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (d : mat_Point)) (C : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (C : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (a : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (C : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (d : mat_Point)) (a : mat_Point))) (((nCol (d : mat_Point)) (a : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (a : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (a : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (d : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (d : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (d : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (d : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (d : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (d : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (d : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (d : mat_Point))) (((nCol (A : mat_Point)) (d : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (d : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (d : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__rayimpliescollinear
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((betS (C : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))`
                                                                   ))))
                                                             ) (ASSUME `ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))`
                                                             ))))
                                                       ) (ASSUME `ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))`
                                                       ))))
                                                 ) (ASSUME `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))`
                                                 ))
                                               ) (MP  
                                                  (CONV_CONV_rule `((((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))))))))))` 
                                                   (DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))` 
                                                    (MP  
                                                     (DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))) ==> (return : bool)))` 
                                                          (SPEC `\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))))` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (ex__ind))))
                                                        ) (GEN `(x : mat_Point)` 
                                                           (DISCH `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                               (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))) ==> (return : bool)))` 
                                                                (SPEC `\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (ex__ind)))
                                                               )
                                                              ) (GEN `(x0 : mat_Point)` 
                                                                 (DISCH `ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))))))))))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. (((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x5 : mat_Point. ((ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (x5 : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))) ==> (ex (\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ a : mat_Point. (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x1 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x5 : mat_Point. ((ex (\ e : mat_Point. ((mat_and (((betS (x : mat_Point)) (e : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))) ==> (ex (\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (x : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ d : mat_Point. (ex (\ e : mat_Point. ((mat_and (((betS (x : mat_Point)) (e : mat_Point)) (d : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (d : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x0 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x5 : mat_Point. (((mat_and (((betS (x : mat_Point)) (x5 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x5 : mat_Point))))) ==> (ex (\ e : mat_Point. ((mat_and (((betS (x : mat_Point)) (e : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ e : mat_Point. ((mat_and (((betS (x : mat_Point)) (e : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (e : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (x3 : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x3 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x2 : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x2 : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (x0 : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (x0 : mat_Point))))))`
                                                                   ))))
                                                             ) (ASSUME `ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))`
                                                             ))))
                                                       ) (ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))`
                                                       ))
                                                     ) (ASSUME `ex (\ U : mat_Point. (ex (\ X : mat_Point. (ex (\ V : mat_Point. ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (V : mat_Point))) ((mat_and (((out (C : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (X : mat_Point))))))))))`
                                                     )))
                                                  ) (ASSUME `(((((ltA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                  )))
                                             ) (MP  
                                                (MP  
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (SPEC `(D : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (lemma__angleorderrespectscongruence2
                                                          )))))))))
                                                 ) (ASSUME `(((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                 )
                                                ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                )))
                                           ) (MP  
                                              (SPEC `(C : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (lemma__ABCequalsCBA)))
                                              ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                              )))
                                         ) (MP  
                                            (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. ((((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> ((((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)))))))` 
                                             (MP  
                                              (MP  
                                               (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((((ltA (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                (SPEC `(D : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. ((((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> ((((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)))))))`
                                                    )))))
                                               ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                               )
                                              ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                              ))
                                            ) (GEN `(A0 : mat_Point)` 
                                               (GEN `(B0 : mat_Point)` 
                                                (GEN `(C0 : mat_Point)` 
                                                 (GEN `(D0 : mat_Point)` 
                                                  (DISCH `((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)` 
                                                   (DISCH `((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                       (SPEC `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                        (SPEC `(((((ltA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((((ltA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                         (DISCH `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                          (ASSUME `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                          )))
                                                     ) (MP  
                                                        (MP  
                                                         (SPEC `(D0 : mat_Point)` 
                                                          (SPEC `(C0 : mat_Point)` 
                                                           (SPEC `(B0 : mat_Point)` 
                                                            (SPEC `(A0 : mat_Point)` 
                                                             (proposition__16
                                                             ))))
                                                         ) (ASSUME `((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)`
                                                         )
                                                        ) (ASSUME `((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                        )))))))))))
                                       ) (MP  
                                          (DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                              (SPEC `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                               (SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                (DISCH `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                    (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                     (SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                      (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                          (SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                           (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                            (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                  (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                   (ASSUME `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                   )))
                                                              ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)))))`
                                            ))
                                          ) (MP  
                                             (SPEC `(A : mat_Point)` 
                                              (SPEC `(D : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (lemma__NCorder)))
                                             ) (ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                             ))))
                                     ) (MP  
                                        (SPEC `(A : mat_Point)` 
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (nCol__notCol)))
                                        ) (MP  
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (nCol__not__Col)))
                                           ) (MP  
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (SPEC `(D : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (lemma__NChelper)))))
                                                 ) (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                 )
                                                ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                )
                                               ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                               )
                                              ) (ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                              )))))
                                   ) (MP  
                                      (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                          (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                           (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                            (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                   (ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                   )))
                                              ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                        ))
                                      ) (MP  
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (lemma__betweennotequal)))
                                         ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                         )))))
                                ) (MP  
                                   (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                    (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                       (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                        (or__introl))
                                      ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                      )))))
                             ) (SPEC `(B : mat_Point)` 
                                (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))
                           )
                          ) (MP  
                             (SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                              (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                               (or__intror))
                             ) (MP  
                                (SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                 (SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                  (or__intror))
                                ) (MP  
                                   (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                    (SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                       (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                        (or__intror))
                                      ) (MP  
                                         (SPEC `((betS (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                           (or__introl))
                                         ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                         )))))))
                        ) (MP  
                           (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                            (MP  
                             (MP  
                              (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                               (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                     (SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                      (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                       (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                           (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                            (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                 (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                  (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                   (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                    (ASSUME `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                    )))
                                               ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                         ))))
                                   ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                   ))))
                             ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                             ))
                           ) (MP  
                              (SPEC `(C : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(A : mat_Point)` (lemma__NCorder)))
                              ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                              ))))))
                  ) (ASSUME `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                  ))))
            ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
            ))
          ) (MP  
             (MP  
              (SPEC `(C : mat_Point)` 
               (SPEC `(B : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` (lemma__extension))))
              ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`)
             ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`)))
        ) (MP  
           (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
            (MP  
             (MP  
              (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
               (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)))
              ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                 (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                  (MP  
                   (MP  
                    (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                     (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                      (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                       (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                        (MP  
                         (MP  
                          (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                           (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                            (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                             (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                              (MP  
                               (MP  
                                (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                  (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                   (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                       (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                        (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                         (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                          (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                          )))
                                     ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                     ))))
                               ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                               ))))
                         ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                         ))))
                   ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                   ))))
             ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
             ))
           ) (MP  
              (SPEC `(C : mat_Point)` 
               (SPEC `(B : mat_Point)` 
                (SPEC `(A : mat_Point)` (lemma__NCdistinct)))
              ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
              )))))
     ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
     )))))
 ;;


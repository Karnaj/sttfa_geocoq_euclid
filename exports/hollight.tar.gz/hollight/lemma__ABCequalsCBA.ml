(*lemma__ABCequalsCBA :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((nCol A) B) C) ==> ((((((congA A) B) C) C) B) A))))`*)
let lemma__ABCequalsCBA =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((eq (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
      (DISCH `mat_not ((eq (B : mat_Point)) (A : mat_Point))` 
       (MP  
        (CONV_CONV_rule `(((eq (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
         (DISCH `mat_not ((eq (C : mat_Point)) (B : mat_Point))` 
          (MP  
           (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
            (MP  
             (MP  
              (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                (SPEC `\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
              ) (GEN `(E : mat_Point)` 
                 (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                  (MP  
                   (MP  
                    (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                     (SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                      (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                       (DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (MP  
                         (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                          (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                           (MP  
                            (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                             (MP  
                              (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                   (SPEC `\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind)
                                    )))
                                 ) (GEN `(F : mat_Point)` 
                                    (DISCH `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                        (SPEC `(((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                          (DISCH `(((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                           (MP  
                                            (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `((betS (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((cong (F : mat_Point)) (B : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                           (MP  
                                                            (DISCH `((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                             (MP  
                                                              (CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                               (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))))` 
                                                                   (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                            ) (MP  
                                                               (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((out (B : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                                (MP  
                                                                 (SPEC `(F : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                               ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                               )))
                                                          ) (MP  
                                                             (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (A : mat_Point))) ==> (((out (B : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                              (MP  
                                                               (SPEC `(E : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (lemma__ray4
                                                                  )))
                                                               ) (MP  
                                                                  (SPEC `(mat_or ((eq (E : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                   (SPEC `((betS (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                   (SPEC `(eq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                  ))))
                                                             ) (ASSUME `mat_not ((eq (B : mat_Point)) (A : mat_Point))`
                                                             )))
                                                        ) (SPEC `(F : mat_Point)` 
                                                           (SPEC `(E : mat_Point)` 
                                                            (cn__equalityreverse
                                                            ))))
                                                      ) (MP  
                                                         (SPEC `(F : mat_Point)` 
                                                          (SPEC `(E : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (lemma__congruencesymmetric
                                                             ))))
                                                         ) (ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                         )))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(F : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(F : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (lemma__congruencetransitive
                                                              ))))))
                                                        ) (ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (F : mat_Point)) (B : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                       )))
                                                  ) (SPEC `(B : mat_Point)` 
                                                     (SPEC `(F : mat_Point)` 
                                                      (cn__equalityreverse)))
                                                 )
                                                ) (MP  
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(B : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(F : mat_Point)` 
                                                         (SPEC `(E : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (cn__sumofparts))
                                                          ))))
                                                      ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                      )
                                                     ) (ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                     )
                                                    ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                    )
                                                   ) (ASSUME `((betS (F : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (SPEC `(F : mat_Point)` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (axiom__betweennesssymmetry
                                                    )))
                                                 ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(((cong (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                    (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(((cong (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                      (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                      )))
                                                 ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                 ))
                                               ) (MP  
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (SPEC `(F : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (lemma__doublereverse))
                                                    ))
                                                  ) (ASSUME `(((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                  ))))))
                                      ) (ASSUME `(mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                      ))))
                                ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                ))
                              ) (MP  
                                 (MP  
                                  (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (C : mat_Point)) (X : mat_Point))) ((((cong (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                   (SPEC `(B : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (lemma__extension)))))
                                  ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                  )
                                 ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                 )))
                            ) (MP  
                               (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (A : mat_Point))) ==> ((neq (A : mat_Point)) (B : mat_Point))` 
                                (SPEC `(A : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (lemma__inequalitysymmetric)))
                               ) (ASSUME `mat_not ((eq (B : mat_Point)) (A : mat_Point))`
                               ))))
                         ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                              (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (MP  
                                 (SPEC `(C : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(A : mat_Point)` (col__nCol__False)
                                   ))
                                 ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                 )
                                ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                )))
                             ) (MP  
                                (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                 (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                  (or__intror))
                                ) (MP  
                                   (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                    (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                       (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                        (or__introl))
                                      ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                      )))))))))
                   ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                   ))))
             ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
             ))
           ) (MP  
              (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
               (MP  
                (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (A : mat_Point))) ==> (((neq (C : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(A : mat_Point)` 
                    (SPEC `(B : mat_Point)` (lemma__extension)))))
                ) (ASSUME `mat_not ((eq (B : mat_Point)) (A : mat_Point))`))
              ) (ASSUME `mat_not ((eq (C : mat_Point)) (B : mat_Point))`))))
        ) (DISCH `(eq (C : mat_Point)) (B : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (B : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
             (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
              (MP  
               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (col__nCol__False)))
                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 ))
               ) (MP  
                  (DISCH `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                   (MP  
                    (MP  
                     (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                       (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                        (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                         (MP  
                          (MP  
                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                             (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                              (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                   (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                    (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                           )))
                                      ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                ))))
                          ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                          ))))
                    ) (ASSUME `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                    ))
                  ) (MP  
                     (SPEC `(A : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(C : mat_Point)` (lemma__collinearorder)))
                     ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                     )))))
            ) (MP  
               (SPEC `(mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                (SPEC `(eq (C : mat_Point)) (B : mat_Point)` (or__introl))
               ) (ASSUME `(eq (C : mat_Point)) (B : mat_Point)`))))))
     ) (DISCH `(eq (B : mat_Point)) (A : mat_Point)` 
        (MP  
         (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
          (MP  
           (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
            (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
             (MP  
              (MP  
               (SPEC `(C : mat_Point)` 
                (SPEC `(B : mat_Point)` 
                 (SPEC `(A : mat_Point)` (col__nCol__False)))
               ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
               )
              ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
              )))
           ) (MP  
              (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
               (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__introl))
              ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)))
         ) (MP  
            (SPEC `(B : mat_Point)` 
             (SPEC `(A : mat_Point)` (lemma__equalitysymmetric))
            ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`))))))))
 ;;


(*lemma__equalangleshelper :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! p : mat_Point. (! q : mat_Point. (((((((congA A) B) C) a) b) c) ==> ((((out b) a) p) ==> ((((out b) c) q) ==> ((((((congA A) B) C) p) b) q)))))))))))`*)
let lemma__equalangleshelper =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(a : mat_Point)` 
    (GEN `(b : mat_Point)` 
     (GEN `(c : mat_Point)` 
      (GEN `(p : mat_Point)` 
       (GEN `(q : mat_Point)` 
        (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
         (DISCH `((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point)` 
          (DISCH `((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point))` 
             (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
              (MP  
               (MP  
                (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> (return : bool)))` 
                  (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(U : mat_Point)` 
                   (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                    (MP  
                     (MP  
                      (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool)))` 
                        (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                         (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                      ) (GEN `(V : mat_Point)` 
                         (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                          (MP  
                           (MP  
                            (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool)))` 
                              (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                            ) (GEN `(u : mat_Point)` 
                               (DISCH `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool)))` 
                                    (SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(v : mat_Point)` 
                                     (DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                         (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                          (SPEC `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                           (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                               (SPEC `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                (SPEC `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                 (DISCH `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                     (SPEC `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                      (SPEC `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)` 
                                                       (DISCH `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                           (SPEC `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                            (SPEC `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)` 
                                                             (DISCH `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                 (SPEC `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                  (SPEC `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                   (DISCH `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> ((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (p : mat_Point)) (b : mat_Point)) (q : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(U : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (ex (\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U0 : mat_Point. (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U0 : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U0 : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(V : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (ex (\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V0 : mat_Point. (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V0 : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V0 : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (x : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (ex (\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u0 : mat_Point. (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u0 : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (ex (\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v0 : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v0 : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v0 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (p : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (q : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(v : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(u : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__ray3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
                                             ))))
                                       ) (ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))`
                                       ))))
                                 ) (ASSUME `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))`
                                 ))))
                           ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))`
                           ))))
                     ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))`
                     ))))
               ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
               )))
            ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
            ))))))))))))
 ;;


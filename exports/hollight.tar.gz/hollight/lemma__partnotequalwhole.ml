(*lemma__partnotequalwhole :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((betS A) B) C) ==> (mat_not ((((cong A) B) A) C)))))`*)
let lemma__partnotequalwhole =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
      (MP  
       (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
        (MP  
         (DISCH `ex (\ D : mat_Point. (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
          (MP  
           (MP  
            (SPEC `mat_not ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (return : bool))) ==> ((ex (\ D : mat_Point. (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))) ==> (return : bool)))` 
              (SPEC `\ D : mat_Point. (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(D : mat_Point)` 
               (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                (MP  
                 (DISCH `((betS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                  (MP  
                   (DISCH `((betS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                    (MP  
                     (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `(((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (mat_not ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                        (DISCH `mat_not ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                         (ASSUME `mat_not ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                         ))
                       ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                          (MP  
                           (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                              (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                              )
                             ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                             ))
                           ) (MP  
                              (MP  
                               (MP  
                                (SPEC `(C : mat_Point)` 
                                 (SPEC `(B : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (SPEC `(D : mat_Point)` 
                                    (lemma__extensionunique))))
                                ) (ASSUME `((betS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                )
                               ) (ASSUME `((betS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                               )
                              ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                              )))))
                     ) (MP  
                        (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                             (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                              (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                  (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                    (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                     (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                     )))
                                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                          ))
                        ) (MP  
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(A : mat_Point)` (lemma__betweennotequal)
                             ))
                           ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                           ))))
                   ) (MP  
                      (MP  
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(A : mat_Point)` 
                          (SPEC `(D : mat_Point)` (lemma__3__7b))))
                       ) (ASSUME `((betS (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                       )
                      ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                      )))
                 ) (MP  
                    (SPEC `(D : mat_Point)` 
                     (SPEC `(A : mat_Point)` 
                      (SPEC `(B : mat_Point)` (axiom__betweennesssymmetry)))
                    ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                    )))))
           ) (ASSUME `ex (\ D : mat_Point. (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
           ))
         ) (MP  
            (SPEC `(A : mat_Point)` 
             (SPEC `(B : mat_Point)` (postulate__Euclid2))
            ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`)))
       ) (MP  
          (SPEC `(B : mat_Point)` 
           (SPEC `(A : mat_Point)` (lemma__inequalitysymmetric))
          ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))
     ) (MP  
        (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
         (MP  
          (MP  
           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
            (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
             (SPEC `(neq (B : mat_Point)) (C : mat_Point)` (and__ind)))
           ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
              (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
               (MP  
                (MP  
                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                  (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)))
                 ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                    (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                     (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))
                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                ))))
          ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
          ))
        ) (MP  
           (SPEC `(C : mat_Point)` 
            (SPEC `(B : mat_Point)` 
             (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
           ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
           )))))))
 ;;


(*lemma__interior5 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. ((((betS A) B) C) ==> ((((betS a) b) c) ==> (((((cong A) B) a) b) ==> (((((cong B) C) b) c) ==> (((((cong A) D) a) d) ==> (((((cong C) D) c) d) ==> ((((cong B) D) b) d))))))))))))))`*)
let lemma__interior5 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(a : mat_Point)` 
     (GEN `(b : mat_Point)` 
      (GEN `(c : mat_Point)` 
       (GEN `(d : mat_Point)` 
        (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
         (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
          (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
           (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
            (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
             (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
              (MP  
               (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (CONV_CONV_rule `(((eq (C : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                    (DISCH `mat_not ((eq (C : mat_Point)) (A : mat_Point))` 
                     (MP  
                      (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                       (MP  
                        (MP  
                         (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                           (SPEC `\ M : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                         ) (GEN `(M : mat_Point)` 
                            (DISCH `(mat_and (((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                (SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (SPEC `((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                  (DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                     (MP  
                                      (DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                       (MP  
                                        (DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (MP  
                                          (DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                           (MP  
                                            (DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `(((eq (c : mat_Point)) (a : mat_Point)) ==> mat_false) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                               (DISCH `mat_not ((eq (c : mat_Point)) (a : mat_Point))` 
                                                (MP  
                                                 (DISCH `ex (\ m : mat_Point. ((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (m : mat_Point))) ((((cong (a : mat_Point)) (m : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                     (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((((cong (a : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (m : mat_Point))) ((((cong (a : mat_Point)) (m : mat_Point)) (b : mat_Point)) (c : mat_Point))))) ==> (return : bool)))` 
                                                      (SPEC `\ m : mat_Point. ((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (m : mat_Point))) ((((cong (a : mat_Point)) (m : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                                        (ex__ind))))
                                                    ) (GEN `(m : mat_Point)` 
                                                       (DISCH `(mat_and (((betS (c : mat_Point)) (a : mat_Point)) (m : mat_Point))) ((((cong (a : mat_Point)) (m : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                           (SPEC `(((cong (a : mat_Point)) (m : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                            (SPEC `((betS (c : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((betS (c : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                             (DISCH `(((cong (a : mat_Point)) (m : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(((cong (m : mat_Point)) (a : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(((cong (m : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (m : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (m : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (m : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (c : mat_Point)) (a : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (b : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (M : mat_Point)) (d : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (m : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (D : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (d : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (D : mat_Point)) (m : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (m : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (A : mat_Point)) (m : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (D : mat_Point)) (m : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (D : mat_Point)) (d : mat_Point)) (m : mat_Point))) ((((cong (D : mat_Point)) (M : mat_Point)) (m : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (D : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (M : mat_Point)) (D : mat_Point)) (d : mat_Point)) (m : mat_Point))) ((((cong (D : mat_Point)) (M : mat_Point)) (m : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (D : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (D : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (D : mat_Point)) (d : mat_Point)) (m : mat_Point))) ((((cong (D : mat_Point)) (M : mat_Point)) (m : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (D : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (D : mat_Point)) (M : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (D : mat_Point)) (d : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (D : mat_Point)) (d : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (D : mat_Point)) (M : mat_Point)) (m : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (M : mat_Point)) (D : mat_Point)) (m : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (D : mat_Point)) (d : mat_Point)) (m : mat_Point))) ((((cong (D : mat_Point)) (M : mat_Point)) (m : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (D : mat_Point)) (m : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (D : mat_Point)) (d : mat_Point)) (m : mat_Point))) ((((cong (D : mat_Point)) (M : mat_Point)) (m : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (D : mat_Point)) (M : mat_Point)) (d : mat_Point)) (m : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (a : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (a : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (a : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (a : mat_Point)) (m : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (m : mat_Point)) (a : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (a : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (m : mat_Point)) (a : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (a : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (m : mat_Point)) (a : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (a : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (m : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (m : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (a : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (a : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (m : mat_Point)) (a : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (a : mat_Point)) (m : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (a : mat_Point)) (m : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (m : mat_Point)) (a : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (a : mat_Point)) (m : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (A : mat_Point)) (m : mat_Point)) (a : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (b : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (a : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__3__6a
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (c : mat_Point)) (a : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (c : mat_Point)) (a : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (c : mat_Point)) (a : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (c : mat_Point)) (a : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (c : mat_Point)) (a : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (c : mat_Point)) (a : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (c : mat_Point)) (a : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (m : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (m : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(((cong (m : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                   )))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (a : mat_Point)) (a : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (m : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                               ) (SPEC `(a : mat_Point)` 
                                                                  (SPEC `(m : mat_Point)` 
                                                                   (cn__equalityreverse
                                                                   ))))))
                                                         ) (ASSUME `(mat_and (((betS (c : mat_Point)) (a : mat_Point)) (m : mat_Point))) ((((cong (a : mat_Point)) (m : mat_Point)) (b : mat_Point)) (c : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `ex (\ m : mat_Point. ((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (m : mat_Point))) ((((cong (a : mat_Point)) (m : mat_Point)) (b : mat_Point)) (c : mat_Point))))`
                                                   ))
                                                 ) (MP  
                                                    (MP  
                                                     (CONV_CONV_rule `(mat_not ((eq (c : mat_Point)) (a : mat_Point))) ==> (((neq (b : mat_Point)) (c : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (c : mat_Point)) (a : mat_Point)) (X : mat_Point))) ((((cong (a : mat_Point)) (X : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                      (SPEC `(c : mat_Point)` 
                                                       (SPEC `(b : mat_Point)` 
                                                        (SPEC `(a : mat_Point)` 
                                                         (SPEC `(c : mat_Point)` 
                                                          (lemma__extension))
                                                        )))
                                                     ) (ASSUME `mat_not ((eq (c : mat_Point)) (a : mat_Point))`
                                                     )
                                                    ) (ASSUME `(neq (b : mat_Point)) (c : mat_Point)`
                                                    ))))
                                              ) (DISCH `(eq (c : mat_Point)) (a : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(eq (a : mat_Point)) (c : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `((eq (a : mat_Point)) (c : mat_Point)) ==> mat_false` 
                                                     (ASSUME `(neq (a : mat_Point)) (c : mat_Point)`
                                                     )
                                                    ) (ASSUME `(eq (a : mat_Point)) (c : mat_Point)`
                                                    ))
                                                  ) (MP  
                                                     (SPEC `(c : mat_Point)` 
                                                      (SPEC `(a : mat_Point)` 
                                                       (lemma__equalitysymmetric
                                                       ))
                                                     ) (ASSUME `(eq (c : mat_Point)) (a : mat_Point)`
                                                     )))))
                                            ) (MP  
                                               (DISCH `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                                   (SPEC `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))` 
                                                    (SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                     (DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                                         (SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                                          (SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                           (DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                                            (ASSUME `(neq (a : mat_Point)) (c : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))`
                                                 ))
                                               ) (MP  
                                                  (SPEC `(c : mat_Point)` 
                                                   (SPEC `(b : mat_Point)` 
                                                    (SPEC `(a : mat_Point)` 
                                                     (lemma__betweennotequal)
                                                    ))
                                                  ) (ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                  ))))
                                          ) (MP  
                                             (MP  
                                              (SPEC `(c : mat_Point)` 
                                               (SPEC `(b : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (axiom__nocollapse))))
                                              ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                              )
                                             ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                             )))
                                        ) (MP  
                                           (MP  
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(M : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (SPEC `(M : mat_Point)` 
                                                  (lemma__congruencetransitive
                                                  ))))))
                                            ) (ASSUME `(((cong (M : mat_Point)) (A : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                            )
                                           ) (ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                           )))
                                      ) (MP  
                                         (SPEC `(A : mat_Point)` 
                                          (SPEC `(M : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(M : mat_Point)` 
                                             (lemma__congruencesymmetric))))
                                         ) (ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                         )))
                                    ) (SPEC `(M : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (cn__equalityreverse))))))
                              ) (ASSUME `(mat_and (((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                              ))))
                        ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                        ))
                      ) (MP  
                         (MP  
                          (CONV_CONV_rule `(mat_not ((eq (C : mat_Point)) (A : mat_Point))) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(C : mat_Point)` (lemma__extension)))))
                          ) (ASSUME `mat_not ((eq (C : mat_Point)) (A : mat_Point))`
                          )) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`)
                      )))
                   ) (DISCH `(eq (C : mat_Point)) (A : mat_Point)` 
                      (MP  
                       (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                        (MP  
                         (CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                          (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`)
                         ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`))
                       ) (MP  
                          (SPEC `(C : mat_Point)` 
                           (SPEC `(A : mat_Point)` (lemma__equalitysymmetric)
                           )) (ASSUME `(eq (C : mat_Point)) (A : mat_Point)`)
                       ))))
                 ) (MP  
                    (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                     (MP  
                      (MP  
                       (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                        (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                         (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                          (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                           (MP  
                            (MP  
                             (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                              (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                 (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                 )))
                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                            ))))
                      ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                      ))
                    ) (MP  
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` 
                         (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
                       ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                       ))))
               ) (MP  
                  (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                   (MP  
                    (MP  
                     (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                       (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                        (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                         (MP  
                          (MP  
                           (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                              (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                               (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                               )))
                          ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                          ))))
                    ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                    ))
                  ) (MP  
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
                     ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                     )))))))))))))))))
 ;;


(*lemma__lessthannotequal :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((lt A) B) C) D) ==> ((mat_and ((neq A) B)) ((neq C) D))))))`*)
let lemma__lessthannotequal =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (CONV_CONV_rule `((((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
       (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
        (MP  
         (MP  
          (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
           (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
            (SPEC `\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
          ) (GEN `(E : mat_Point)` 
             (DISCH `(mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
              (MP  
               (MP  
                (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                 (SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                  (SPEC `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                   (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                    (MP  
                     (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                      (MP  
                       (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                        (MP  
                         (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                          (MP  
                           (MP  
                            (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                             (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                              (conj))
                            ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                            )
                           ) (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`)
                          )
                         ) (MP  
                            (DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                (SPEC `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                 (SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                  (DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                      (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                       (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                        (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                         (ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                         )))
                                    ) (ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                              ))
                            ) (MP  
                               (SPEC `(D : mat_Point)` 
                                (SPEC `(E : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (lemma__betweennotequal)))
                               ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                               ))))
                       ) (MP  
                          (MP  
                           (SPEC `(B : mat_Point)` 
                            (SPEC `(A : mat_Point)` 
                             (SPEC `(E : mat_Point)` 
                              (SPEC `(C : mat_Point)` (axiom__nocollapse))))
                           ) (ASSUME `(neq (C : mat_Point)) (E : mat_Point)`)
                          ) (ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                          )))
                     ) (MP  
                        (DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                            (SPEC `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                             (SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                              (DISCH `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                  (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                   (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                    (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                     (ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                     )))
                                ) (ASSUME `(mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (E : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                          ))
                        ) (MP  
                           (SPEC `(D : mat_Point)` 
                            (SPEC `(E : mat_Point)` 
                             (SPEC `(C : mat_Point)` (lemma__betweennotequal)
                             ))
                           ) (ASSUME `((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                           ))))))
               ) (ASSUME `(mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))`
               ))))
         ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((((cong (C : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
         )))
      ) (ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
      ))))))
 ;;


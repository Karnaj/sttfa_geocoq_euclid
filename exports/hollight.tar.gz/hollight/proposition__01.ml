(*proposition__01 :  |- `! A : mat_Point. (! B : mat_Point. (((neq A) B) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral A) B) X)) (((triangle A) B) X))))))`*)
let proposition__01 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
   (MP  
    (DISCH `ex (\ J : mat_Circle. ((((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
     (MP  
      (MP  
       (SPEC `ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
        (CONV_CONV_rule `! return : bool. ((! x : mat_Circle. (((((cI (x : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (return : bool))) ==> ((ex (\ J : mat_Circle. ((((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))) ==> (return : bool)))` 
         (SPEC `\ J : mat_Circle. ((((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
          (PINST [(`:mat_Circle`,`:A`)] [] (ex__ind))))
       ) (GEN `(J : mat_Circle)` 
          (DISCH `(((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
           (MP  
            (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
             (MP  
              (DISCH `ex (\ K : mat_Circle. ((((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
               (MP  
                (MP  
                 (SPEC `ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Circle. (((((cI (x : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> (return : bool))) ==> ((ex (\ K : mat_Circle. ((((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))) ==> (return : bool)))` 
                   (SPEC `\ K : mat_Circle. ((((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                    (PINST [(`:mat_Circle`,`:A`)] [] (ex__ind))))
                 ) (GEN `(K : mat_Circle)` 
                    (DISCH `(((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                     (MP  
                      (DISCH `ex (\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                       (MP  
                        (MP  
                         (SPEC `ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                           (SPEC `\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                         ) (GEN `(D : mat_Point)` 
                            (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                 (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                  (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (MP  
                                    (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                     (MP  
                                      (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))))))) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                       (DISCH `(outCirc (D : mat_Point)) (K : mat_Circle)` 
                                        (MP  
                                         (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                          (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                             (DISCH `(inCirc (B : mat_Point)) (K : mat_Circle)` 
                                              (MP  
                                               (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                  (DISCH `(onCirc (B : mat_Point)) (J : mat_Circle)` 
                                                   (MP  
                                                    (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (D : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                     (DISCH `(onCirc (D : mat_Point)) (J : mat_Circle)` 
                                                      (MP  
                                                       (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                        (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                           (DISCH `(inCirc (A : mat_Point)) (J : mat_Circle)` 
                                                            (MP  
                                                             (DISCH `ex (\ C : mat_Point. ((mat_and ((onCirc (C : mat_Point)) (K : mat_Circle))) ((onCirc (C : mat_Point)) (J : mat_Circle))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((onCirc (x : mat_Point)) (K : mat_Circle))) ((onCirc (x : mat_Point)) (J : mat_Circle))) ==> (return : bool))) ==> ((ex (\ C : mat_Point. ((mat_and ((onCirc (C : mat_Point)) (K : mat_Circle))) ((onCirc (C : mat_Point)) (J : mat_Circle))))) ==> (return : bool)))` 
                                                                  (SPEC `\ C : mat_Point. ((mat_and ((onCirc (C : mat_Point)) (K : mat_Circle))) ((onCirc (C : mat_Point)) (J : mat_Circle)))` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                  ))
                                                                ) (GEN `(C : mat_Point)` 
                                                                   (DISCH `(mat_and ((onCirc (C : mat_Point)) (K : mat_Circle))) ((onCirc (C : mat_Point)) (J : mat_Circle))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    SPEC `(onCirc (C : mat_Point)) (J : mat_Circle)` 
                                                                    (
                                                                    SPEC `(onCirc (C : mat_Point)) (K : mat_Circle)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(onCirc (C : mat_Point)) (K : mat_Circle)` 
                                                                    (
                                                                    DISCH `(onCirc (C : mat_Point)) (J : mat_Circle)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((equilateral (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((triangle (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((equilateral (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__partnotequalwhole
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__partnotequalwhole
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__partnotequalwhole
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__nocollapse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__nocollapse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__equalityreverse
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Circle)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    axiom__circle__center__radius
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(onCirc (C : mat_Point)) (K : mat_Circle)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Circle)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__circle__center__radius
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(onCirc (C : mat_Point)) (J : mat_Circle)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((onCirc (C : mat_Point)) (K : mat_Circle))) ((onCirc (C : mat_Point)) (J : mat_Circle))`
                                                                    ))))
                                                               ) (ASSUME `ex (\ C : mat_Point. ((mat_and ((onCirc (C : mat_Point)) (K : mat_Circle))) ((onCirc (C : mat_Point)) (J : mat_Circle))))`
                                                               ))
                                                             ) (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Circle)` 
                                                                    (
                                                                    SPEC `(K : mat_Circle)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    postulate__circle__circle
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(inCirc (B : mat_Point)) (K : mat_Circle)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(outCirc (D : mat_Point)) (K : mat_Circle)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(onCirc (B : mat_Point)) (J : mat_Circle)`
                                                                 )
                                                                ) (ASSUME `(onCirc (D : mat_Point)) (J : mat_Circle)`
                                                                ))))
                                                          ) (MP  
                                                             (SPEC `(A : mat_Point)` 
                                                              (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))))` 
                                                               (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))))` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (ex__intro))
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(A : mat_Point)` 
                                                                 (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) (x : mat_Point)))))))))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))` 
                                                                  (SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))` 
                                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                ) (MP  
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (x : mat_Point))) ((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) (A : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (U : mat_Point)) (A : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (A : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_and (((betS (A : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (A : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (A : mat_Point)))))))) ==> (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_and (((betS (A : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (A : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_and (((betS (A : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (A : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_and (((betS (A : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (A : mat_Point)))))) ==> (ex (\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_and (((betS (A : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (W : mat_Point))) ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (A : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ W : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (W : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_and (((betS (A : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (W : mat_Point))) ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_and (((betS (A : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_and (((betS (A : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (A : mat_Point)) (A : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                   ))))))))))
                                                       ) (SPEC `(A : mat_Point)` 
                                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                                           (eq__refl)))))
                                                    ) (MP  
                                                       (SPEC `(A : mat_Point)` 
                                                        (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (x : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (D : mat_Point)) (x : mat_Point)) (Y : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (D : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                         (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (D : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))` 
                                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                                           (ex__intro))))
                                                       ) (MP  
                                                          (SPEC `(B : mat_Point)` 
                                                           (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (U : mat_Point)) (D : mat_Point)) (A : mat_Point)) (x : mat_Point))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (A : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (D : mat_Point)) (A : mat_Point)) (Y : mat_Point))))))))` 
                                                            (SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (A : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (D : mat_Point)) (A : mat_Point)) (Y : mat_Point)))))` 
                                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                                              (ex__intro))))
                                                          ) (MP  
                                                             (SPEC `(A : mat_Point)` 
                                                              (CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (J : mat_Circle)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (x : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (U : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                               (SPEC `\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (U : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                                 (ex__intro))
                                                               ))
                                                             ) (MP  
                                                                (MP  
                                                                 (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                  (SPEC `(((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                   (conj))
                                                                 ) (ASSUME `(((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                )))))))
                                                 ) (MP  
                                                    (SPEC `(A : mat_Point)` 
                                                     (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (x : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (x : mat_Point)) (Y : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))))))))))` 
                                                      (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point)))))))` 
                                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                                        (ex__intro))))
                                                    ) (MP  
                                                       (SPEC `(B : mat_Point)` 
                                                        (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (A : mat_Point)) (x : mat_Point))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (A : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (A : mat_Point)) (Y : mat_Point))))))))` 
                                                         (SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (A : mat_Point)) (Y : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (A : mat_Point)) (Y : mat_Point)))))` 
                                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                                           (ex__intro))))
                                                       ) (MP  
                                                          (SPEC `(A : mat_Point)` 
                                                           (CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (J : mat_Circle)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (x : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                            (SPEC `\ U : mat_Point. ((mat_and ((((cI (J : mat_Circle)) (U : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                                              (ex__intro))))
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                (conj))
                                                              ) (ASSUME `(((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                              )
                                                             ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                             ))))))
                                               ) (SPEC `(B : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (cn__congruencereflexive))
                                               )))
                                            ) (MP  
                                               (SPEC `(A : mat_Point)` 
                                                (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))))` 
                                                 (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__intro))))
                                               ) (MP  
                                                  (SPEC `(A : mat_Point)` 
                                                   (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (x : mat_Point)))))))))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))` 
                                                    (SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (ex__intro))))
                                                  ) (MP  
                                                     (SPEC `(B : mat_Point)` 
                                                      (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) (A : mat_Point)))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (A : mat_Point)))))))))))))` 
                                                       (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (A : mat_Point))))))))))` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (ex__intro))))
                                                     ) (MP  
                                                        (SPEC `(B : mat_Point)` 
                                                         (CONV_CONV_rule `! x : mat_Point. ((ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))) ==> (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))))` 
                                                          (SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))))))))` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (ex__intro))))
                                                        ) (MP  
                                                           (SPEC `(A : mat_Point)` 
                                                            (CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))))) ==> (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))))))))` 
                                                             (SPEC `\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (ex__intro))))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                (SPEC `(((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                 (conj))
                                                               ) (ASSUME `(((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                               )
                                                              ) (MP  
                                                                 (SPEC `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((cong (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                  (SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                   (or__introl
                                                                   ))
                                                                 ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                 ))))))))))
                                         ) (SPEC `(B : mat_Point)` 
                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                             (eq__refl)))))
                                      ) (MP  
                                         (SPEC `(A : mat_Point)` 
                                          (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (U : mat_Point)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))))))))` 
                                           (SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))))))))))` 
                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                             (ex__intro))))
                                         ) (MP  
                                            (SPEC `(B : mat_Point)` 
                                             (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (x : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))))))` 
                                              (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (U : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (U : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))))))))` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (ex__intro))))
                                            ) (MP  
                                               (SPEC `(B : mat_Point)` 
                                                (CONV_CONV_rule `! x : mat_Point. ((ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (W : mat_Point)))))) ==> (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point)))))))))` 
                                                 (SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (V : mat_Point)) (W : mat_Point))))))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__intro))))
                                               ) (MP  
                                                  (SPEC `(A : mat_Point)` 
                                                   (CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)))) ==> (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (W : mat_Point)))))))` 
                                                    (SPEC `\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (W : mat_Point))) ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (W : mat_Point))))` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (ex__intro))))
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                       (SPEC `(((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (conj))
                                                      ) (ASSUME `(((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                      )
                                                     ) (MP  
                                                        (MP  
                                                         (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                          (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                           (conj))
                                                         ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                        ))))))))
                                    ) (SPEC `(A : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (cn__congruencereflexive))))))
                              ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                              ))))
                        ) (ASSUME `ex (\ D : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                        ))
                      ) (MP  
                         (MP  
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` 
                            (SPEC `(B : mat_Point)` (lemma__localextension)))
                          ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`)
                         ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))
                    ))
                ) (ASSUME `ex (\ K : mat_Circle. ((((cI (K : mat_Circle)) (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                ))
              ) (MP  
                 (SPEC `(A : mat_Point)` 
                  (SPEC `(B : mat_Point)` (postulate__Euclid3))
                 ) (ASSUME `(neq (B : mat_Point)) (A : mat_Point)`)))
            ) (MP  
               (SPEC `(B : mat_Point)` 
                (SPEC `(A : mat_Point)` (lemma__inequalitysymmetric))
               ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))))
      ) (ASSUME `ex (\ J : mat_Circle. ((((cI (J : mat_Circle)) (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
      ))
    ) (MP  
       (SPEC `(B : mat_Point)` (SPEC `(A : mat_Point)` (postulate__Euclid3))
       ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)))))
 ;;


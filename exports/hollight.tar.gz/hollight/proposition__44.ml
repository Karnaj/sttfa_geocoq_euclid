(*proposition__44 :  |- `! A : mat_Point. (! B : mat_Point. (! D : mat_Point. (! J : mat_Point. (! N : mat_Point. (! R : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. ((((triangle a) b) c) ==> ((((nCol J) D) N) ==> ((((nCol A) B) R) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG A) B) X) Y)) ((mat_and ((((((congA A) B) X) J) D) N)) ((mat_and ((((((((eF a) b) Z) c) A) B) X) Y)) ((mat_and (((midpoint b) Z) c)) ((((tS X) A) B) R))))))))))))))))))))))`*)
let proposition__44 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(D : mat_Point)` 
   (GEN `(J : mat_Point)` 
    (GEN `(N : mat_Point)` 
     (GEN `(R : mat_Point)` 
      (GEN `(a : mat_Point)` 
       (GEN `(b : mat_Point)` 
        (GEN `(c : mat_Point)` 
         (DISCH `((triangle (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
          (DISCH `((nCol (J : mat_Point)) (D : mat_Point)) (N : mat_Point)` 
           (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
            (MP  
             (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
              (MP  
               (CONV_CONV_rule `(((triangle (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                (DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                 (MP  
                  (DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                   (MP  
                    (DISCH `ex (\ m : mat_Point. ((mat_and (((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point))))` 
                     (MP  
                      (MP  
                       (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (b : mat_Point)) (x : mat_Point)) (c : mat_Point))) ((((cong (x : mat_Point)) (b : mat_Point)) (x : mat_Point)) (c : mat_Point))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and (((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point))))) ==> (return : bool)))` 
                         (SPEC `\ m : mat_Point. ((mat_and (((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)))` 
                          (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                       ) (GEN `(m : mat_Point)` 
                          (DISCH `(mat_and (((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point))` 
                           (MP  
                            (MP  
                             (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                              (SPEC `(((cong (m : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                               (SPEC `((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                (DISCH `(((cong (m : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                 (MP  
                                  (DISCH `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((mat_and (((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                     (DISCH `((midpoint (b : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                      (MP  
                                       (DISCH `(neq (m : mat_Point)) (c : mat_Point)` 
                                        (MP  
                                         (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (m : mat_Point)) (c : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point))))) ==> (return : bool)))` 
                                              (SPEC `\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point)))` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (ex__ind))))
                                            ) (GEN `(E : mat_Point)` 
                                               (DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                   (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                    (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                     (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                        (MP  
                                                         (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                          (DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                           (MP  
                                                            (DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                             (MP  
                                                              (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                               (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                (MP  
                                                                 (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (A : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                  (DISCH `((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ g : mat_Point. (ex (\ e : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ e : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (x : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (x : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ g : mat_Point. (ex (\ e : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ g : mat_Point. (ex (\ e : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(g : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ e : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((out (B : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (x : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ e : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ Q : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (b : mat_Point)) (m : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (m : mat_Point))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (b : mat_Point)) (m : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Q : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (b : mat_Point)) (m : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (E : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (b : mat_Point)) (m : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (b : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (E : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (b : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (Q : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((midpoint (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ G : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ F : mat_Point. ((mat_and ((((pG (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (x : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (x : mat_Point)) (B : mat_Point)) (E : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ G : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(G : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ F : mat_Point. ((mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ F : mat_Point. ((mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((pG (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. (ex (\ L : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ L : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (x : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (x : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. (ex (\ L : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. (ex (\ L : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ L : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (x : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))))) ==> (return : bool))) ==> ((ex (\ L : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ L : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))))` 
                                                                    (
                                                                    DISCH `(((tS (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (R : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))) ==> (ex (\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (Y : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (Y : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (x : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (x : mat_Point)) (c : mat_Point))) ((((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))) ==> (ex (\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ Z : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (Z : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (Z : mat_Point)) (c : mat_Point))) ((((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and (((midpoint (b : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((midpoint (b : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((midpoint (b : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((midpoint (b : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__oppositesidesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((tS (R : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (G : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (G : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesideflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__samesidecollinear
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (A : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) (A : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(L : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    axiom__EFtransitive
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (G : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (G : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (G : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((nCol (G : mat_Point)) (B : mat_Point)) (F : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)) ==> ((((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (L : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (L : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> ((((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (B : mat_Point)) (G : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ L : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. (ex (\ L : mat_Point. ((mat_and ((((pG (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (L : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((mat_and ((((((((eF (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (L : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (B : mat_Point)) (M : mat_Point))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__44A
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((pG (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__PGrotate
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ F : mat_Point. ((mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ G : mat_Point. (ex (\ F : mat_Point. ((mat_and ((((pG (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (G : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (G : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> ((((midpoint (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) ==> ((((nCol (J : mat_Point)) (D : mat_Point)) (N : mat_Point)) ==> ((((midpoint (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point)) ==> ((((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (ex (\ X : mat_Point. (ex (\ Z : mat_Point. ((mat_and ((((pG (X : mat_Point)) (B : mat_Point)) (E : mat_Point)) (Z : mat_Point))) ((mat_and ((((((((eF (a : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (X : mat_Point)) (B : mat_Point)) (E : mat_Point)) (Z : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (B : mat_Point)) (X : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (R : mat_Point)) (X : mat_Point)) (B : mat_Point)) (E : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    proposition__42B
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (b : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (J : mat_Point)) (D : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (Q : mat_Point)) (B : mat_Point))) ((neq (Q : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (R : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (E : mat_Point))) (((nCol (R : mat_Point)) (E : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (E : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (m : mat_Point)) (c : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (b : mat_Point)) (m : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (m : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (b : mat_Point)) (m : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (m : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (b : mat_Point)) (m : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (m : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (m : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (m : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (b : mat_Point)) (m : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (m : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (Q : mat_Point)) (m : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (B : mat_Point)) (b : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (B : mat_Point)) (b : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (m : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (b : mat_Point)) (m : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (m : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (m : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (B : mat_Point)) (b : mat_Point)) (m : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (m : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (b : mat_Point)) (m : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (E : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (b : mat_Point)) (m : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Q : mat_Point. ((mat_and (((betS (E : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((((cong (B : mat_Point)) (Q : mat_Point)) (b : mat_Point)) (m : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (b : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (m : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (m : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (b : mat_Point)) (m : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (m : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (m : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (m : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (b : mat_Point)) (m : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (m : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (m : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (m : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(m : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (P : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (P : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((neq (B : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ P : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__extension
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ e : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ g : mat_Point. (ex (\ e : mat_Point. ((mat_and (((out (B : mat_Point)) (E : mat_Point)) (e : mat_Point))) ((mat_and ((((((congA (g : mat_Point)) (B : mat_Point)) (e : mat_Point)) (J : mat_Point)) (D : mat_Point)) (N : mat_Point))) ((((oS (g : mat_Point)) (R : mat_Point)) (B : mat_Point)) (E : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(J : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__23C
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (J : mat_Point)) (D : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (E : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (R : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (R : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (R : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (R : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (R : mat_Point)) (B : mat_Point))) (((nCol (R : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (B : mat_Point))) (((betS (B : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                              ) (SPEC `(B : mat_Point)` 
                                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                                  (eq__refl))
                                                              ))
                                                            ) (MP  
                                                               (DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                   (SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                  (DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((col (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(E : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((col (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                  )))))
                                                         ) (MP  
                                                            (SPEC `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                             (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                              (or__intror))
                                                            ) (MP  
                                                               (SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                (SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (MP  
                                                                  (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)))` 
                                                                   (SPEC `(eq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                                   (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                  )))))))
                                                       ) (MP  
                                                          (DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                              (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                                               (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                   (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point)))`
                                                            ))
                                                          ) (MP  
                                                             (SPEC `(E : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (lemma__betweennotequal
                                                                )))
                                                             ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                             ))))))
                                                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point))`
                                                 ))))
                                           ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (m : mat_Point)) (c : mat_Point))))`
                                           ))
                                         ) (MP  
                                            (MP  
                                             (SPEC `(c : mat_Point)` 
                                              (SPEC `(m : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (lemma__extension))))
                                             ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                             )
                                            ) (ASSUME `(neq (m : mat_Point)) (c : mat_Point)`
                                            )))
                                       ) (MP  
                                          (DISCH `(mat_and ((neq (m : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (m : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(neq (m : mat_Point)) (c : mat_Point)` 
                                              (SPEC `(mat_and ((neq (b : mat_Point)) (m : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))` 
                                               (SPEC `(neq (m : mat_Point)) (c : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (m : mat_Point)) (c : mat_Point)` 
                                                (DISCH `(mat_and ((neq (b : mat_Point)) (m : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(neq (m : mat_Point)) (c : mat_Point)` 
                                                    (SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                     (SPEC `(neq (b : mat_Point)) (m : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(neq (b : mat_Point)) (m : mat_Point)` 
                                                      (DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                                       (ASSUME `(neq (m : mat_Point)) (c : mat_Point)`
                                                       )))
                                                  ) (ASSUME `(mat_and ((neq (b : mat_Point)) (m : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((neq (m : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (m : mat_Point))) ((neq (b : mat_Point)) (c : mat_Point)))`
                                            ))
                                          ) (MP  
                                             (SPEC `(c : mat_Point)` 
                                              (SPEC `(m : mat_Point)` 
                                               (SPEC `(b : mat_Point)` 
                                                (lemma__betweennotequal)))
                                             ) (ASSUME `((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                             )))))
                                    ) (MP  
                                       (MP  
                                        (SPEC `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                         (SPEC `((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                          (conj))
                                        ) (ASSUME `((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                        )
                                       ) (ASSUME `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                       )))
                                  ) (MP  
                                     (DISCH `(mat_and ((((cong (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (m : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (c : mat_Point)) (m : mat_Point)))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                         (SPEC `(mat_and ((((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (c : mat_Point)) (m : mat_Point))` 
                                          (SPEC `(((cong (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(((cong (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                           (DISCH `(mat_and ((((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (c : mat_Point)) (m : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                               (SPEC `(((cong (m : mat_Point)) (b : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                                (SPEC `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)` 
                                                 (DISCH `(((cong (m : mat_Point)) (b : mat_Point)) (c : mat_Point)) (m : mat_Point)` 
                                                  (ASSUME `(((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                                  )))
                                             ) (ASSUME `(mat_and ((((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (c : mat_Point)) (m : mat_Point))`
                                             ))))
                                       ) (ASSUME `(mat_and ((((cong (b : mat_Point)) (m : mat_Point)) (c : mat_Point)) (m : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (m : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (c : mat_Point)) (m : mat_Point)))`
                                       ))
                                     ) (MP  
                                        (SPEC `(c : mat_Point)` 
                                         (SPEC `(m : mat_Point)` 
                                          (SPEC `(b : mat_Point)` 
                                           (SPEC `(m : mat_Point)` 
                                            (lemma__congruenceflip))))
                                        ) (ASSUME `(((cong (m : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point)`
                                        ))))))
                            ) (ASSUME `(mat_and (((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point))`
                            ))))
                      ) (ASSUME `ex (\ m : mat_Point. ((mat_and (((betS (b : mat_Point)) (m : mat_Point)) (c : mat_Point))) ((((cong (m : mat_Point)) (b : mat_Point)) (m : mat_Point)) (c : mat_Point))))`
                      ))
                    ) (MP  
                       (SPEC `(c : mat_Point)` 
                        (SPEC `(b : mat_Point)` (proposition__10))
                       ) (ASSUME `(neq (b : mat_Point)) (c : mat_Point)`)))
                  ) (MP  
                     (DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))))))` 
                      (MP  
                       (MP  
                        (SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                         (SPEC `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))))` 
                          (SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                           (DISCH `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))))` 
                            (MP  
                             (MP  
                              (SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                               (SPEC `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))))` 
                                (SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                 (DISCH `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                     (SPEC `(mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))` 
                                      (SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (a : mat_Point)) (c : mat_Point)` 
                                       (DISCH `(mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                           (SPEC `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))` 
                                            (SPEC `(neq (b : mat_Point)) (a : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                             (DISCH `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                 (SPEC `(neq (c : mat_Point)) (a : mat_Point)` 
                                                  (SPEC `(neq (c : mat_Point)) (b : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(neq (c : mat_Point)) (b : mat_Point)` 
                                                   (DISCH `(neq (c : mat_Point)) (a : mat_Point)` 
                                                    (ASSUME `(neq (b : mat_Point)) (c : mat_Point)`
                                                    )))
                                               ) (ASSUME `(mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))`
                                         ))))
                                   ) (ASSUME `(mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))))`
                                   ))))
                             ) (ASSUME `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point)))))`
                             ))))
                       ) (ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((mat_and ((neq (a : mat_Point)) (c : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (c : mat_Point)) (b : mat_Point))) ((neq (c : mat_Point)) (a : mat_Point))))))`
                       ))
                     ) (MP  
                        (SPEC `(c : mat_Point)` 
                         (SPEC `(b : mat_Point)` 
                          (SPEC `(a : mat_Point)` (lemma__NCdistinct)))
                        ) (ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                        )))))
               ) (ASSUME `((triangle (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
               ))
             ) (MP  
                (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point))))))` 
                 (MP  
                  (MP  
                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                    (SPEC `(mat_and ((neq (B : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point)))))` 
                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)
                     ))
                   ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                      (DISCH `(mat_and ((neq (B : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point)))))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                          (SPEC `(mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point))))` 
                           (SPEC `(neq (B : mat_Point)) (R : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (B : mat_Point)) (R : mat_Point)` 
                            (DISCH `(mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                (SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point)))` 
                                 (SPEC `(neq (A : mat_Point)) (R : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (A : mat_Point)) (R : mat_Point)` 
                                  (DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                      (SPEC `(mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point))` 
                                       (SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                        (DISCH `(mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                            (SPEC `(neq (R : mat_Point)) (A : mat_Point)` 
                                             (SPEC `(neq (R : mat_Point)) (B : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (R : mat_Point)) (B : mat_Point)` 
                                              (DISCH `(neq (R : mat_Point)) (A : mat_Point)` 
                                               (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point))))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (B : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point)))))`
                        ))))
                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (R : mat_Point))) ((mat_and ((neq (A : mat_Point)) (R : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (R : mat_Point)) (B : mat_Point))) ((neq (R : mat_Point)) (A : mat_Point))))))`
                  ))
                ) (MP  
                   (SPEC `(R : mat_Point)` 
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(A : mat_Point)` (lemma__NCdistinct)))
                   ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                   )))))))))))))))
 ;;


(*lemma__TGsymmetric :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((tG A) a) B) b) C) c) ==> ((((((tG B) b) A) a) C) c)))))))`*)
let lemma__TGsymmetric =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(a : mat_Point)` 
    (GEN `(b : mat_Point)` 
     (GEN `(c : mat_Point)` 
      (DISCH `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
       (MP  
        (CONV_CONV_rule `((((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((((tG (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point))` 
         (DISCH `ex (\ H0 : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (H0 : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (H0 : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H0 : mat_Point)))))` 
          (MP  
           (MP  
            (SPEC `(((((tG (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (x : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ H1 : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (H1 : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H1 : mat_Point)))))) ==> (return : bool)))` 
              (SPEC `\ H1 : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (H1 : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H1 : mat_Point))))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(H1 : mat_Point)` 
               (DISCH `(mat_and (((betS (A : mat_Point)) (a : mat_Point)) (H1 : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H1 : mat_Point)))` 
                (MP  
                 (MP  
                  (SPEC `(((((tG (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                   (SPEC `(mat_and ((((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H1 : mat_Point))` 
                    (SPEC `((betS (A : mat_Point)) (a : mat_Point)) (H1 : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((betS (A : mat_Point)) (a : mat_Point)) (H1 : mat_Point)` 
                     (DISCH `(mat_and ((((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H1 : mat_Point))` 
                      (MP  
                       (MP  
                        (SPEC `(((((tG (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                         (SPEC `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H1 : mat_Point)` 
                          (SPEC `(((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                           (DISCH `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H1 : mat_Point)` 
                            (MP  
                             (DISCH `(neq (a : mat_Point)) (H1 : mat_Point)` 
                              (MP  
                               (DISCH `(neq (B : mat_Point)) (b : mat_Point)` 
                                (MP  
                                 (DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                  (MP  
                                   (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(((((tG (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                       (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((((cong (b : mat_Point)) (x : mat_Point)) (A : mat_Point)) (a : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))))) ==> (return : bool)))` 
                                        (SPEC `\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)))` 
                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                          (ex__ind))))
                                      ) (GEN `(F : mat_Point)` 
                                         (DISCH `(mat_and (((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(((((tG (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                             (SPEC `(((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                              (SPEC `((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                               (DISCH `(((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((cong (a : mat_Point)) (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                    (MP  
                                                     (DISCH `(((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                      (MP  
                                                       (DISCH `((betS (F : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(((cong (A : mat_Point)) (H1 : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(((lt (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (X : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (X : mat_Point)))))) ==> ((((((tG (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point))` 
                                                                (DISCH `(((((tG (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                 (ASSUME `(((((tG (B : mat_Point)) (b : mat_Point)) (A : mat_Point)) (a : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(F : mat_Point)` 
                                                                   (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (x : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (X : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (X : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (X : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(mat_and ((((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(((lt (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)` 
                                                                    (conj))
                                                                   ) (
                                                                   ASSUME `(((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                  )))))
                                                             ) (MP  
                                                                (MP  
                                                                 (SPEC `(F : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (SPEC `(H1 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                 ) (ASSUME `(((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H1 : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                )))
                                                           ) (MP  
                                                              (DISCH `(mat_and ((((cong (H1 : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (H1 : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point)))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                  (SPEC `(mat_and ((((cong (H1 : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                   (SPEC `(((cong (H1 : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(((cong (H1 : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (H1 : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (H1 : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (H1 : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (H1 : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((((cong (H1 : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (H1 : mat_Point)) (A : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (F : mat_Point)))`
                                                                ))
                                                              ) (MP  
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(F : mat_Point)` 
                                                                   (SPEC `(H1 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                 ) (ASSUME `(((cong (A : mat_Point)) (H1 : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                 ))))
                                                         ) (MP  
                                                            (MP  
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(B : mat_Point)` 
                                                                (SPEC `(b : mat_Point)` 
                                                                 (SPEC `(F : mat_Point)` 
                                                                  (SPEC `(H1 : mat_Point)` 
                                                                   (SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    cn__sumofparts
                                                                    ))))))
                                                               ) (ASSUME `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                               )
                                                              ) (ASSUME `(((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point)`
                                                              )
                                                             ) (ASSUME `((betS (A : mat_Point)) (a : mat_Point)) (H1 : mat_Point)`
                                                             )
                                                            ) (ASSUME `((betS (F : mat_Point)) (b : mat_Point)) (B : mat_Point)`
                                                            )))
                                                       ) (MP  
                                                          (SPEC `(F : mat_Point)` 
                                                           (SPEC `(b : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (axiom__betweennesssymmetry
                                                             )))
                                                          ) (ASSUME `((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point)`
                                                          )))
                                                     ) (MP  
                                                        (DISCH `(mat_and ((((cong (H1 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (H1 : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point)))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                            (SPEC `(mat_and ((((cong (H1 : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point))` 
                                                             (SPEC `(((cong (H1 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(((cong (H1 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                              (DISCH `(mat_and ((((cong (H1 : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                  (SPEC `(((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                   (SPEC `(((cong (H1 : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(((cong (H1 : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                ) (ASSUME `(mat_and ((((cong (H1 : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point))`
                                                                ))))
                                                          ) (ASSUME `(mat_and ((((cong (H1 : mat_Point)) (a : mat_Point)) (b : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (H1 : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (H1 : mat_Point)) (b : mat_Point)) (B : mat_Point)))`
                                                          ))
                                                        ) (MP  
                                                           (SPEC `(b : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(H1 : mat_Point)` 
                                                              (SPEC `(a : mat_Point)` 
                                                               (lemma__congruenceflip
                                                               ))))
                                                           ) (ASSUME `(((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                                           ))))
                                                   ) (MP  
                                                      (DISCH `(mat_and ((((cong (A : mat_Point)) (a : mat_Point)) (b : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (A : mat_Point)) (b : mat_Point)) (F : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                          (SPEC `(mat_and ((((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (A : mat_Point)) (b : mat_Point)) (F : mat_Point))` 
                                                           (SPEC `(((cong (A : mat_Point)) (a : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((cong (A : mat_Point)) (a : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                            (DISCH `(mat_and ((((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (A : mat_Point)) (b : mat_Point)) (F : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                (SPEC `(((cong (a : mat_Point)) (A : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                 (SPEC `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                                  (DISCH `(((cong (a : mat_Point)) (A : mat_Point)) (b : mat_Point)) (F : mat_Point)` 
                                                                   (ASSUME `(((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                                   )))
                                                              ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (A : mat_Point)) (b : mat_Point)) (F : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (a : mat_Point)) (b : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (a : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (A : mat_Point)) (b : mat_Point)) (F : mat_Point)))`
                                                        ))
                                                      ) (MP  
                                                         (SPEC `(b : mat_Point)` 
                                                          (SPEC `(F : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (SPEC `(a : mat_Point)` 
                                                             (lemma__congruenceflip
                                                             ))))
                                                         ) (ASSUME `(((cong (a : mat_Point)) (A : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                         ))))
                                                 ) (MP  
                                                    (DISCH `(mat_and ((((cong (a : mat_Point)) (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (b : mat_Point)) (a : mat_Point)) (A : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(((cong (a : mat_Point)) (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                        (SPEC `(((cong (F : mat_Point)) (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                         (SPEC `(((cong (a : mat_Point)) (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(((cong (a : mat_Point)) (A : mat_Point)) (F : mat_Point)) (b : mat_Point)` 
                                                          (DISCH `(((cong (F : mat_Point)) (b : mat_Point)) (a : mat_Point)) (A : mat_Point)` 
                                                           (ASSUME `(((cong (a : mat_Point)) (A : mat_Point)) (F : mat_Point)) (b : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (A : mat_Point)) (F : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (b : mat_Point)) (a : mat_Point)) (A : mat_Point))`
                                                      ))
                                                    ) (MP  
                                                       (SPEC `(a : mat_Point)` 
                                                        (SPEC `(A : mat_Point)` 
                                                         (SPEC `(F : mat_Point)` 
                                                          (SPEC `(b : mat_Point)` 
                                                           (lemma__doublereverse
                                                           ))))
                                                       ) (ASSUME `(((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point)`
                                                       ))))))
                                           ) (ASSUME `(mat_and (((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))`
                                           ))))
                                     ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (B : mat_Point)) (b : mat_Point)) (F : mat_Point))) ((((cong (b : mat_Point)) (F : mat_Point)) (A : mat_Point)) (a : mat_Point))))`
                                     ))
                                   ) (MP  
                                      (MP  
                                       (SPEC `(a : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (SPEC `(b : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (lemma__extension))))
                                       ) (ASSUME `(neq (B : mat_Point)) (b : mat_Point)`
                                       )
                                      ) (ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                      )))
                                 ) (MP  
                                    (DISCH `(mat_and ((neq (a : mat_Point)) (H1 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (H1 : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                        (SPEC `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (H1 : mat_Point))` 
                                         (SPEC `(neq (a : mat_Point)) (H1 : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (a : mat_Point)) (H1 : mat_Point)` 
                                          (DISCH `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (H1 : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                              (SPEC `(neq (A : mat_Point)) (H1 : mat_Point)` 
                                               (SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                                (DISCH `(neq (A : mat_Point)) (H1 : mat_Point)` 
                                                 (ASSUME `(neq (A : mat_Point)) (a : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (H1 : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and ((neq (a : mat_Point)) (H1 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (H1 : mat_Point)))`
                                      ))
                                    ) (MP  
                                       (SPEC `(H1 : mat_Point)` 
                                        (SPEC `(a : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (lemma__betweennotequal)))
                                       ) (ASSUME `((betS (A : mat_Point)) (a : mat_Point)) (H1 : mat_Point)`
                                       ))))
                               ) (MP  
                                  (MP  
                                   (SPEC `(b : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(H1 : mat_Point)` 
                                      (SPEC `(a : mat_Point)` 
                                       (axiom__nocollapse))))
                                   ) (ASSUME `(neq (a : mat_Point)) (H1 : mat_Point)`
                                   )
                                  ) (ASSUME `(((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point)`
                                  )))
                             ) (MP  
                                (DISCH `(mat_and ((neq (a : mat_Point)) (H1 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (H1 : mat_Point)))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (a : mat_Point)) (H1 : mat_Point)` 
                                    (SPEC `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (H1 : mat_Point))` 
                                     (SPEC `(neq (a : mat_Point)) (H1 : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (a : mat_Point)) (H1 : mat_Point)` 
                                      (DISCH `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (H1 : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(neq (a : mat_Point)) (H1 : mat_Point)` 
                                          (SPEC `(neq (A : mat_Point)) (H1 : mat_Point)` 
                                           (SPEC `(neq (A : mat_Point)) (a : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (A : mat_Point)) (a : mat_Point)` 
                                            (DISCH `(neq (A : mat_Point)) (H1 : mat_Point)` 
                                             (ASSUME `(neq (a : mat_Point)) (H1 : mat_Point)`
                                             )))
                                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (H1 : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and ((neq (a : mat_Point)) (H1 : mat_Point))) ((mat_and ((neq (A : mat_Point)) (a : mat_Point))) ((neq (A : mat_Point)) (H1 : mat_Point)))`
                                  ))
                                ) (MP  
                                   (SPEC `(H1 : mat_Point)` 
                                    (SPEC `(a : mat_Point)` 
                                     (SPEC `(A : mat_Point)` 
                                      (lemma__betweennotequal)))
                                   ) (ASSUME `((betS (A : mat_Point)) (a : mat_Point)) (H1 : mat_Point)`
                                   ))))))
                       ) (ASSUME `(mat_and ((((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H1 : mat_Point))`
                       ))))
                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (a : mat_Point)) (H1 : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (H1 : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H1 : mat_Point)))`
                 ))))
           ) (ASSUME `ex (\ H0 : mat_Point. ((mat_and (((betS (A : mat_Point)) (a : mat_Point)) (H0 : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (H0 : mat_Point)) (B : mat_Point)) (b : mat_Point))) ((((lt (C : mat_Point)) (c : mat_Point)) (A : mat_Point)) (H0 : mat_Point)))))`
           )))
        ) (ASSUME `(((((tG (A : mat_Point)) (a : mat_Point)) (B : mat_Point)) (b : mat_Point)) (C : mat_Point)) (c : mat_Point)`
        ))))))))
 ;;


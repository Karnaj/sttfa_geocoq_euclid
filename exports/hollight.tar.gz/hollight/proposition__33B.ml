(*proposition__33B :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((par A) B) C) D) ==> (((((cong A) B) C) D) ==> (((((oS A) C) B) D) ==> ((mat_and ((((par A) C) B) D)) ((((cong A) C) B) D))))))))`*)
let proposition__33B =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (DISCH `(((oS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false) ==> ((mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
         (DISCH `mat_not ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
          (MP  
           (DISCH `(((cR (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
            (MP  
             (CONV_CONV_rule `((((cR (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> ((mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
              (DISCH `ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                   (SPEC `\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point)))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(m : mat_Point)` 
                    (DISCH `(mat_and (((betS (A : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))` 
                     (MP  
                      (MP  
                       (SPEC `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                        (SPEC `((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                         (SPEC `((betS (A : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((betS (A : mat_Point)) (m : mat_Point)) (D : mat_Point)` 
                          (DISCH `((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point)` 
                           (MP  
                            (DISCH `((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)` 
                             (MP  
                              (DISCH `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                               (ASSUME `(mat_and ((((par (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                               )
                              ) (MP  
                                 (MP  
                                  (MP  
                                   (MP  
                                    (SPEC `(m : mat_Point)` 
                                     (SPEC `(D : mat_Point)` 
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (proposition__33)))))
                                    ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                    )
                                   ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                   )
                                  ) (ASSUME `((betS (A : mat_Point)) (m : mat_Point)) (D : mat_Point)`
                                  )
                                 ) (ASSUME `((betS (B : mat_Point)) (m : mat_Point)) (C : mat_Point)`
                                 )))
                            ) (MP  
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(m : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (axiom__betweennesssymmetry)))
                               ) (ASSUME `((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point)`
                               )))))
                      ) (ASSUME `(mat_and (((betS (A : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))`
                      ))))
                ) (ASSUME `ex (\ m : mat_Point. ((mat_and (((betS (A : mat_Point)) (m : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (m : mat_Point)) (B : mat_Point))))`
                )))
             ) (ASSUME `(((cR (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
             ))
           ) (MP  
              (MP  
               (SPEC `(D : mat_Point)` 
                (SPEC `(B : mat_Point)` 
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__crisscross))))
               ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
               )
              ) (ASSUME `mat_not ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
              ))))
        ) (DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) ==> mat_false` 
             (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
              (MP  
               (MP  
                (SPEC `mat_false` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                  (SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(M : mat_Point)` 
                   (DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                    (MP  
                     (MP  
                      (SPEC `mat_false` 
                       (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                        (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                         (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                          (MP  
                           (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (M : mat_Point)) (D : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point))))))) ==> mat_false` 
                            (DISCH `((col (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                             (MP  
                              (DISCH `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                               (MP  
                                (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                 (MP  
                                  (DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))) ==> mat_false` 
                                     (DISCH `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `mat_not ((((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                        (MP  
                                         (CONV_CONV_rule `((((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                          (ASSUME `mat_not ((((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                          )
                                         ) (ASSUME `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                         ))
                                       ) (MP  
                                          (SPEC `(D : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__samenotopposite))))
                                          ) (ASSUME `(((oS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                          ))))
                                    ) (MP  
                                       (SPEC `(M : mat_Point)` 
                                        (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (x : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))))` 
                                         (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (X : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (ex__intro))))
                                       ) (MP  
                                          (MP  
                                           (SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                            (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                             (conj))
                                           ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                           )
                                          ) (MP  
                                             (MP  
                                              (SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                               (SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                (conj))
                                              ) (ASSUME `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                              )
                                             ) (ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                             )))))
                                  ) (MP  
                                     (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                         (SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                          (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                           (DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                               (SPEC `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                (SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                 (DISCH `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                     (SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                      (SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                       (DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                           (SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                            (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                             (DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                              (ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                              )))
                                                         ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                             ))))
                                       ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                       ))
                                     ) (MP  
                                        (SPEC `(D : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(A : mat_Point)` 
                                           (lemma__NCorder)))
                                        ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                        ))))
                                ) (MP  
                                   (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                       (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                        (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                              (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                    (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                      (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                      )))
                                                 ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                           ))))
                                     ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                     ))
                                   ) (MP  
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(C : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (lemma__parallelNC))))
                                      ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                      ))))
                              ) (MP  
                                 (DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                     (SPEC `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                      (SPEC `((col (M : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (M : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                       (DISCH `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                           (SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                            (SPEC `((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                             (DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                 (SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                  (SPEC `((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                   (DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                       (SPEC `((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                        (SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                         (DISCH `((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                          (ASSUME `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                          )))
                                                     ) (ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                               ))))
                                         ) (ASSUME `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                   ))
                                 ) (MP  
                                    (SPEC `(D : mat_Point)` 
                                     (SPEC `(M : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (lemma__collinearorder)))
                                    ) (ASSUME `((col (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                    )))))
                           ) (MP  
                              (SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (M : mat_Point)) (D : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point)))))` 
                               (SPEC `(eq (B : mat_Point)) (M : mat_Point)` 
                                (or__intror))
                              ) (MP  
                                 (SPEC `(mat_or ((eq (M : mat_Point)) (D : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point))))` 
                                  (SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                   (or__intror))
                                 ) (MP  
                                    (SPEC `(mat_or (((betS (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                     (SPEC `(eq (M : mat_Point)) (D : mat_Point)` 
                                      (or__intror))
                                    ) (MP  
                                       (SPEC `(mat_or (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                        (SPEC `((betS (M : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                         (or__intror))
                                       ) (MP  
                                          (SPEC `((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                           (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                            (or__introl))
                                          ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                          )))))))))
                     ) (ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))`
                     ))))
               ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))`
               )))
            ) (ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
            ))))))))))
 ;;


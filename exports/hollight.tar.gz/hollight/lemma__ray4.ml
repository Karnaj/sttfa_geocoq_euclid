(*lemma__ray4 :  |- `! A : mat_Point. (! B : mat_Point. (! E : mat_Point. (((mat_or (((betS A) E) B)) ((mat_or ((eq E) B)) (((betS A) B) E))) ==> (((neq A) B) ==> (((out A) B) E)))))`*)
let lemma__ray4 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(E : mat_Point)` 
   (DISCH `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
    (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
     (MP  
      (CONV_CONV_rule `(((eq (B : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
       (DISCH `mat_not ((eq (B : mat_Point)) (A : mat_Point))` 
        (MP  
         (DISCH `ex (\ J : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((((cong (A : mat_Point)) (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
          (MP  
           (MP  
            (SPEC `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((((cong (A : mat_Point)) (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
              (SPEC `\ J : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((((cong (A : mat_Point)) (J : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(J : mat_Point)` 
               (DISCH `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((((cong (A : mat_Point)) (J : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                (MP  
                 (MP  
                  (SPEC `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                   (SPEC `(((cong (A : mat_Point)) (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                    (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (J : mat_Point)` 
                     (DISCH `(((cong (A : mat_Point)) (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                      (MP  
                       (DISCH `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (MP  
                         (DISCH `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                          (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                          )
                         ) (MP  
                            (DISCH `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                             (MP  
                              (DISCH `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                               (MP  
                                (MP  
                                 (MP  
                                  (SPEC `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                   (SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                    (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                     (or__ind)))
                                  ) (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                     (MP  
                                      (DISCH `((betS (J : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                       (MP  
                                        (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                         (DISCH `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                          (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                          ))
                                        ) (MP  
                                           (SPEC `(J : mat_Point)` 
                                            (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                             (SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                               (ex__intro))))
                                           ) (MP  
                                              (MP  
                                               (SPEC `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                (SPEC `((betS (J : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                 (conj))
                                               ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                               )
                                              ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (MP  
                                          (SPEC `(B : mat_Point)` 
                                           (SPEC `(E : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (SPEC `(J : mat_Point)` 
                                              (axiom__innertransitivity))))
                                          ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                          )
                                         ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                         ))))
                                 ) (DISCH `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                    (MP  
                                     (MP  
                                      (MP  
                                       (SPEC `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                        (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                         (SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                          (or__ind)))
                                       ) (DISCH `(eq (E : mat_Point)) (B : mat_Point)` 
                                          (MP  
                                           (DISCH `((betS (J : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                              (DISCH `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                               (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                               ))
                                             ) (MP  
                                                (SPEC `(J : mat_Point)` 
                                                 (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                  (SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (ex__intro))))
                                                ) (MP  
                                                   (MP  
                                                    (SPEC `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `((betS (J : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                      (conj))
                                                    ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                    )
                                                   ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                   ))))
                                           ) (MP  
                                              (CONV_CONV_rule `((eq (E : mat_Point)) (B : mat_Point)) ==> (((betS (J : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                               (SPEC `(E : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `(((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> (((betS (J : mat_Point)) (A : mat_Point)) (x : mat_Point))))` 
                                                  (SPEC `\ E0 : mat_Point. (((betS (J : mat_Point)) (A : mat_Point)) (E0 : mat_Point))` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (PINST [(`:mat_Point`,`:A`)] [] 
                                                     (eq__ind__r))))
                                                 ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                 )))
                                              ) (ASSUME `(eq (E : mat_Point)) (B : mat_Point)`
                                              ))))
                                      ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                         (MP  
                                          (DISCH `((betS (J : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                             (DISCH `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                              (ASSUME `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                              ))
                                            ) (MP  
                                               (SPEC `(J : mat_Point)` 
                                                (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
                                                 (SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (A : mat_Point)) (E : mat_Point))) (((betS (X : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__intro))))
                                               ) (MP  
                                                  (MP  
                                                   (SPEC `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                    (SPEC `((betS (J : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                     (conj))
                                                   ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                   )
                                                  ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                  ))))
                                          ) (MP  
                                             (MP  
                                              (SPEC `(E : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (SPEC `(J : mat_Point)` 
                                                  (lemma__3__7b))))
                                              ) (ASSUME `((betS (J : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                              )
                                             ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                             ))))
                                     ) (ASSUME `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                     )))
                                ) (ASSUME `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                ))
                              ) (ASSUME `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                              ))
                            ) (ASSUME `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                            )))
                       ) (MP  
                          (SPEC `(J : mat_Point)` 
                           (SPEC `(A : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (axiom__betweennesssymmetry)))
                          ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (J : mat_Point)`
                          )))))
                 ) (ASSUME `(mat_and (((betS (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((((cong (A : mat_Point)) (J : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                 ))))
           ) (ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (J : mat_Point))) ((((cong (A : mat_Point)) (J : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
           ))
         ) (MP  
            (MP  
             (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (A : mat_Point))) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (A : mat_Point)) (X : mat_Point))) ((((cong (A : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point))))))` 
              (SPEC `(B : mat_Point)` 
               (SPEC `(A : mat_Point)` 
                (SPEC `(A : mat_Point)` 
                 (SPEC `(B : mat_Point)` (lemma__extension)))))
             ) (ASSUME `mat_not ((eq (B : mat_Point)) (A : mat_Point))`)
            ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`))))
      ) (DISCH `(eq (B : mat_Point)) (A : mat_Point)` 
         (MP  
          (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
             (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)
            ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`))
          ) (MP  
             (SPEC `(B : mat_Point)` 
              (SPEC `(A : mat_Point)` (lemma__equalitysymmetric))
             ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`)))))))))
 ;;


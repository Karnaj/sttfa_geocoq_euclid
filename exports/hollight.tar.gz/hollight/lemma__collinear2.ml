(*lemma__collinear2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((col A) B) C) ==> (((col B) C) A))))`*)
let lemma__collinear2 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
      (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
       (MP  
        (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
         (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`)
        ) (MP  
           (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
            (MP  
             (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
              (MP  
               (MP  
                (MP  
                 (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                  (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                   (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__ind)))
                 ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                    (MP  
                     (DISCH `(eq (B : mat_Point)) (A : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                        (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                         (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                         ))
                       ) (MP  
                          (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                           (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                            (or__intror))
                          ) (MP  
                             (SPEC `(mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                              (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                               (or__introl))
                             ) (ASSUME `(eq (B : mat_Point)) (A : mat_Point)`
                             ))))
                     ) (MP  
                        (SPEC `(A : mat_Point)` 
                         (SPEC `(B : mat_Point)` (lemma__equalitysymmetric))
                        ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`))))
                ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                   (MP  
                    (MP  
                     (MP  
                      (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                       (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                        (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                         (or__ind)))
                      ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (DISCH `(eq (C : mat_Point)) (A : mat_Point)` 
                           (MP  
                            (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                             (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                              (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                              ))
                            ) (MP  
                               (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                 (or__intror))
                               ) (MP  
                                  (SPEC `(mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                   (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                    (or__intror))
                                  ) (MP  
                                     (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                      (SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                       (or__introl))
                                     ) (ASSUME `(eq (C : mat_Point)) (A : mat_Point)`
                                     )))))
                          ) (MP  
                             (SPEC `(A : mat_Point)` 
                              (SPEC `(C : mat_Point)` 
                               (lemma__equalitysymmetric))
                             ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                             ))))
                     ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                        (MP  
                         (MP  
                          (MP  
                           (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                            (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                             (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                              (or__ind)))
                           ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                 (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                 ))
                               ) (MP  
                                  (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                   (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                    (or__introl))
                                  ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                  ))))
                          ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                             (MP  
                              (MP  
                               (MP  
                                (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                 (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                  (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                   (or__ind)))
                                ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                   (MP  
                                    (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                     (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                      (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                      ))
                                    ) (MP  
                                       (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                        (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                         (or__intror))
                                       ) (MP  
                                          (SPEC `(mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                           (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                            (or__intror))
                                          ) (MP  
                                             (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                              (SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                               (or__intror))
                                             ) (MP  
                                                (SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                 (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                  (or__intror))
                                                ) (MP  
                                                   (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                     (or__intror))
                                                   ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                   ))))))))
                               ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                  (MP  
                                   (MP  
                                    (MP  
                                     (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                      (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                       (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (or__ind)))
                                     ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                            (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                             (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                             ))
                                           ) (MP  
                                              (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                               (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                (or__intror))
                                              ) (MP  
                                                 (SPEC `(mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                  (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                   (or__intror))
                                                 ) (MP  
                                                    (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                     (SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                                      (or__intror))
                                                    ) (MP  
                                                       (SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                        (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                         (or__introl))
                                                       ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                       ))))))
                                         ) (MP  
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(A : mat_Point)` 
                                               (axiom__betweennesssymmetry)))
                                            ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                            ))))
                                    ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                       (MP  
                                        (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                           (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                            (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                            ))
                                          ) (MP  
                                             (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                              (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                               (or__intror))
                                             ) (MP  
                                                (SPEC `(mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                 (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                  (or__intror))
                                                ) (MP  
                                                   (SPEC `(mat_or (((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                    (SPEC `(eq (C : mat_Point)) (A : mat_Point)` 
                                                     (or__intror))
                                                   ) (MP  
                                                      (SPEC `(mat_or (((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                       (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (or__intror))
                                                      ) (MP  
                                                         (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                           (or__introl))
                                                         ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                         )))))))
                                        ) (MP  
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (axiom__betweennesssymmetry)))
                                           ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                           ))))
                                   ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                   )))
                              ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                              )))
                         ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                         )))
                    ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                    )))
               ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
               ))
             ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
             ))
           ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
           ))))
     ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`)))))
 ;;


(*lemma__parallelcollinear2 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((tP A) B) c) d) ==> ((((betS c) C) d) ==> ((((tP A) B) C) d)))))))`*)
let lemma__parallelcollinear2 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(c : mat_Point)` 
    (GEN `(d : mat_Point)` 
     (DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
      (DISCH `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
       (MP  
        (DISCH `((betS (d : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
         (MP  
          (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
           (MP  
            (DISCH `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
             (MP  
              (MP  
               (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))) ==> (return : bool)))` 
                 (SPEC `\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))` 
                  (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
               ) (GEN `(p : mat_Point)` 
                  (DISCH `ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))` 
                   (MP  
                    (MP  
                     (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                      (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))) ==> (return : bool)))` 
                       (SPEC `\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))` 
                        (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                     ) (GEN `(q : mat_Point)` 
                        (DISCH `ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))` 
                         (MP  
                          (MP  
                           (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))) ==> (return : bool)))` 
                             (SPEC `\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))` 
                              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                           ) (GEN `(r : mat_Point)` 
                              (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))` 
                               (MP  
                                (MP  
                                 (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                  (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))` 
                                   (SPEC `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                    (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                        (SPEC `(mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))` 
                                         (SPEC `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                          (DISCH `(mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                              (SPEC `(mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))` 
                                               (SPEC `((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                (DISCH `(mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                    (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))` 
                                                     (SPEC `((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                      (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                          (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                           (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                            (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                 (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (d : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (q : mat_Point)) (p : mat_Point))) ((mat_or ((eq (q : mat_Point)) (c : mat_Point))) ((mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (q : mat_Point)) (c : mat_Point))) ((mat_or (((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (q : mat_Point)) (c : mat_Point)) (p : mat_Point))))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (p : mat_Point)) (r : mat_Point)) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (p : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (p : mat_Point)) (r : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (p : mat_Point)) (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (q : mat_Point)) (r : mat_Point))) ((mat_or ((eq (q : mat_Point)) (d : mat_Point))) ((mat_or ((eq (r : mat_Point)) (d : mat_Point))) ((mat_or (((betS (r : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_or (((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point))) (((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point))))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (d : mat_Point)) (d : mat_Point)) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (d : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (r : mat_Point)) (d : mat_Point))) ((mat_or ((eq (r : mat_Point)) (d : mat_Point))) ((mat_or ((eq (d : mat_Point)) (d : mat_Point))) ((mat_or (((betS (d : mat_Point)) (r : mat_Point)) (d : mat_Point))) ((mat_or (((betS (r : mat_Point)) (d : mat_Point)) (d : mat_Point))) (((betS (r : mat_Point)) (d : mat_Point)) (d : mat_Point))))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (r : mat_Point)) (d : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (q : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (c : mat_Point)) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (c : mat_Point)) (p : mat_Point)) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (c : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (p : mat_Point)) (p : mat_Point)) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (q : mat_Point)) (p : mat_Point))) ((mat_or ((eq (q : mat_Point)) (p : mat_Point))) ((mat_or ((eq (p : mat_Point)) (p : mat_Point))) ((mat_or (((betS (p : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_or (((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point))) (((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point))))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (c : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (c : mat_Point)) (p : mat_Point))) ((mat_or ((eq (c : mat_Point)) (c : mat_Point))) ((mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (c : mat_Point)) (c : mat_Point))) ((mat_or (((betS (c : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (c : mat_Point)) (c : mat_Point)) (p : mat_Point))))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (q : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ E : mat_Point. ((mat_and (((betS (q : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (d : mat_Point)) (E : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (q : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (d : mat_Point)) (x : mat_Point)) (p : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (q : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (d : mat_Point)) (E : mat_Point)) (p : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. ((mat_and (((betS (q : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (d : mat_Point)) (E : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (q : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (d : mat_Point)) (E : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (d : mat_Point)) (E : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (q : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (q : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (d : mat_Point)) (E : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (p : mat_Point)) (E : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ F : mat_Point. ((mat_and (((betS (q : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (q : mat_Point)) (x : mat_Point)) (E : mat_Point))) (((betS (p : mat_Point)) (x : mat_Point)) (r : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (q : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ F : mat_Point. ((mat_and (((betS (q : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (q : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (q : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (q : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (p : mat_Point)) (r : mat_Point))) ((mat_or ((eq (p : mat_Point)) (F : mat_Point))) ((mat_or ((eq (r : mat_Point)) (F : mat_Point))) ((mat_or (((betS (r : mat_Point)) (p : mat_Point)) (F : mat_Point))) ((mat_or (((betS (p : mat_Point)) (r : mat_Point)) (F : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point))))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (r : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (q : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_not ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (mat_not ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)) ==> mat_false) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)))) ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> ((((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)))) ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)))) ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ R : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (x : mat_Point))))) ==> (return : bool))) ==> ((ex (\ R : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ R : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (C : mat_Point)) (d : mat_Point))) ((mat_or (((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_or (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (c : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))) ((mat_and (((col (c : mat_Point)) (R : mat_Point)) (d : mat_Point))) ((mat_and (((col (R : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (R : mat_Point)) (d : mat_Point))) ((mat_and (((col (R : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (R : mat_Point)) (d : mat_Point))) ((mat_and (((col (R : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (R : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (R : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (R : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (R : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (R : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (R : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (R : mat_Point)) (d : mat_Point))) ((mat_and (((col (R : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (R : mat_Point))) ((mat_and (((col (c : mat_Point)) (R : mat_Point)) (d : mat_Point))) ((mat_and (((col (R : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (R : mat_Point)) (c : mat_Point))) (((col (R : mat_Point)) (c : mat_Point)) (d : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (d : mat_Point)) (c : mat_Point)) (R : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (d : mat_Point)) (c : mat_Point)) (R : mat_Point)) ==> mat_false) ==> (((col (d : mat_Point)) (c : mat_Point)) (R : mat_Point))` 
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (d : mat_Point)) (c : mat_Point)) (R : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (d : mat_Point)) (c : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(R : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (q : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (q : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (C : mat_Point)) (d : mat_Point))) ((mat_or (((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_or (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (d : mat_Point))) ((mat_or (((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_or (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_or (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (nNPP)
                                                                    ) (
                                                                    ASSUME `mat_not (mat_not ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ R : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (R : mat_Point))) (((col (C : mat_Point)) (d : mat_Point)) (R : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `mat_not ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (B : mat_Point)) (p : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((neq (B : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (p : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (p : mat_Point)) (r : mat_Point))) ==> ((((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)) ==> ((((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)) ==> ((((col (p : mat_Point)) (r : mat_Point)) (F : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__collinear5
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (p : mat_Point)) (r : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (F : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))) (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (p : mat_Point))) ((mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (p : mat_Point))) ((mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (p : mat_Point))) ((mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (p : mat_Point))) ((mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (p : mat_Point))) ((mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (p : mat_Point)) (B : mat_Point)) (r : mat_Point)) ==> mat_false) ==> (((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (p : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (B : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (p : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (p : mat_Point)) (r : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (p : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear5
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((col (A : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__trans
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__sym))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (p : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (B : mat_Point)) (p : mat_Point))) ==> ((eq (B : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (p : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (B : mat_Point)) (p : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (A : mat_Point)) (p : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((neq (A : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (r : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (r : mat_Point)) (A : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((eq (r : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) (((col (B : mat_Point)) (F : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (F : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (r : mat_Point)) (A : mat_Point))) ==> (((col (A : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (r : mat_Point)) (A : mat_Point))`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(eq (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (r : mat_Point)) (p : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (r : mat_Point)) (p : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (r : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (r : mat_Point)) (p : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (p : mat_Point)) (r : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (q : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (C : mat_Point)) (F : mat_Point)) ==> (((neq (C : mat_Point)) (q : mat_Point)) ==> (mat_not ((eq (p : mat_Point)) (r : mat_Point))))) ==> (((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point))) ==> ((neq (p : mat_Point)) (r : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (p : mat_Point)) (r : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (q : mat_Point))) ((mat_and ((neq (C : mat_Point)) (F : mat_Point))) ((neq (C : mat_Point)) (q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (r : mat_Point)) (A : mat_Point)) ==> (((eq (A : mat_Point)) (p : mat_Point)) ==> ((eq (r : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__trans
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (r : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (p : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (A : mat_Point)) (p : mat_Point))) ==> ((eq (A : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (p : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (A : mat_Point)) (p : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) ((mat_and (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) ((mat_and (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) ((mat_and (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) ((mat_and (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) ((mat_and (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (r : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (r : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (F : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (F : mat_Point))) ((mat_and (((col (r : mat_Point)) (F : mat_Point)) (A : mat_Point))) ((mat_and (((col (F : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (A : mat_Point)) (F : mat_Point)) (r : mat_Point))) (((col (F : mat_Point)) (r : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (r : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (p : mat_Point)) (r : mat_Point)) (F : mat_Point)) ==> (! x : mat_Point. (((eq (x : mat_Point)) (p : mat_Point)) ==> (((col (x : mat_Point)) (r : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (((col (X : mat_Point)) (r : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((neq (A : mat_Point)) (p : mat_Point))) ==> ((eq (A : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (p : mat_Point)` 
                                                                    (nNPP))
                                                                    ) (
                                                                    ASSUME `mat_not ((neq (A : mat_Point)) (p : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (C : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (U : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (F : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (p : mat_Point)) (r : mat_Point))) ==> ((((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)) ==> ((((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)) ==> ((((col (p : mat_Point)) (r : mat_Point)) (F : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__collinear5
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (p : mat_Point)) (r : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (F : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (p : mat_Point)) (r : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (r : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (p : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (r : mat_Point))) (((col (A : mat_Point)) (r : mat_Point)) (p : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (p : mat_Point)) (r : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (p : mat_Point)) (r : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (p : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (r : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (p : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__3__6b
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (F : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (c : mat_Point)) (C : mat_Point))) ((mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (C : mat_Point)) (d : mat_Point))) ((mat_or (((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_or (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (C : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and (((col (d : mat_Point)) (c : mat_Point)) (C : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (C : mat_Point))) (((col (d : mat_Point)) (C : mat_Point)) (c : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (c : mat_Point)) (d : mat_Point))) ((mat_or ((eq (C : mat_Point)) (d : mat_Point))) ((mat_or (((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_or (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (d : mat_Point))) ((mat_or (((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_or (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_or (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point))) (((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (d : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (r : mat_Point)) (p : mat_Point)) (B : mat_Point))) ((mat_and (((col (p : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (r : mat_Point))) (((col (p : mat_Point)) (r : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (r : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (r : mat_Point))) ((mat_and (((col (B : mat_Point)) (r : mat_Point)) (A : mat_Point))) ((mat_and (((col (r : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (r : mat_Point)) (B : mat_Point))) (((col (r : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (p : mat_Point))) ((mat_and (((col (B : mat_Point)) (p : mat_Point)) (A : mat_Point))) ((mat_and (((col (p : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (p : mat_Point)) (B : mat_Point))) (((col (p : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (r : mat_Point)) (p : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (r : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (r : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (p : mat_Point)) (F : mat_Point))) ((mat_or ((eq (r : mat_Point)) (F : mat_Point))) ((mat_or (((betS (r : mat_Point)) (p : mat_Point)) (F : mat_Point))) ((mat_or (((betS (p : mat_Point)) (r : mat_Point)) (F : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (r : mat_Point)) (F : mat_Point))) ((mat_or (((betS (r : mat_Point)) (p : mat_Point)) (F : mat_Point))) ((mat_or (((betS (p : mat_Point)) (r : mat_Point)) (F : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (p : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (r : mat_Point)) (p : mat_Point)) (F : mat_Point))) ((mat_or (((betS (p : mat_Point)) (r : mat_Point)) (F : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (r : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (p : mat_Point)) (r : mat_Point)) (F : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (r : mat_Point)) (p : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (p : mat_Point)) (r : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (q : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (q : mat_Point)) (F : mat_Point)) (E : mat_Point))) (((betS (p : mat_Point)) (F : mat_Point)) (r : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (p : mat_Point)) (E : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (q : mat_Point)) (d : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (E : mat_Point)) (p : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (q : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (d : mat_Point)) (E : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (q : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (d : mat_Point)) (E : mat_Point)) (p : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    postulate__Pasch__inner
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (q : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (c : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (q : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (p : mat_Point)) (c : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((neq (q : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((neq (q : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((neq (q : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (q : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((neq (q : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (p : mat_Point)) (c : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((neq (q : mat_Point)) (c : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (c : mat_Point)) (c : mat_Point))) ((mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (c : mat_Point)) (c : mat_Point))) ((mat_or (((betS (c : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (c : mat_Point)) (c : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (c : mat_Point)) (c : mat_Point))) ((mat_or (((betS (c : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (c : mat_Point)) (c : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (c : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (q : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((col (c : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((col (c : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((col (c : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (c : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (c : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((col (c : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (q : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (c : mat_Point)) (q : mat_Point))) ((mat_and (((col (c : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((col (q : mat_Point)) (c : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (p : mat_Point)) (q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (c : mat_Point)) (p : mat_Point))) ==> (((nCol (c : mat_Point)) (p : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (p : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (c : mat_Point)) (p : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (q : mat_Point)) (p : mat_Point))) ((mat_or ((eq (p : mat_Point)) (p : mat_Point))) ((mat_or (((betS (p : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_or (((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point))) (((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (p : mat_Point)) (p : mat_Point))) ((mat_or (((betS (p : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_or (((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point))) (((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (p : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_or (((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point))) (((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (p : mat_Point)) (p : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (c : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (p : mat_Point)) (c : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (p : mat_Point)) (r : mat_Point))) ((mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or ((eq (r : mat_Point)) (c : mat_Point))) ((mat_or (((betS (r : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (r : mat_Point)) (c : mat_Point))) (((betS (p : mat_Point)) (c : mat_Point)) (r : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (r : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)) ==> mat_false) ==> (((col (q : mat_Point)) (p : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (r : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (r : mat_Point)) (c : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or ((eq (r : mat_Point)) (c : mat_Point))) ((mat_or (((betS (r : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (r : mat_Point)) (c : mat_Point))) (((betS (p : mat_Point)) (c : mat_Point)) (r : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (r : mat_Point)) (c : mat_Point))) ((mat_or (((betS (r : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (r : mat_Point)) (c : mat_Point))) (((betS (p : mat_Point)) (c : mat_Point)) (r : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (p : mat_Point)) (c : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (c : mat_Point)) ==> ((eq (p : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (c : mat_Point)) (p : mat_Point)) ==> (((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)) ==> ((((betS (d : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> (((neq (c : mat_Point)) (d : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))) ==> (((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) ==> ((((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)) ==> ((((betS (d : mat_Point)) (C : mat_Point)) (c : mat_Point)) ==> ((((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)) ==> ((((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)) ==> ((((nCol (p : mat_Point)) (r : mat_Point)) (c : mat_Point)) ==> ((((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)) ==> (((eq (c : mat_Point)) (c : mat_Point)) ==> ((eq (p : mat_Point)) (c : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((tP (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (d : mat_Point)) ==> ((((betS (p : mat_Point)) (C : mat_Point)) (d : mat_Point)) ==> ((((betS (d : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> (((neq (p : mat_Point)) (d : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (d : mat_Point))) ==> (((((oS (p : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((betS (p : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point)) ==> ((((betS (d : mat_Point)) (C : mat_Point)) (p : mat_Point)) ==> ((((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point)) ==> ((((col (q : mat_Point)) (p : mat_Point)) (p : mat_Point)) ==> ((((nCol (p : mat_Point)) (r : mat_Point)) (p : mat_Point)) ==> ((((col (q : mat_Point)) (p : mat_Point)) (p : mat_Point)) ==> (((eq (p : mat_Point)) (p : mat_Point)) ==> ((eq (p : mat_Point)) (p : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (p : mat_Point)) ==> (((((tP (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (d : mat_Point)) ==> ((((betS (x : mat_Point)) (C : mat_Point)) (d : mat_Point)) ==> ((((betS (d : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((neq (x : mat_Point)) (d : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (d : mat_Point))) ==> (((((oS (x : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((betS (x : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (q : mat_Point)) (p : mat_Point)) (x : mat_Point)) ==> ((((betS (d : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> ((((betS (q : mat_Point)) (p : mat_Point)) (x : mat_Point)) ==> ((((col (q : mat_Point)) (p : mat_Point)) (x : mat_Point)) ==> ((((nCol (p : mat_Point)) (r : mat_Point)) (x : mat_Point)) ==> ((((col (q : mat_Point)) (p : mat_Point)) (x : mat_Point)) ==> (((eq (x : mat_Point)) (x : mat_Point)) ==> ((eq (p : mat_Point)) (x : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ c0 : mat_Point. (((((tP (A : mat_Point)) (B : mat_Point)) (c0 : mat_Point)) (d : mat_Point)) ==> ((((betS (c0 : mat_Point)) (C : mat_Point)) (d : mat_Point)) ==> ((((betS (d : mat_Point)) (C : mat_Point)) (c0 : mat_Point)) ==> (((neq (c0 : mat_Point)) (d : mat_Point)) ==> ((mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c0 : mat_Point)) (d : mat_Point))) ==> (((((oS (c0 : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((betS (c0 : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (c0 : mat_Point)) ==> ((((betS (q : mat_Point)) (p : mat_Point)) (c0 : mat_Point)) ==> ((((betS (d : mat_Point)) (C : mat_Point)) (c0 : mat_Point)) ==> ((((betS (q : mat_Point)) (p : mat_Point)) (c0 : mat_Point)) ==> ((((col (q : mat_Point)) (p : mat_Point)) (c0 : mat_Point)) ==> ((((nCol (p : mat_Point)) (r : mat_Point)) (c0 : mat_Point)) ==> ((((col (q : mat_Point)) (p : mat_Point)) (c0 : mat_Point)) ==> (((eq (c0 : mat_Point)) (c0 : mat_Point)) ==> ((eq (p : mat_Point)) (c0 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((tP (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (p : mat_Point)) (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (d : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (p : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (p : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (d : mat_Point)) (C : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (q : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (p : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(eq (p : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (p : mat_Point)) (p : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (r : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (c : mat_Point)) (c : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (d : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (d : mat_Point)) (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (p : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (d : mat_Point)) (p : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (p : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (p : mat_Point)) (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (p : mat_Point)) (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (p : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (d : mat_Point)) (q : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (q : mat_Point)) (p : mat_Point)) (d : mat_Point))) (((nCol (p : mat_Point)) (d : mat_Point)) (q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (q : mat_Point)) (d : mat_Point)) (p : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (r : mat_Point)) (d : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (q : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (r : mat_Point)) (d : mat_Point))) ((mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((neq (q : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((neq (q : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((neq (q : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (q : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((neq (q : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (r : mat_Point)) (d : mat_Point))) ((mat_and ((neq (q : mat_Point)) (r : mat_Point))) ((neq (q : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (r : mat_Point)) (d : mat_Point))) ((mat_or ((eq (d : mat_Point)) (d : mat_Point))) ((mat_or (((betS (d : mat_Point)) (r : mat_Point)) (d : mat_Point))) ((mat_or (((betS (r : mat_Point)) (d : mat_Point)) (d : mat_Point))) (((betS (r : mat_Point)) (d : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (d : mat_Point)) (d : mat_Point))) ((mat_or (((betS (d : mat_Point)) (r : mat_Point)) (d : mat_Point))) ((mat_or (((betS (r : mat_Point)) (d : mat_Point)) (d : mat_Point))) (((betS (r : mat_Point)) (d : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (d : mat_Point)) (r : mat_Point)) (d : mat_Point))) ((mat_or (((betS (r : mat_Point)) (d : mat_Point)) (d : mat_Point))) (((betS (r : mat_Point)) (d : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (d : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (d : mat_Point)) (d : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_and (((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point))) ((mat_and (((col (d : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point))) ((mat_and (((col (d : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point))) ((mat_and (((col (d : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point))) ((mat_and (((col (d : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (r : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_and (((col (r : mat_Point)) (d : mat_Point)) (q : mat_Point))) ((mat_and (((col (d : mat_Point)) (q : mat_Point)) (r : mat_Point))) ((mat_and (((col (q : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((col (d : mat_Point)) (r : mat_Point)) (q : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (r : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (q : mat_Point)) (d : mat_Point))) ((mat_or ((eq (r : mat_Point)) (d : mat_Point))) ((mat_or (((betS (r : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_or (((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point))) (((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (r : mat_Point)) (d : mat_Point))) ((mat_or (((betS (r : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_or (((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point))) (((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (r : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_or (((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point))) (((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point))) (((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (r : mat_Point)) (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (r : mat_Point)) (p : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (r : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (r : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (d : mat_Point)) (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (r : mat_Point)) (p : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (r : mat_Point)) (d : mat_Point)) (p : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (p : mat_Point)) (r : mat_Point))) ((mat_and (((nCol (p : mat_Point)) (d : mat_Point)) (r : mat_Point))) (((nCol (d : mat_Point)) (r : mat_Point)) (p : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (r : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (p : mat_Point)) (r : mat_Point))) ==> (((nCol (p : mat_Point)) (r : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (p : mat_Point)) (r : mat_Point))`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (p : mat_Point)) (r : mat_Point))) ==> (((nCol (p : mat_Point)) (r : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (p : mat_Point)) (r : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(eq (p : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (q : mat_Point)) (r : mat_Point))) ((mat_or ((eq (q : mat_Point)) (d : mat_Point))) ((mat_or ((eq (r : mat_Point)) (d : mat_Point))) ((mat_or (((betS (r : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_or (((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point))) (((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (X : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (x : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (X : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) (((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point))) ((mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point))) ((mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point))) ((mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point))) ((mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (c : mat_Point)) (p : mat_Point)) (d : mat_Point))) ((mat_and (((col (c : mat_Point)) (d : mat_Point)) (p : mat_Point))) ((mat_and (((col (d : mat_Point)) (p : mat_Point)) (c : mat_Point))) ((mat_and (((col (p : mat_Point)) (d : mat_Point)) (c : mat_Point))) (((col (d : mat_Point)) (c : mat_Point)) (p : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (p : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> mat_false) ==> (((col (p : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (p : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (p : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (q : mat_Point)) (p : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (p : mat_Point)) (c : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((neq (q : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((neq (q : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((neq (q : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (q : mat_Point)) (p : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((neq (q : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (p : mat_Point)) (c : mat_Point))) ((mat_and ((neq (q : mat_Point)) (p : mat_Point))) ((neq (q : mat_Point)) (c : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (p : mat_Point)) (r : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)) ==> ((((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point)) ==> ((((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)) ==> ((((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)) ==> ((((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)) ==> ((((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)) ==> (((col (q : mat_Point)) (p : mat_Point)) (d : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)) ==> ((((betS (c : mat_Point)) (r : mat_Point)) (q : mat_Point)) ==> ((((betS (q : mat_Point)) (r : mat_Point)) (c : mat_Point)) ==> ((((betS (q : mat_Point)) (r : mat_Point)) (c : mat_Point)) ==> ((((col (q : mat_Point)) (r : mat_Point)) (c : mat_Point)) ==> ((((col (q : mat_Point)) (r : mat_Point)) (c : mat_Point)) ==> (((col (q : mat_Point)) (r : mat_Point)) (d : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (r : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((betS (c : mat_Point)) (x : mat_Point)) (q : mat_Point)) ==> ((((betS (q : mat_Point)) (x : mat_Point)) (c : mat_Point)) ==> ((((betS (q : mat_Point)) (x : mat_Point)) (c : mat_Point)) ==> ((((col (q : mat_Point)) (x : mat_Point)) (c : mat_Point)) ==> ((((col (q : mat_Point)) (x : mat_Point)) (c : mat_Point)) ==> (((col (q : mat_Point)) (x : mat_Point)) (d : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ p0 : mat_Point. ((((col (A : mat_Point)) (B : mat_Point)) (p0 : mat_Point)) ==> ((((betS (c : mat_Point)) (p0 : mat_Point)) (q : mat_Point)) ==> ((((betS (q : mat_Point)) (p0 : mat_Point)) (c : mat_Point)) ==> ((((betS (q : mat_Point)) (p0 : mat_Point)) (c : mat_Point)) ==> ((((col (q : mat_Point)) (p0 : mat_Point)) (c : mat_Point)) ==> ((((col (q : mat_Point)) (p0 : mat_Point)) (c : mat_Point)) ==> (((col (q : mat_Point)) (p0 : mat_Point)) (d : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (c : mat_Point)) (r : mat_Point)) (q : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (q : mat_Point)) (r : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (q : mat_Point)) (r : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (r : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (q : mat_Point)) (r : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (q : mat_Point)) (r : mat_Point)) (d : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (p : mat_Point)) (r : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (q : mat_Point)) (d : mat_Point))) ((mat_or ((eq (r : mat_Point)) (d : mat_Point))) ((mat_or (((betS (r : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_or (((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point))) (((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (r : mat_Point)) (d : mat_Point))) ((mat_or (((betS (r : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_or (((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point))) (((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (r : mat_Point)) (q : mat_Point)) (d : mat_Point))) ((mat_or (((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point))) (((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point))) (((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (r : mat_Point)) (q : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (q : mat_Point)) (d : mat_Point)) (r : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (r : mat_Point)) (d : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (q : mat_Point)) (c : mat_Point))) ((mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (q : mat_Point)) (c : mat_Point))) ((mat_or (((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (q : mat_Point)) (c : mat_Point)) (p : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (p : mat_Point)) (c : mat_Point))) ((mat_or (((betS (p : mat_Point)) (q : mat_Point)) (c : mat_Point))) ((mat_or (((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (q : mat_Point)) (c : mat_Point)) (p : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (p : mat_Point)) (q : mat_Point)) (c : mat_Point))) ((mat_or (((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (q : mat_Point)) (c : mat_Point)) (p : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point))) (((betS (q : mat_Point)) (c : mat_Point)) (p : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (p : mat_Point)) (q : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (q : mat_Point)) (c : mat_Point)) (p : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((betS (q : mat_Point)) (p : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (C : mat_Point)) (c : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(r : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(q : mat_Point)` 
                                                                    (
                                                                    SPEC `(p : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (C : mat_Point))) ((neq (c : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (c : mat_Point)) (C : mat_Point))) ((neq (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (c : mat_Point)) (C : mat_Point))) ((neq (c : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (c : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (C : mat_Point))) ((neq (c : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (d : mat_Point))) ((mat_and ((neq (c : mat_Point)) (C : mat_Point))) ((neq (c : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(c : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))`
                                ))))
                          ) (ASSUME `ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))`
                          ))))
                    ) (ASSUME `ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))`
                    ))))
              ) (ASSUME `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))`
              ))
            ) (MP  
               (CONV_CONV_rule `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))))` 
                (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))))))` 
                 (MP  
                  (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))))))` 
                   (MP  
                    (MP  
                     (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                      (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))))` 
                       (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                        (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))))` 
                         (MP  
                          (MP  
                           (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                            (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))))` 
                             (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                              (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))))` 
                               (MP  
                                (MP  
                                 (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                  (SPEC `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                   (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                    (and__ind)))
                                 ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                    (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                        (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))) ==> (return : bool)))` 
                                         (SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))` 
                                          (PINST [(`:mat_Point`,`:A`)] [] 
                                           (ex__ind))))
                                       ) (GEN `(x : mat_Point)` 
                                          (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                              (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))) ==> (return : bool)))` 
                                               (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))` 
                                                (PINST [(`:mat_Point`,`:A`)] [] 
                                                 (ex__ind))))
                                             ) (GEN `(x0 : mat_Point)` 
                                                (DISCH `ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                    (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))) ==> (return : bool)))` 
                                                     (SPEC `\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))` 
                                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                                       (ex__ind))))
                                                   ) (GEN `(x1 : mat_Point)` 
                                                      (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                          (SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))` 
                                                           (SPEC `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                            (DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                                (SPEC `(mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))` 
                                                                 (SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                  (DISCH `(mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x0 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x2 : mat_Point. ((ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x2 : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))) ==> (ex (\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ p : mat_Point. (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (p : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (p : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x2 : mat_Point. ((ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (x2 : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))) ==> (ex (\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ q : mat_Point. (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (q : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (q : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(x1 : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x2 : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x2 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))) ==> (ex (\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ r : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (r : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (r : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)`
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))`
                                                        ))))
                                                  ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))`
                                                  ))))
                                            ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))`
                                            ))))
                                      ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))`
                                      ))))
                                ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))))`
                                ))))
                          ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point))))))))))))))`
                          ))))
                    ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))))))`
                    ))
                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((betS (c : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (d : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (c : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (d : mat_Point)))))))))))))))`
                  )))
               ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
               )))
          ) (MP  
             (CONV_CONV_rule `((((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
              (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
               (MP  
                (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                 (MP  
                  (MP  
                   (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                    (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)
                     ))
                   ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                      (DISCH `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                       (MP  
                        (MP  
                         (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                          (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                           (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (c : mat_Point)) (d : mat_Point)` 
                            (DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                 (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                  (and__ind)))
                               ) (DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                  (DISCH `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                   (MP  
                                    (MP  
                                     (SPEC `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                      (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                       (conj))
                                     ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                     )
                                    ) (MP  
                                       (MP  
                                        (SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                         (SPEC `(neq (c : mat_Point)) (d : mat_Point)` 
                                          (conj))
                                        ) (ASSUME `(neq (c : mat_Point)) (d : mat_Point)`
                                        )
                                       ) (MP  
                                          (MP  
                                           (SPEC `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                            (SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                             (conj))
                                           ) (ASSUME `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point))`
                                           )
                                          ) (ASSUME `(((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                          ))))))
                              ) (ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                        ))))
                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                  ))
                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (c : mat_Point)) (d : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)))) ((((oS (c : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                )))
             ) (ASSUME `(((tP (A : mat_Point)) (B : mat_Point)) (c : mat_Point)) (d : mat_Point)`
             )))
        ) (MP  
           (SPEC `(d : mat_Point)` 
            (SPEC `(C : mat_Point)` 
             (SPEC `(c : mat_Point)` (axiom__betweennesssymmetry)))
           ) (ASSUME `((betS (c : mat_Point)) (C : mat_Point)) (d : mat_Point)`
           )))))))))
 ;;


(*lemma__ondiameter :  |- `! D : mat_Point. (! F : mat_Point. (! K : mat_Circle. (! M : mat_Point. (! N : mat_Point. (! P : mat_Point. (! Q : mat_Point. (((((cI K) F) P) Q) ==> (((((cong F) D) P) Q) ==> (((((cong F) M) P) Q) ==> ((((betS D) F) M) ==> ((((betS D) N) M) ==> ((inCirc N) K))))))))))))`*)
let lemma__ondiameter =

 GEN `(D : mat_Point)` 
 (GEN `(F : mat_Point)` 
  (GEN `(K : mat_Circle)` 
   (GEN `(M : mat_Point)` 
    (GEN `(N : mat_Point)` 
     (GEN `(P : mat_Point)` 
      (GEN `(Q : mat_Point)` 
       (DISCH `(((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
        (DISCH `(((cong (F : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
         (DISCH `(((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
          (DISCH `((betS (D : mat_Point)) (F : mat_Point)) (M : mat_Point)` 
           (DISCH `((betS (D : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
            (MP  
             (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
              (MP  
               (DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                (MP  
                 (CONV_CONV_rule `((mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))) ==> mat_false) ==> ((inCirc (N : mat_Point)) (K : mat_Circle))` 
                  (DISCH `mat_not (mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))))` 
                   (MP  
                    (DISCH `(((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)` 
                     (MP  
                      (DISCH `(inCirc (N : mat_Point)) (K : mat_Circle)` 
                       (ASSUME `(inCirc (N : mat_Point)) (K : mat_Circle)`)
                      ) (MP  
                         (DISCH `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                          (MP  
                           (DISCH `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                            (MP  
                             (DISCH `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                              (MP  
                               (MP  
                                (MP  
                                 (SPEC `(inCirc (N : mat_Point)) (K : mat_Circle)` 
                                  (SPEC `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))` 
                                   (SPEC `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                    (or__ind)))
                                 ) (DISCH `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                    (MP  
                                     (DISCH `((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point)` 
                                      (MP  
                                       (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))) ==> ((inCirc (N : mat_Point)) (K : mat_Circle))` 
                                        (DISCH `(inCirc (N : mat_Point)) (K : mat_Circle)` 
                                         (ASSUME `(inCirc (N : mat_Point)) (K : mat_Circle)`
                                         ))
                                       ) (MP  
                                          (DISCH `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                                           (MP  
                                            (SPEC `(D : mat_Point)` 
                                             (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))))` 
                                              (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))))` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (ex__intro))))
                                            ) (MP  
                                               (SPEC `(N : mat_Point)` 
                                                (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (D : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (x : mat_Point)))))))))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (D : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))` 
                                                 (SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (D : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__intro))))
                                               ) (MP  
                                                  (SPEC `(F : mat_Point)` 
                                                   (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (x : mat_Point))) ((mat_and (((betS (x : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (D : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (x : mat_Point)) (N : mat_Point)) (x : mat_Point)) (N : mat_Point)))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (D : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (N : mat_Point)))))))))))))` 
                                                    (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (D : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (N : mat_Point))))))))))` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (ex__intro))))
                                                  ) (MP  
                                                     (SPEC `(P : mat_Point)` 
                                                      (CONV_CONV_rule `! x : mat_Point. ((ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)))))))) ==> (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)))))))))))` 
                                                       (SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point))))))))` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (ex__intro))))
                                                     ) (MP  
                                                        (SPEC `(Q : mat_Point)` 
                                                         (CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)))))) ==> (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)))))))))` 
                                                          (SPEC `\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point))))))` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (ex__intro))))
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point))))` 
                                                             (SPEC `(((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                              (conj))
                                                            ) (ASSUME `(((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                            )
                                                           ) (MP  
                                                              (SPEC `(mat_and (((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)))` 
                                                               (SPEC `(eq (N : mat_Point)) (F : mat_Point)` 
                                                                (or__intror))
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `(mat_and ((((cong (F : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point))` 
                                                                   (SPEC `((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                  ) (
                                                                  ASSUME `((betS (F : mat_Point)) (N : mat_Point)) (D : mat_Point)`
                                                                  )
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (D : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)`
                                                                    )))))))))
                                           )
                                          ) (MP  
                                             (SPEC `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                                              (nNPP)
                                             ) (ASSUME `mat_not (mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))))`
                                             ))))
                                     ) (MP  
                                        (DISCH `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                                         (MP  
                                          (SPEC `(F : mat_Point)` 
                                           (SPEC `(N : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (axiom__betweennesssymmetry)))
                                          ) (ASSUME `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)`
                                          ))
                                        ) (MP  
                                           (SPEC `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                                            (nNPP)
                                           ) (ASSUME `mat_not (mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))))`
                                           )))))
                                ) (DISCH `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))` 
                                   (MP  
                                    (MP  
                                     (MP  
                                      (SPEC `(inCirc (N : mat_Point)) (K : mat_Circle)` 
                                       (SPEC `(eq (F : mat_Point)) (N : mat_Point)` 
                                        (SPEC `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
                                         (or__ind)))
                                      ) (DISCH `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))) ==> ((inCirc (N : mat_Point)) (K : mat_Circle))` 
                                           (DISCH `(inCirc (N : mat_Point)) (K : mat_Circle)` 
                                            (ASSUME `(inCirc (N : mat_Point)) (K : mat_Circle)`
                                            ))
                                          ) (MP  
                                             (DISCH `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                                              (MP  
                                               (SPEC `(M : mat_Point)` 
                                                (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))))` 
                                                 (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))))` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (ex__intro))))
                                               ) (MP  
                                                  (SPEC `(N : mat_Point)` 
                                                   (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (x : mat_Point)))))))))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))` 
                                                    (SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (ex__intro))))
                                                  ) (MP  
                                                     (SPEC `(F : mat_Point)` 
                                                      (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (x : mat_Point))) ((mat_and (((betS (x : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (x : mat_Point)) (N : mat_Point)) (x : mat_Point)) (N : mat_Point)))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (N : mat_Point)))))))))))))` 
                                                       (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (N : mat_Point))))))))))` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (ex__intro))))
                                                     ) (MP  
                                                        (SPEC `(P : mat_Point)` 
                                                         (CONV_CONV_rule `! x : mat_Point. ((ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)))))))) ==> (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)))))))))))` 
                                                          (SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point))))))))` 
                                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                                            (ex__intro))))
                                                        ) (MP  
                                                           (SPEC `(Q : mat_Point)` 
                                                            (CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)))))) ==> (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)))))))))` 
                                                             (SPEC `\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point))))))` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (ex__intro))))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point))))` 
                                                                (SPEC `(((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                 (conj))
                                                               ) (ASSUME `(((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                               )
                                                              ) (MP  
                                                                 (SPEC `(mat_and (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)))` 
                                                                  (SPEC `(eq (N : mat_Point)) (F : mat_Point)` 
                                                                   (or__intror
                                                                   ))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (N : mat_Point)`
                                                                    )))))))))
                                              )
                                             ) (MP  
                                                (SPEC `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                                                 (nNPP)
                                                ) (ASSUME `mat_not (mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))))`
                                                )))))
                                     ) (DISCH `(eq (F : mat_Point)) (N : mat_Point)` 
                                        (MP  
                                         (DISCH `(eq (N : mat_Point)) (F : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))) ==> ((inCirc (N : mat_Point)) (K : mat_Circle))` 
                                            (DISCH `(inCirc (N : mat_Point)) (K : mat_Circle)` 
                                             (ASSUME `(inCirc (N : mat_Point)) (K : mat_Circle)`
                                             ))
                                           ) (MP  
                                              (DISCH `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                                               (MP  
                                                (SPEC `(M : mat_Point)` 
                                                 (CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))))` 
                                                  (SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))))` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (ex__intro))))
                                                ) (MP  
                                                   (SPEC `(M : mat_Point)` 
                                                    (CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (x : mat_Point)))))))))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))` 
                                                     (SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))` 
                                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                                       (ex__intro))))
                                                   ) (MP  
                                                      (SPEC `(F : mat_Point)` 
                                                       (CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (x : mat_Point))) ((mat_and (((betS (x : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (x : mat_Point)) (N : mat_Point)) (x : mat_Point)) (M : mat_Point)))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (M : mat_Point)))))))))))))` 
                                                        (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (N : mat_Point)) (U : mat_Point)) (M : mat_Point))))))))))` 
                                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                                          (ex__intro))))
                                                      ) (MP  
                                                         (SPEC `(P : mat_Point)` 
                                                          (CONV_CONV_rule `! x : mat_Point. ((ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (M : mat_Point)))))))) ==> (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (M : mat_Point)))))))))))` 
                                                           (SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (M : mat_Point))))))))` 
                                                            (PINST [(`:mat_Point`,`:A`)] [] 
                                                             (ex__intro))))
                                                         ) (MP  
                                                            (SPEC `(Q : mat_Point)` 
                                                             (CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (M : mat_Point)))))) ==> (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (M : mat_Point)))))))))` 
                                                              (SPEC `\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (W : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (M : mat_Point))))))` 
                                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                                (ex__intro)))
                                                             )
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(mat_or ((eq (N : mat_Point)) (F : mat_Point))) ((mat_and (((betS (F : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (M : mat_Point))))` 
                                                                 (SPEC `(((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                  (conj))
                                                                ) (ASSUME `(((cI (K : mat_Circle)) (F : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                )
                                                               ) (MP  
                                                                  (SPEC `(mat_and (((betS (F : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((((cong (F : mat_Point)) (N : mat_Point)) (F : mat_Point)) (M : mat_Point)))` 
                                                                   (SPEC `(eq (N : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `(eq (N : mat_Point)) (F : mat_Point)`
                                                                  ))))))))
                                              ) (MP  
                                                 (SPEC `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                                                  (nNPP)
                                                 ) (ASSUME `mat_not (mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))))`
                                                 ))))
                                         ) (MP  
                                            (DISCH `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                                             (MP  
                                              (SPEC `(F : mat_Point)` 
                                               (SPEC `(N : mat_Point)` 
                                                (lemma__equalitysymmetric))
                                              ) (ASSUME `(eq (F : mat_Point)) (N : mat_Point)`
                                              ))
                                            ) (MP  
                                               (SPEC `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                                                (nNPP)
                                               ) (ASSUME `mat_not (mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))))`
                                               )))))
                                    ) (ASSUME `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))`
                                    )))
                               ) (ASSUME `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))`
                               ))
                             ) (ASSUME `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))`
                             ))
                           ) (ASSUME `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))`
                           ))
                         ) (MP  
                            (CONV_CONV_rule `((mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))) ==> mat_false) ==> ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))` 
                             (SPEC `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                              (nNPP))
                            ) (DISCH `mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))` 
                               (MP  
                                (DISCH `mat_false` 
                                 (MP  
                                  (DISCH `(((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)) ==> mat_false` 
                                   (MP  
                                    (DISCH `((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))) ==> mat_false` 
                                     (MP  
                                      (DISCH `(((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                       (MP  
                                        (DISCH `((eq (F : mat_Point)) (N : mat_Point)) ==> mat_false` 
                                         (MP  
                                          (SPEC `mat_false` (false__ind)
                                          ) (ASSUME `mat_false`))
                                        ) (DISCH `(eq (F : mat_Point)) (N : mat_Point)` 
                                           (MP  
                                            (ASSUME `((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))) ==> mat_false`
                                            ) (MP  
                                               (SPEC `(eq (F : mat_Point)) (N : mat_Point)` 
                                                (SPEC `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
                                                 (or__intror))
                                               ) (ASSUME `(eq (F : mat_Point)) (N : mat_Point)`
                                               )))))
                                      ) (DISCH `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
                                         (MP  
                                          (ASSUME `((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))) ==> mat_false`
                                          ) (MP  
                                             (SPEC `(eq (F : mat_Point)) (N : mat_Point)` 
                                              (SPEC `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
                                               (or__introl))
                                             ) (ASSUME `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)`
                                             )))))
                                    ) (DISCH `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))` 
                                       (MP  
                                        (CONV_CONV_rule `((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))) ==> mat_false` 
                                         (ASSUME `mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))`
                                         )
                                        ) (MP  
                                           (SPEC `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))` 
                                            (SPEC `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                             (or__intror))
                                           ) (ASSUME `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))`
                                           )))))
                                  ) (DISCH `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                     (MP  
                                      (CONV_CONV_rule `((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))) ==> mat_false` 
                                       (ASSUME `mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))`
                                       )
                                      ) (MP  
                                         (SPEC `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))` 
                                          (SPEC `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                           (or__introl))
                                         ) (ASSUME `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)`
                                         )))))
                                ) (MP  
                                   (CONV_CONV_rule `(mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))) ==> mat_false` 
                                    (ASSUME `mat_not (mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))))`
                                    )
                                   ) (ASSUME `mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))`
                                   )))))))
                    ) (MP  
                       (DISCH `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                        (SPEC `(N : mat_Point)` 
                         (SPEC `(F : mat_Point)` (cn__congruencereflexive)))
                       ) (MP  
                          (SPEC `(mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))` 
                           (nNPP)
                          ) (ASSUME `mat_not (mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))))`
                          )))))
                 ) (DISCH `mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))` 
                    (MP  
                     (CONV_CONV_rule `((((betS (D : mat_Point)) (F : mat_Point)) (N : mat_Point)) ==> mat_false) ==> mat_false` 
                      (DISCH `mat_not (((betS (D : mat_Point)) (F : mat_Point)) (N : mat_Point))` 
                       (MP  
                        (DISCH `(eq (F : mat_Point)) (N : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))) ==> mat_false` 
                           (ASSUME `mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))`
                           )
                          ) (MP  
                             (SPEC `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))` 
                              (SPEC `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                               (or__intror))
                             ) (MP  
                                (SPEC `(eq (F : mat_Point)) (N : mat_Point)` 
                                 (SPEC `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
                                  (or__intror))
                                ) (ASSUME `(eq (F : mat_Point)) (N : mat_Point)`
                                ))))
                        ) (MP  
                           (CONV_CONV_rule `((((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)) ==> mat_false) ==> ((eq (F : mat_Point)) (N : mat_Point))` 
                            (MP  
                             (MP  
                              (MP  
                               (SPEC `(M : mat_Point)` 
                                (SPEC `(N : mat_Point)` 
                                 (SPEC `(F : mat_Point)` 
                                  (SPEC `(D : mat_Point)` 
                                   (axiom__connectivity))))
                               ) (ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                               )
                              ) (ASSUME `((betS (D : mat_Point)) (N : mat_Point)) (M : mat_Point)`
                              )
                             ) (ASSUME `mat_not (((betS (D : mat_Point)) (F : mat_Point)) (N : mat_Point))`
                             ))
                           ) (DISCH `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                              (MP  
                               (CONV_CONV_rule `((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))) ==> mat_false` 
                                (ASSUME `mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))`
                                )
                               ) (MP  
                                  (SPEC `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))` 
                                   (SPEC `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                    (or__introl))
                                  ) (ASSUME `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)`
                                  )))))))
                     ) (DISCH `((betS (D : mat_Point)) (F : mat_Point)) (N : mat_Point)` 
                        (MP  
                         (DISCH `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
                          (MP  
                           (CONV_CONV_rule `((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point)))) ==> mat_false` 
                            (ASSUME `mat_not ((mat_or (((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))))`
                            )
                           ) (MP  
                              (SPEC `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point))) ((eq (F : mat_Point)) (N : mat_Point))` 
                               (SPEC `((betS (D : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                (or__intror))
                              ) (MP  
                                 (SPEC `(eq (F : mat_Point)) (N : mat_Point)` 
                                  (SPEC `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)` 
                                   (or__introl))
                                 ) (ASSUME `((betS (F : mat_Point)) (N : mat_Point)) (M : mat_Point)`
                                 ))))
                         ) (MP  
                            (MP  
                             (SPEC `(M : mat_Point)` 
                              (SPEC `(N : mat_Point)` 
                               (SPEC `(F : mat_Point)` 
                                (SPEC `(D : mat_Point)` (lemma__3__6a))))
                             ) (ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (N : mat_Point)`
                             )
                            ) (ASSUME `((betS (D : mat_Point)) (N : mat_Point)) (M : mat_Point)`
                            )))))))
               ) (MP  
                  (SPEC `(F : mat_Point)` 
                   (SPEC `(D : mat_Point)` (lemma__inequalitysymmetric))
                  ) (ASSUME `(neq (D : mat_Point)) (F : mat_Point)`)))
             ) (MP  
                (DISCH `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (M : mat_Point)))` 
                 (MP  
                  (MP  
                   (SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                    (SPEC `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (M : mat_Point))` 
                     (SPEC `(neq (F : mat_Point)) (M : mat_Point)` (and__ind)
                     ))
                   ) (DISCH `(neq (F : mat_Point)) (M : mat_Point)` 
                      (DISCH `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (M : mat_Point))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                          (SPEC `(neq (D : mat_Point)) (M : mat_Point)` 
                           (SPEC `(neq (D : mat_Point)) (F : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (D : mat_Point)) (F : mat_Point)` 
                            (DISCH `(neq (D : mat_Point)) (M : mat_Point)` 
                             (ASSUME `(neq (D : mat_Point)) (F : mat_Point)`)
                            ))
                        ) (ASSUME `(mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (M : mat_Point))`
                        ))))
                  ) (ASSUME `(mat_and ((neq (F : mat_Point)) (M : mat_Point))) ((mat_and ((neq (D : mat_Point)) (F : mat_Point))) ((neq (D : mat_Point)) (M : mat_Point)))`
                  ))
                ) (MP  
                   (SPEC `(M : mat_Point)` 
                    (SPEC `(F : mat_Point)` 
                     (SPEC `(D : mat_Point)` (lemma__betweennotequal)))
                   ) (ASSUME `((betS (D : mat_Point)) (F : mat_Point)) (M : mat_Point)`
                   )))))))))))))))
 ;;


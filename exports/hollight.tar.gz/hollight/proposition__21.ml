(*proposition__21 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. ((((triangle A) B) C) ==> ((((betS A) E) C) ==> ((((betS B) D) E) ==> ((mat_and ((((((((tT B) A) A) C) B) D) D) C)) ((((((ltA B) A) C) B) D) C)))))))))`*)
let proposition__21 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
      (DISCH `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
       (DISCH `((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
        (MP  
         (DISCH `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
          (MP  
           (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
            (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
             (MP  
              (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))))))) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
               (DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                (MP  
                 (DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                  (MP  
                   (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                    (MP  
                     (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                        (DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                           (DISCH `((col (A : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                            (MP  
                             (DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                (MP  
                                 (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                  (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                   (MP  
                                    (DISCH `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                     (MP  
                                      (DISCH `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                         (MP  
                                          (DISCH `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `((eq (C : mat_Point)) (C : mat_Point)) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                               (DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))))))) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                  (DISCH `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                       (MP  
                                                        (DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (D : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point))))))) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                           (DISCH `((col (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                            (MP  
                                                             (DISCH `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `((eq (E : mat_Point)) (E : mat_Point)) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                (DISCH `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                 (MP  
                                                                  (CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (E : mat_Point)) (E : mat_Point)) (B : mat_Point))))))) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                   (DISCH `((col (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `((triangle (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((tG (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((tT (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((tT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((tT (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `((triangle (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))))))) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((mat_and ((((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    DISCH `((triangle (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (E : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angleordertransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((ltA (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence2
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) (((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) (((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (A : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray5
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__angleorderrespectscongruence2
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((ltA (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> ((((((congA (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. ((((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> ((((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. ((((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> ((((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__16
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (E : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((neq (B : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. ((((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> ((((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. ((((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> ((((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((ltA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((ltA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((ltA (C0 : mat_Point)) (B0 : mat_Point)) (A0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__16
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((triangle (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((triangle (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__TTflip2
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__TTtransitive
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((tT (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((tT (B : mat_Point)) (E : mat_Point)) (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__TTflip
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((tT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__TTorder
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((tT (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__21helper
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((((tG (C : mat_Point)) (E : mat_Point)) (E : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    proposition__20
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((triangle (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (C : mat_Point)) (D : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (D : mat_Point))) ((neq (E : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or ((eq (E : mat_Point)) (E : mat_Point))) ((mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (E : mat_Point)) (E : mat_Point)) (B : mat_Point)))))` 
                                                                   (SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or ((eq (B : mat_Point)) (E : mat_Point))) ((mat_or (((betS (B : mat_Point)) (E : mat_Point)) (E : mat_Point))) ((mat_or (((betS (E : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((betS (E : mat_Point)) (E : mat_Point)) (B : mat_Point))))` 
                                                                   (SPEC `(eq (E : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `(eq (E : mat_Point)) (E : mat_Point)`
                                                                  )))))
                                                               ) (SPEC `(E : mat_Point)` 
                                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                                   (eq__refl)
                                                                  )))
                                                             ) (MP  
                                                                (DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((col (B : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (D : mat_Point))) (((col (B : mat_Point)) (D : mat_Point)) (E : mat_Point)))))`
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                   ) (
                                                                   ASSUME `((col (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                   )))))
                                                          ) (MP  
                                                             (SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) ((mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                                              (SPEC `(eq (E : mat_Point)) (D : mat_Point)` 
                                                               (or__intror))
                                                             ) (MP  
                                                                (SPEC `(mat_or ((eq (D : mat_Point)) (B : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                 (SPEC `(eq (E : mat_Point)) (B : mat_Point)` 
                                                                  (or__intror
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(mat_or (((betS (D : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or (((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `((betS (E : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `((betS (E : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                   )))))))
                                                        ) (MP  
                                                           (DISCH `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                (SPEC `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                 (DISCH `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point))))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (C : mat_Point)) (E : mat_Point)))))`
                                                             ))
                                                           ) (MP  
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(E : mat_Point)` 
                                                                 (lemma__NCorder
                                                                 )))
                                                              ) (ASSUME `((nCol (E : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                              ))))
                                                      ) (MP  
                                                         (SPEC `(B : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(E : mat_Point)` 
                                                            (nCol__notCol)))
                                                         ) (MP  
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (SPEC `(E : mat_Point)` 
                                                               (nCol__not__Col
                                                               )))
                                                            ) (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                  ) (
                                                                  ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                )
                                                               ) (ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                                               )))))
                                                    ) (MP  
                                                       (DISCH `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                            (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                   (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(E : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (lemma__betweennotequal
                                                             )))
                                                          ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                          )))))
                                                 ) (MP  
                                                    (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point)))))` 
                                                     (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                      (or__intror))
                                                    ) (MP  
                                                       (SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))))` 
                                                        (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                         (or__intror))
                                                       ) (MP  
                                                          (SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point)))` 
                                                           (SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                            (or__introl))
                                                          ) (ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                          ))))))
                                              ) (SPEC `(C : mat_Point)` 
                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                  (eq__refl))))
                                            ) (MP  
                                               (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                   (SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                    (SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                         (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                          (SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                           (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                               (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                (SPEC `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                 (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                                 ))
                                               ) (MP  
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(E : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (lemma__collinearorder))
                                                   )
                                                  ) (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                  ))))
                                          ) (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                          ))
                                        ) (MP  
                                           (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                               (SPEC `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                 (DISCH `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                      (SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                       (DISCH `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                            (SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (DISCH `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (SPEC `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                   (DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                             ))
                                           ) (MP  
                                              (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))))))` 
                                               (SPEC `(E : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (lemma__NCorder))))
                                              ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (MP  
                                          (SPEC `(E : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__21helper))))
                                          ) (ASSUME `(((((tG (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                          )
                                         ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                         )))
                                    ) (MP  
                                       (SPEC `(E : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (proposition__20)))
                                       ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                       ))))
                                 ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                 ))
                               ) (MP  
                                  (DISCH `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                      (SPEC `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                       (SPEC `((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                        (DISCH `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                            (SPEC `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                             (SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                              (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                  (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                   (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                    (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                        (SPEC `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                         (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                          (DISCH `((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                           (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                                ))))
                                          ) (ASSUME `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                                          ))))
                                    ) (ASSUME `(mat_and (((nCol (E : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((nCol (B : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                                    ))
                                  ) (MP  
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(E : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (lemma__NCorder)))
                                     ) (ASSUME `((nCol (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                     ))))
                             ) (MP  
                                (SPEC `(B : mat_Point)` 
                                 (SPEC `(E : mat_Point)` 
                                  (SPEC `(A : mat_Point)` (nCol__notCol)))
                                ) (MP  
                                   (SPEC `(B : mat_Point)` 
                                    (SPEC `(E : mat_Point)` 
                                     (SPEC `(A : mat_Point)` (nCol__not__Col)
                                     ))
                                   ) (MP  
                                      (MP  
                                       (MP  
                                        (MP  
                                         (SPEC `(E : mat_Point)` 
                                          (SPEC `(A : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__NChelper)))))
                                         ) (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                         )
                                        ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                        )
                                       ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                       )
                                      ) (ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                      ))))))
                          ) (MP  
                             (SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) ((mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                              (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                               (or__intror))
                             ) (MP  
                                (SPEC `(mat_or ((eq (C : mat_Point)) (A : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (A : mat_Point))) (((betS (A : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                 (SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                  (or__introl))
                                ) (ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                )))))
                       ) (SPEC `(A : mat_Point)` 
                          (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))
                     ) (MP  
                        (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                         (MP  
                          (MP  
                           (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                            (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                             (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                              (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                               (MP  
                                (MP  
                                 (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                  (SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                   (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                    (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                        (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                         (SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                          (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                              (SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                               (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                (DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                 (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                 )))
                                            ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                      ))))
                                ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                ))))
                          ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                          ))
                        ) (MP  
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(A : mat_Point)` (lemma__NCorder)))
                           ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                           ))))
                   ) (MP  
                      (DISCH `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                          (SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                           (SPEC `(neq (E : mat_Point)) (C : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                            (DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                 (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                  (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                   (ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                   )))
                              ) (ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (E : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                        ))
                      ) (MP  
                         (SPEC `(C : mat_Point)` 
                          (SPEC `(E : mat_Point)` 
                           (SPEC `(A : mat_Point)` (lemma__betweennotequal)))
                         ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                         ))))
                 ) (MP  
                    (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))` 
                     (MP  
                      (MP  
                       (SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                        (SPEC `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                         (SPEC `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                          (DISCH `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))` 
                           (MP  
                            (MP  
                             (SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                              (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                               (SPEC `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                (DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                    (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                     (SPEC `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                      (DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                          (SPEC `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                           (SPEC `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                            (DISCH `((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                             (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                             )))
                                        ) (ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))`
                                  ))))
                            ) (ASSUME `(mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point))))`
                            ))))
                      ) (ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (E : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((col (C : mat_Point)) (E : mat_Point)) (A : mat_Point)))))`
                      ))
                    ) (MP  
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(E : mat_Point)` 
                         (SPEC `(A : mat_Point)` (lemma__collinearorder)))
                       ) (ASSUME `((col (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                       )))))
              ) (MP  
                 (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))))` 
                  (SPEC `(eq (A : mat_Point)) (E : mat_Point)` (or__intror))
                 ) (MP  
                    (SPEC `(mat_or ((eq (E : mat_Point)) (C : mat_Point))) ((mat_or (((betS (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))))` 
                     (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                      (or__intror))
                    ) (MP  
                       (SPEC `(mat_or (((betS (E : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                        (SPEC `(eq (E : mat_Point)) (C : mat_Point)` 
                         (or__intror))
                       ) (MP  
                          (SPEC `(mat_or (((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                           (SPEC `((betS (E : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                            (or__intror))
                          ) (MP  
                             (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                              (SPEC `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                               (or__introl))
                             ) (ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                             ))))))))
           ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
           ))
         ) (MP  
            (SPEC `(E : mat_Point)` 
             (SPEC `(D : mat_Point)` 
              (SPEC `(B : mat_Point)` (axiom__betweennesssymmetry)))
            ) (ASSUME `((betS (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
            ))))))))))
 ;;


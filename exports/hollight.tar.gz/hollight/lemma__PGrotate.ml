(*lemma__PGrotate :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((pG A) B) C) D) ==> ((((pG B) C) D) A)))))`*)
let lemma__PGrotate =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
       (MP  
        (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
         (MP  
          (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
           (MP  
            (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
             (MP  
              (CONV_CONV_rule `((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> ((((pG (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
               (DISCH `(((pG (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                (ASSUME `(((pG (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                ))
              ) (MP  
                 (MP  
                  (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                   (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                    (conj))
                  ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                  )
                 ) (ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                 )))
            ) (MP  
               (MP  
                (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                   (and__ind)))
                ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                   (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                    (MP  
                     (DISCH `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                      (MP  
                       (MP  
                        (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                         (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                          (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                 (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                  (ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                  )))
                             ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                             ))))
                       ) (ASSUME `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                       ))
                     ) (MP  
                        (SPEC `(D : mat_Point)` 
                         (SPEC `(C : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` (lemma__parallelflip))))
                        ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                        )))))
               ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
               )))
          ) (MP  
             (MP  
              (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
               (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (and__ind)))
              ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                 (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (MP  
                   (DISCH `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                    (MP  
                     (MP  
                      (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                       (SPEC `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                        (SPEC `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                         (DISCH `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                          (MP  
                           (MP  
                            (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                             (SPEC `(((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                              (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                               (DISCH `(((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                )))
                           ) (ASSUME `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                           ))))
                     ) (ASSUME `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                     ))
                   ) (MP  
                      (SPEC `(D : mat_Point)` 
                       (SPEC `(A : mat_Point)` 
                        (SPEC `(C : mat_Point)` 
                         (SPEC `(B : mat_Point)` (lemma__parallelflip))))
                      ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                      )))))
             ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
             )))
        ) (MP  
           (MP  
            (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
             (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
              (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
               (and__ind)))
            ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
               (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(B : mat_Point)` 
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(A : mat_Point)` (lemma__parallelsymmetric))))
                 ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 ))))
           ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
           )))
      ) (MP  
         (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
          (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
           (MP  
            (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
             (MP  
              (MP  
               (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (and__ind)))
               ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                  (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (MP  
                     (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                       (conj))
                     ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                     )
                    ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                    ))))
              ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
              ))
            ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
            )))
         ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
         )))))))
 ;;


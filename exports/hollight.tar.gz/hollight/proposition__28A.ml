(*proposition__28A :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! G : mat_Point. (! H : mat_Point. ((((betS A) G) B) ==> ((((betS C) H) D) ==> ((((betS E) G) H) ==> (((((((congA E) G) B) G) H) D) ==> (((((oS B) D) G) H) ==> ((((par A) B) C) D))))))))))))`*)
let proposition__28A =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(G : mat_Point)` 
      (GEN `(H : mat_Point)` 
       (DISCH `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
        (DISCH `((betS (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
         (DISCH `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
          (DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
           (DISCH `(((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
            (MP  
             (DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
              (MP  
               (DISCH `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                (MP  
                 (CONV_CONV_rule `((eq (G : mat_Point)) (G : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                  (DISCH `(eq (G : mat_Point)) (G : mat_Point)` 
                   (MP  
                    (CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or ((eq (G : mat_Point)) (G : mat_Point))) ((mat_or ((eq (H : mat_Point)) (G : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                     (DISCH `((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `((((col (G : mat_Point)) (H : mat_Point)) (A : mat_Point)) ==> mat_false) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                        (DISCH `mat_not (((col (G : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                         (MP  
                          (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                           (DISCH `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                            (MP  
                             (DISCH `(((tS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                              (MP  
                               (DISCH `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                (MP  
                                 (DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                  (MP  
                                   (DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                    (MP  
                                     (DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                      (MP  
                                       (DISCH `(((tS (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                        (MP  
                                         (DISCH `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                          (MP  
                                           (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                            )
                                           ) (MP  
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (SPEC `(H : mat_Point)` 
                                                  (SPEC `(G : mat_Point)` 
                                                   (SPEC `(D : mat_Point)` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (SPEC `(B : mat_Point)` 
                                                      (SPEC `(A : mat_Point)` 
                                                       (proposition__27))))))
                                                 ) (ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                 )
                                                ) (ASSUME `((betS (C : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                )
                                               ) (ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                               )
                                              ) (ASSUME `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                              )))
                                         ) (MP  
                                            (SPEC `(A : mat_Point)` 
                                             (SPEC `(D : mat_Point)` 
                                              (SPEC `(H : mat_Point)` 
                                               (SPEC `(G : mat_Point)` 
                                                (lemma__oppositesidesymmetric
                                                ))))
                                            ) (ASSUME `(((tS (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                            )))
                                       ) (MP  
                                          (MP  
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(D : mat_Point)` 
                                              (SPEC `(H : mat_Point)` 
                                               (SPEC `(G : mat_Point)` 
                                                (lemma__planeseparation)))))
                                           ) (ASSUME `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                           )
                                          ) (ASSUME `(((tS (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                          )))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(H : mat_Point)` 
                                           (SPEC `(G : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (SPEC `(G : mat_Point)` 
                                              (SPEC `(E : mat_Point)` 
                                               (SPEC `(H : mat_Point)` 
                                                (SPEC `(G : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (lemma__equalanglestransitive
                                                  )))))))))
                                         ) (ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                         )
                                        ) (ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                        )))
                                   ) (MP  
                                      (SPEC `(H : mat_Point)` 
                                       (SPEC `(G : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(G : mat_Point)` 
                                           (SPEC `(E : mat_Point)` 
                                            (lemma__equalanglessymmetric)))))
                                       )
                                      ) (ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                      )))
                                 ) (MP  
                                    (MP  
                                     (MP  
                                      (SPEC `(G : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(H : mat_Point)` 
                                          (SPEC `(E : mat_Point)` 
                                           (proposition__15a)))))
                                      ) (ASSUME `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                      )
                                     ) (ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                     )
                                    ) (ASSUME `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                    )))
                               ) (MP  
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(G : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (axiom__betweennesssymmetry)))
                                  ) (ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                  )))
                             ) (MP  
                                (SPEC `(B : mat_Point)` 
                                 (SPEC `(A : mat_Point)` 
                                  (SPEC `(H : mat_Point)` 
                                   (SPEC `(G : mat_Point)` 
                                    (lemma__oppositesidesymmetric))))
                                ) (ASSUME `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                ))))
                          ) (MP  
                             (SPEC `(G : mat_Point)` 
                              (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))))))` 
                               (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__intro)))
                              )
                             ) (MP  
                                (MP  
                                 (SPEC `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                  (SPEC `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                   (conj))
                                 ) (ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                 )
                                ) (MP  
                                   (MP  
                                    (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                     (SPEC `((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                      (conj))
                                    ) (ASSUME `((col (G : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                    )
                                   ) (MP  
                                      (SPEC `(A : mat_Point)` 
                                       (SPEC `(H : mat_Point)` 
                                        (SPEC `(G : mat_Point)` 
                                         (nCol__notCol)))
                                      ) (ASSUME `mat_not (((col (G : mat_Point)) (H : mat_Point)) (A : mat_Point))`
                                      )))))))
                       ) (DISCH `((col (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                          (MP  
                           (DISCH `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (G : mat_Point))) ((mat_or ((eq (E : mat_Point)) (H : mat_Point))) ((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or (((betS (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_or (((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point))) (((betS (E : mat_Point)) (H : mat_Point)) (G : mat_Point))))))) ==> mat_false` 
                              (DISCH `((col (E : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                               (MP  
                                (DISCH `((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                 (MP  
                                  (DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                   (MP  
                                    (DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                     (MP  
                                      (DISCH `((col (G : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                       (MP  
                                        (DISCH `((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (G : mat_Point))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (G : mat_Point)) (B : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))))) ==> mat_false` 
                                           (DISCH `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                            (MP  
                                             (DISCH `(neq (A : mat_Point)) (G : mat_Point)` 
                                              (MP  
                                               (DISCH `((col (G : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                (MP  
                                                 (DISCH `((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(G : mat_Point)` 
                                                      (SPEC `(E : mat_Point)` 
                                                       (col__nCol__False)))
                                                    ) (ASSUME `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                    )
                                                   ) (ASSUME `((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                   ))
                                                 ) (MP  
                                                    (DISCH `(mat_and (((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point)))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                        (SPEC `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                         (SPEC `((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                          (DISCH `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point))))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                              (SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point)))` 
                                                               (SPEC `((col (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((col (E : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                (DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point)))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((col (B : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point)))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((col (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point))))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((col (E : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (E : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (E : mat_Point))) (((col (B : mat_Point)) (E : mat_Point)) (G : mat_Point)))))`
                                                      ))
                                                    ) (MP  
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(E : mat_Point)` 
                                                         (SPEC `(G : mat_Point)` 
                                                          (lemma__collinearorder
                                                          )))
                                                       ) (ASSUME `((col (G : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                       ))))
                                               ) (MP  
                                                  (CONV_CONV_rule `((((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (G : mat_Point)) (E : mat_Point)) (B : mat_Point))` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(E : mat_Point)` 
                                                     (SPEC `(G : mat_Point)` 
                                                      (not__nCol__Col))))
                                                  ) (DISCH `((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(E : mat_Point)` 
                                                         (SPEC `(G : mat_Point)` 
                                                          (col__nCol__False))
                                                        )
                                                       ) (ASSUME `((nCol (G : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                       )
                                                      ) (MP  
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (SPEC `(G : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (lemma__collinear4
                                                               ))))
                                                           ) (ASSUME `((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                           )
                                                          ) (ASSUME `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                          )
                                                         ) (ASSUME `(neq (A : mat_Point)) (G : mat_Point)`
                                                         ))))))
                                             ) (MP  
                                                (DISCH `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                    (SPEC `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                     (SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                                      (DISCH `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                          (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(neq (A : mat_Point)) (G : mat_Point)` 
                                                            (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                             (ASSUME `(neq (A : mat_Point)) (G : mat_Point)`
                                                             )))
                                                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                  ))
                                                ) (MP  
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(G : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (lemma__betweennotequal
                                                      )))
                                                   ) (ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                   )))))
                                          ) (MP  
                                             (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (G : mat_Point)) (B : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))))` 
                                              (SPEC `(eq (A : mat_Point)) (G : mat_Point)` 
                                               (or__intror))
                                             ) (MP  
                                                (SPEC `(mat_or ((eq (G : mat_Point)) (B : mat_Point))) ((mat_or (((betS (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))))` 
                                                 (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                  (or__intror))
                                                ) (MP  
                                                   (SPEC `(mat_or (((betS (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_or (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point)))` 
                                                    (SPEC `(eq (G : mat_Point)) (B : mat_Point)` 
                                                     (or__intror))
                                                   ) (MP  
                                                      (SPEC `(mat_or (((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point))` 
                                                       (SPEC `((betS (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                        (or__intror))
                                                      ) (MP  
                                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                          (SPEC `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                           (or__introl))
                                                         ) (ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                         )))))))
                                        ) (MP  
                                           (DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                               (SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point))))` 
                                                (SPEC `((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                 (DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point))))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                     (SPEC `(mat_and (((col (E : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point)))` 
                                                      (SPEC `((col (A : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((col (A : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                       (DISCH `(mat_and (((col (E : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                           (SPEC `(mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                                            (SPEC `((col (E : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (E : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                             (DISCH `(mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                                 (SPEC `((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                  (SPEC `((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                   (DISCH `((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                               ) (ASSUME `(mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (E : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point)))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point))))`
                                                   ))))
                                             ) (ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (E : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (E : mat_Point)) (A : mat_Point))) (((col (E : mat_Point)) (A : mat_Point)) (G : mat_Point)))))`
                                             ))
                                           ) (MP  
                                              (SPEC `(E : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(G : mat_Point)` 
                                                 (lemma__collinearorder)))
                                              ) (ASSUME `((col (G : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                              ))))
                                      ) (MP  
                                         (CONV_CONV_rule `((((nCol (G : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> mat_false) ==> (((col (G : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                          (SPEC `(E : mat_Point)` 
                                           (SPEC `(A : mat_Point)` 
                                            (SPEC `(G : mat_Point)` 
                                             (not__nCol__Col))))
                                         ) (DISCH `((nCol (G : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                            (MP  
                                             (MP  
                                              (SPEC `(E : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(G : mat_Point)` 
                                                 (col__nCol__False)))
                                              ) (ASSUME `((nCol (G : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                              )
                                             ) (MP  
                                                (MP  
                                                 (MP  
                                                  (SPEC `(E : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (SPEC `(G : mat_Point)` 
                                                     (SPEC `(H : mat_Point)` 
                                                      (lemma__collinear4))))
                                                  ) (ASSUME `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                  )
                                                 ) (ASSUME `((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                 )
                                                ) (ASSUME `(neq (H : mat_Point)) (G : mat_Point)`
                                                ))))))
                                    ) (MP  
                                       (SPEC `(H : mat_Point)` 
                                        (SPEC `(G : mat_Point)` 
                                         (lemma__inequalitysymmetric))
                                       ) (ASSUME `(neq (G : mat_Point)) (H : mat_Point)`
                                       )))
                                  ) (MP  
                                     (DISCH `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((neq (E : mat_Point)) (H : mat_Point)))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                         (SPEC `(mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((neq (E : mat_Point)) (H : mat_Point))` 
                                          (SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                           (DISCH `(mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((neq (E : mat_Point)) (H : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                               (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                (SPEC `(neq (E : mat_Point)) (G : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(neq (E : mat_Point)) (G : mat_Point)` 
                                                 (DISCH `(neq (E : mat_Point)) (H : mat_Point)` 
                                                  (ASSUME `(neq (G : mat_Point)) (H : mat_Point)`
                                                  )))
                                             ) (ASSUME `(mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((neq (E : mat_Point)) (H : mat_Point))`
                                             ))))
                                       ) (ASSUME `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (E : mat_Point)) (G : mat_Point))) ((neq (E : mat_Point)) (H : mat_Point)))`
                                       ))
                                     ) (MP  
                                        (SPEC `(H : mat_Point)` 
                                         (SPEC `(G : mat_Point)` 
                                          (SPEC `(E : mat_Point)` 
                                           (lemma__betweennotequal)))
                                        ) (ASSUME `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                        ))))
                                ) (MP  
                                   (DISCH `(mat_and (((col (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                       (SPEC `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point))))` 
                                        (SPEC `((col (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((col (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                         (DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                             (SPEC `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)))` 
                                              (SPEC `((col (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((col (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                               (DISCH `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                   (SPEC `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point))` 
                                                    (SPEC `((col (H : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((col (H : mat_Point)) (E : mat_Point)) (G : mat_Point)` 
                                                     (DISCH `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                         (SPEC `((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                          (SPEC `((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                           (DISCH `((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)` 
                                                            (ASSUME `((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point))))`
                                           ))))
                                     ) (ASSUME `(mat_and (((col (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and (((col (H : mat_Point)) (E : mat_Point)) (G : mat_Point))) ((mat_and (((col (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((col (H : mat_Point)) (G : mat_Point)) (E : mat_Point)))))`
                                     ))
                                   ) (MP  
                                      (SPEC `(H : mat_Point)` 
                                       (SPEC `(G : mat_Point)` 
                                        (SPEC `(E : mat_Point)` 
                                         (lemma__collinearorder)))
                                      ) (ASSUME `((col (E : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                      )))))
                             ) (MP  
                                (SPEC `(mat_or ((eq (E : mat_Point)) (H : mat_Point))) ((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or (((betS (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_or (((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point))) (((betS (E : mat_Point)) (H : mat_Point)) (G : mat_Point)))))` 
                                 (SPEC `(eq (E : mat_Point)) (G : mat_Point)` 
                                  (or__intror))
                                ) (MP  
                                   (SPEC `(mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or (((betS (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_or (((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point))) (((betS (E : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                    (SPEC `(eq (E : mat_Point)) (H : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or (((betS (G : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_or (((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point))) (((betS (E : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                       (SPEC `(eq (G : mat_Point)) (H : mat_Point)` 
                                        (or__intror))
                                      ) (MP  
                                         (SPEC `(mat_or (((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point))) (((betS (E : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                          (SPEC `((betS (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                           (or__intror))
                                         ) (MP  
                                            (SPEC `((betS (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                             (SPEC `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                              (or__introl))
                                            ) (ASSUME `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                            )))))))
                           ) (MP  
                              (DISCH `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))))` 
                               (MP  
                                (MP  
                                 (SPEC `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                  (SPEC `(mat_and (((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                   (SPEC `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                    (DISCH `(mat_and (((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                        (SPEC `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                         (SPEC `((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                          (DISCH `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                              (SPEC `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                               (SPEC `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                (DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                    (SPEC `((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                     (SPEC `((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                      (DISCH `((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                       (ASSUME `((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                       )))
                                                  ) (ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                                            ))))
                                      ) (ASSUME `(mat_and (((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point))))`
                                      ))))
                                ) (ASSUME `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((col (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((col (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((col (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))))`
                                ))
                              ) (MP  
                                 (SPEC `(A : mat_Point)` 
                                  (SPEC `(H : mat_Point)` 
                                   (SPEC `(G : mat_Point)` 
                                    (lemma__collinearorder)))
                                 ) (ASSUME `((col (G : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                 )))))))
                    ) (MP  
                       (SPEC `(mat_or ((eq (G : mat_Point)) (G : mat_Point))) ((mat_or ((eq (H : mat_Point)) (G : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point)))))` 
                        (SPEC `(eq (G : mat_Point)) (H : mat_Point)` 
                         (or__intror))
                       ) (MP  
                          (SPEC `(mat_or ((eq (H : mat_Point)) (G : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (G : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (G : mat_Point))) (((betS (G : mat_Point)) (G : mat_Point)) (H : mat_Point))))` 
                           (SPEC `(eq (G : mat_Point)) (G : mat_Point)` 
                            (or__introl))
                          ) (ASSUME `(eq (G : mat_Point)) (G : mat_Point)`)))
                   ))
                 ) (SPEC `(G : mat_Point)` 
                    (PINST [(`:mat_Point`,`:A`)] [] (eq__refl))))
               ) (MP  
                  (CONV_CONV_rule `((((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)) ==> (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                   (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (U : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))))))` 
                    (MP  
                     (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (U : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))))))` 
                      (MP  
                       (MP  
                        (SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (U : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))))))) ==> (return : bool)))` 
                          (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (U : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))))))))))))))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(x : mat_Point)` 
                           (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))))` 
                            (MP  
                             (MP  
                              (SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                               (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))))) ==> (return : bool)))` 
                                (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))))))))))))` 
                                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                              ) (GEN `(x0 : mat_Point)` 
                                 (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                     (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))) ==> (return : bool)))` 
                                      (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))))))))))` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (ex__ind))))
                                    ) (GEN `(x1 : mat_Point)` 
                                       (DISCH `ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                           (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. (((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))) ==> (return : bool)))` 
                                            (SPEC `\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))))))))` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (ex__ind))))
                                          ) (GEN `(x2 : mat_Point)` 
                                             (DISCH `(mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                 (SPEC `(mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))))))` 
                                                  (SPEC `((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point)` 
                                                   (DISCH `(mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `(mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))` 
                                                        (SPEC `((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point)` 
                                                         (DISCH `(mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `(mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                              (SPEC `((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point)` 
                                                               (DISCH `(mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                   (SPEC `(mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                  (DISCH `(mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point)))))))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))`
                                               ))))
                                         ) (ASSUME `ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))`
                                         ))))
                                   ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x0 : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))`
                                   ))))
                             ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (x : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (x : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))))`
                             ))))
                       ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (U : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))))))`
                       ))
                     ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (G : mat_Point)) (E : mat_Point)) (U : mat_Point))) ((mat_and (((out (G : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and (((out (H : mat_Point)) (G : mat_Point)) (u : mat_Point))) ((mat_and (((out (H : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (U : mat_Point)) (H : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (V : mat_Point)) (H : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (E : mat_Point)) (G : mat_Point)) (B : mat_Point))))))))))))))))`
                     )))
                  ) (ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                  )))
             ) (MP  
                (DISCH `(mat_and ((((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                 (MP  
                  (MP  
                   (SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                    (SPEC `(mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                     (SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                      (DISCH `(mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                       (MP  
                        (MP  
                         (SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                          (SPEC `(((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                           (SPEC `(((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                            (DISCH `(((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                             (ASSUME `(((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                             )))
                        ) (ASSUME `(mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                        ))))
                  ) (ASSUME `(mat_and ((((oS (D : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((oS (B : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((((oS (D : mat_Point)) (B : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                  ))
                ) (MP  
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(H : mat_Point)` 
                      (SPEC `(G : mat_Point)` (lemma__samesidesymmetric))))
                   ) (ASSUME `(((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                   )))))))))))))))
 ;;


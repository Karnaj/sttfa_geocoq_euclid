(*lemma__TTorder :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (((((((((tT A) B) C) D) E) F) G) H) ==> ((((((((tT C) D) A) B) E) F) G) H)))))))))`*)
let lemma__TTorder =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(G : mat_Point)` 
       (GEN `(H : mat_Point)` 
        (DISCH `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
         (MP  
          (CONV_CONV_rule `((((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> ((((((((tT (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
           (DISCH `ex (\ J : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)))))` 
            (MP  
             (MP  
              (SPEC `(((((((tT (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (x : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (x : mat_Point)))) ==> (return : bool))) ==> ((ex (\ J : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)))))) ==> (return : bool)))` 
                (SPEC `\ J : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point))))` 
                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
              ) (GEN `(J : mat_Point)` 
                 (DISCH `(mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)))` 
                  (MP  
                   (MP  
                    (SPEC `(((((((tT (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                     (SPEC `(mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point))` 
                      (SPEC `((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                       (DISCH `(mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point))` 
                        (MP  
                         (MP  
                          (SPEC `(((((((tT (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                           (SPEC `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                            (SPEC `(((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                             (DISCH `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                              (MP  
                               (DISCH `(((((tG (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                                (MP  
                                 (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (X : mat_Point)))))) ==> ((((((((tT (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                  (DISCH `(((((((tT (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                   (ASSUME `(((((((tT (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                   ))
                                 ) (MP  
                                    (SPEC `(J : mat_Point)` 
                                     (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (x : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (x : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (X : mat_Point)))))))` 
                                      (SPEC `\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (X : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (X : mat_Point))))` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (ex__intro))))
                                    ) (MP  
                                       (MP  
                                        (SPEC `(mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (J : mat_Point))` 
                                         (SPEC `((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point)` 
                                          (conj))
                                        ) (ASSUME `((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point)`
                                        )
                                       ) (MP  
                                          (MP  
                                           (SPEC `(((((tG (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (J : mat_Point)` 
                                            (SPEC `(((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                             (conj))
                                           ) (ASSUME `(((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                           )
                                          ) (ASSUME `(((((tG (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (J : mat_Point)`
                                          )))))
                               ) (MP  
                                  (SPEC `(J : mat_Point)` 
                                   (SPEC `(D : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (lemma__TGsymmetric))))))
                                  ) (ASSUME `(((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)`
                                  )))))
                         ) (ASSUME `(mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point))`
                         ))))
                   ) (ASSUME `(mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)))`
                   ))))
             ) (ASSUME `ex (\ J : mat_Point. ((mat_and (((betS (E : mat_Point)) (F : mat_Point)) (J : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (J : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((((tG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (J : mat_Point)))))`
             )))
          ) (ASSUME `(((((((tT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
          ))))))))))
 ;;


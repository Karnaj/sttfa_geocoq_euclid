(*lemma__collinearorder :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((col A) B) C) ==> ((mat_and (((col B) A) C)) ((mat_and (((col B) C) A)) ((mat_and (((col C) A) B)) ((mat_and (((col A) C) B)) (((col C) B) A))))))))`*)
let lemma__collinearorder =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
      (MP  
       (DISCH `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
        (MP  
         (DISCH `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
          (MP  
           (DISCH `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
            (MP  
             (DISCH `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
              (MP  
               (MP  
                (SPEC `(mat_and (((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                 (SPEC `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                  (conj))
                ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                )
               ) (MP  
                  (MP  
                   (SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                    (SPEC `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                     (conj))
                   ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                   )
                  ) (MP  
                     (MP  
                      (SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                       (SPEC `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                        (conj))
                      ) (ASSUME `((col (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                      )
                     ) (MP  
                        (MP  
                         (SPEC `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                          (SPEC `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                           (conj))
                         ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                         )
                        ) (ASSUME `((col (C : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                        )))))
             ) (MP  
                (SPEC `(B : mat_Point)` 
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__collinear2)))
                ) (ASSUME `((col (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                )))
           ) (MP  
              (SPEC `(C : mat_Point)` 
               (SPEC `(A : mat_Point)` 
                (SPEC `(B : mat_Point)` (lemma__collinear2)))
              ) (ASSUME `((col (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
              )))
         ) (MP  
            (SPEC `(C : mat_Point)` 
             (SPEC `(B : mat_Point)` 
              (SPEC `(A : mat_Point)` (lemma__collinear1)))
            ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
            )))
       ) (MP  
          (SPEC `(A : mat_Point)` 
           (SPEC `(C : mat_Point)` 
            (SPEC `(B : mat_Point)` (lemma__collinear2)))
          ) (ASSUME `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
          )))
     ) (MP  
        (SPEC `(C : mat_Point)` 
         (SPEC `(B : mat_Point)` (SPEC `(A : mat_Point)` (lemma__collinear2))
         )) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
        ))))))
 ;;


(*proposition__48A :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. (((((sQ A) B) C) D) ==> (((((sQ a) b) c) d) ==> (((((((((eF A) B) C) D) a) b) c) d) ==> ((((cong A) B) a) b)))))))))))`*)
let proposition__48A =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(a : mat_Point)` 
     (GEN `(b : mat_Point)` 
      (GEN `(c : mat_Point)` 
       (GEN `(d : mat_Point)` 
        (DISCH `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
         (DISCH `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
          (DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
           (MP  
            (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
             (MP  
              (DISCH `(((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
               (MP  
                (DISCH `(((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                 (MP  
                  (DISCH `(((((cong__3 (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                   (MP  
                    (DISCH `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                     (MP  
                      (DISCH `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                       (MP  
                        (DISCH `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (DISCH `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                           (MP  
                            (DISCH `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                             (MP  
                              (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (DISCH `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                 (MP  
                                  (DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                   (MP  
                                    (DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                     (MP  
                                      (DISCH `(((((eT (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                       (MP  
                                        (DISCH `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (MP  
                                          (DISCH `(((rE (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                           (MP  
                                            (DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                             (MP  
                                              (DISCH `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                               (MP  
                                                (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(((tS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((lt (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((((lt (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((lt (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> mat_false) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__trichotomy1
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((((lt (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((lt (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (d : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (b : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (d : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (d : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (d : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (d : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (d : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (b : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (d : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (d : mat_Point))) ((mat_and ((neq (b : mat_Point)) (a : mat_Point))) ((mat_and ((neq (d : mat_Point)) (b : mat_Point))) ((neq (d : mat_Point)) (a : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(((lt (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(e : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ f : mat_Point. ((mat_and (((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (a : mat_Point)) (x : mat_Point)) (d : mat_Point))) ((((cong (a : mat_Point)) (x : mat_Point)) (A : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ f : mat_Point. ((mat_and (((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ f : mat_Point. ((mat_and (((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(f : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (d : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (a : mat_Point)) (b : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (f : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (f : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (f : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((((cong__3 (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (f : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `((triangle (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((((eT (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) (a : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((eT (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((((eT (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) (a : mat_Point)) (e : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) (a : mat_Point)) (e : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    axiom__deZolt2
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((triangle (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    axiom__ETtransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    axiom__congruentequal
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((cong__3 (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cong (f : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (f : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (f : mat_Point)) (e : mat_Point)) (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (f : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (f : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (f : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (f : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (f : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (f : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (f : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (f : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (f : mat_Point)) (a : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((cong (f : mat_Point)) (a : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))))))))))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(a0 : mat_Point)` 
                                                                    (
                                                                    GEN `(b0 : mat_Point)` 
                                                                    (
                                                                    GEN `(c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) (b0 : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) (b0 : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(b0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(a0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    lemma__Euclid4
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((per (f : mat_Point)) (a : mat_Point)) (e : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__equaltorightisright
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (f : mat_Point)) (a : mat_Point)) (e : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (f : mat_Point)) (a : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (d : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (d : mat_Point)) (f : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (a : mat_Point)) (b : mat_Point)) (e : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((nCol (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) (((nCol (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (e : mat_Point)) (b : mat_Point))) (((betS (a : mat_Point)) (b : mat_Point)) (e : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (f : mat_Point)) (d : mat_Point))) (((betS (a : mat_Point)) (d : mat_Point)) (f : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (a : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (e : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (e : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (e : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (e : mat_Point)) (b : mat_Point))) ((mat_and ((neq (a : mat_Point)) (e : mat_Point))) ((neq (a : mat_Point)) (b : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(e : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (f : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (f : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (a : mat_Point)) (f : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (f : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (f : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (a : mat_Point)) (f : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (a : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (a : mat_Point)) (f : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (a : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (a : mat_Point)) (f : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (f : mat_Point)) (d : mat_Point))) ((mat_and ((neq (a : mat_Point)) (f : mat_Point))) ((neq (a : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(f : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ f : mat_Point. ((mat_and (((betS (a : mat_Point)) (f : mat_Point)) (d : mat_Point))) ((((cong (a : mat_Point)) (f : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ e : mat_Point. ((mat_and (((betS (a : mat_Point)) (e : mat_Point)) (b : mat_Point))) ((((cong (a : mat_Point)) (e : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    DISCH `(((lt (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (a : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((lt (a : mat_Point)) (d : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((lt (a : mat_Point)) (d : mat_Point)) (A : mat_Point)) (D : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (a : mat_Point)) (d : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (d : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (a : mat_Point)) (d : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (a : mat_Point)) (d : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)))) ==> mat_false` 
                                                                    (
                                                                    DISCH `(((((cong__3 (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((eT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `((triangle (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((((eT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((eT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((((((eT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    axiom__deZolt2
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((triangle (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__ETtransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((eT (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__ETsymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__ETpermutation
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((eT (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__congruentequal
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((cong__3 (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((cong (F : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (E : mat_Point)) (d : mat_Point)) (b : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (F : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (F : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (F : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (F : mat_Point)) (A : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! a0 : mat_Point. (! b0 : mat_Point. (! c0 : mat_Point. (((((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> (((((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))))))))))`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (F : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(a0 : mat_Point)` 
                                                                    (
                                                                    GEN `(b0 : mat_Point)` 
                                                                    (
                                                                    GEN `(c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) (b0 : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point))) ((((((congA (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)) (b0 : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((cong (B0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (c0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(c0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(b0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(a0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (a0 : mat_Point)) (b0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B0 : mat_Point)) (A0 : mat_Point)) (C0 : mat_Point)) (b0 : mat_Point)) (a0 : mat_Point)) (c0 : mat_Point)`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__Euclid4
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((per (F : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equaltorightisright
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (F : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (F : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) (((nCol (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (F : mat_Point))) ((neq (A : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (a : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (A : mat_Point)) (F : mat_Point)) (D : mat_Point))) ((((cong (A : mat_Point)) (F : mat_Point)) (a : mat_Point)) (d : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (a : mat_Point)) (d : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (a : mat_Point)) (d : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__lessthancongruence2
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((lt (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (A : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (E : mat_Point)) (a : mat_Point)) (b : mat_Point))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((lt (a : mat_Point)) (b : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (DISCH `(mat_and ((((cong (b : mat_Point)) (a : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (a : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (a : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (a : mat_Point)) (a : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cong (a : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)))`
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(a : mat_Point)` 
                                                                   (SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)`
                                                                  ))))
                                                                ) (MP  
                                                                   (CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    )))))
                                                                   ) (
                                                                   ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                   )))
                                                              ) (MP  
                                                                 (CONV_CONV_rule `((((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                  (MP  
                                                                   (SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                   (DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((cong (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and (((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))))))`
                                                                    )))))
                                                                 ) (ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                 )))
                                                            ) (MP  
                                                               (MP  
                                                                (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(d : mat_Point)` 
                                                                    (
                                                                    SPEC `(b : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__halvesofequals
                                                                    ))))))))
                                                                   ) (
                                                                   ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(((((eT (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                 )
                                                                ) (ASSUME `(((tS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                )
                                                               ) (ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                               )))
                                                          ) (MP  
                                                             (DISCH `(mat_and ((((tS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and ((((tS (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((tS (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((tS (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((tS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                 (SPEC `(mat_and ((((tS (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((tS (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((tS (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                  (SPEC `(((tS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((tS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                   (DISCH `(mat_and ((((tS (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((tS (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((tS (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tS (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((tS (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tS (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tS (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tS (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((tS (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tS (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tS (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tS (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tS (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((tS (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tS (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((tS (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((tS (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((tS (a : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))) ((mat_and ((((tS (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((tS (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((tS (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))))`
                                                               ))
                                                             ) (MP  
                                                                (MP  
                                                                 (SPEC `(d : mat_Point)` 
                                                                  (SPEC `(b : mat_Point)` 
                                                                   (SPEC `(c : mat_Point)` 
                                                                    (
                                                                    SPEC `(a : mat_Point)` 
                                                                    (
                                                                    lemma__crossimpliesopposite
                                                                    ))))
                                                                 ) (ASSUME `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                 )
                                                                ) (ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                ))))
                                                        ) (MP  
                                                           (DISCH `(mat_and ((((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                               (SPEC `(mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                (SPEC `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                 (DISCH `(mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                             ))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(B : mat_Point)` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (lemma__crossimpliesopposite
                                                                   ))))
                                                               ) (ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                               )
                                                              ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                              ))))
                                                      ) (MP  
                                                         (DISCH `(mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                             (SPEC `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                              (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                               (DISCH `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                   (SPEC `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                  (DISCH `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((nCol (a : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((nCol (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (d : mat_Point))))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(d : mat_Point)` 
                                                             (SPEC `(c : mat_Point)` 
                                                              (SPEC `(b : mat_Point)` 
                                                               (SPEC `(a : mat_Point)` 
                                                                (lemma__parallelNC
                                                                ))))
                                                            ) (ASSUME `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (CONV_CONV_rule `((((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                        (MP  
                                                         (SPEC `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                          (SPEC `(((par (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                           (SPEC `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                            (DISCH `(((par (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                             (MP  
                                                              (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))` 
                                                               (MP  
                                                                (SPEC `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                 (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                    ))))
                                                              ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                              )))))
                                                       ) (ASSUME `(((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                         (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                          (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                               (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                   ) (
                                                                   ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                       ))
                                                     ) (MP  
                                                        (SPEC `(D : mat_Point)` 
                                                         (SPEC `(C : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (lemma__parallelNC
                                                            ))))
                                                        ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                        ))))
                                                ) (MP  
                                                   (CONV_CONV_rule `((((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                    (MP  
                                                     (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `(((par (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                       (SPEC `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((par (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                        (DISCH `(((par (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                           (MP  
                                                            (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                             (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                ))))
                                                          ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                          )))))
                                                   ) (ASSUME `(((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                   )))
                                              ) (MP  
                                                 (CONV_CONV_rule `((((rE (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                  (MP  
                                                   (SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                    (SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                                     (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                      (DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                          (SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                           (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                            (DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                (SPEC `(mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                 (SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                  (DISCH `(mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                                              ))))
                                                        ) (ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))))`
                                                        )))))
                                                 ) (ASSUME `(((rE (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                 )))
                                            ) (MP  
                                               (CONV_CONV_rule `((((rE (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                (MP  
                                                 (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                                   (SPEC `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((per (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                    (DISCH `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                        (SPEC `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                         (SPEC `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                          (DISCH `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                              (SPEC `(mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                               (SPEC `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                                (DISCH `(mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                                   (DISCH `(((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((per (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and (((per (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((mat_and (((per (c : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((((cR (a : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))))`
                                                      )))))
                                               ) (ASSUME `(((rE (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                               )))
                                          ) (MP  
                                             (SPEC `(d : mat_Point)` 
                                              (SPEC `(c : mat_Point)` 
                                               (SPEC `(b : mat_Point)` 
                                                (SPEC `(a : mat_Point)` 
                                                 (lemma__squarerectangle))))
                                             ) (ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                             )))
                                        ) (MP  
                                           (SPEC `(D : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(A : mat_Point)` 
                                               (lemma__squarerectangle))))
                                           ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                           )))
                                      ) (MP  
                                         (SPEC `(d : mat_Point)` 
                                          (SPEC `(b : mat_Point)` 
                                           (SPEC `(a : mat_Point)` 
                                            (SPEC `(c : mat_Point)` 
                                             (SPEC `(d : mat_Point)` 
                                              (SPEC `(b : mat_Point)` 
                                               (axiom__ETsymmetric))))))
                                         ) (ASSUME `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                         )))
                                    ) (MP  
                                       (DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                           (SPEC `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                            (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                             (DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                 (SPEC `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                  (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point)` 
                                                   (DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                       (SPEC `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                        (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                         (DISCH `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                             (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                              (SPEC `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                               (DISCH `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)` 
                                                                (ASSUME `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))`
                                                     ))))
                                               ) (ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point))))`
                                               ))))
                                         ) (ASSUME `(mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)) (a : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (a : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (a : mat_Point)) (b : mat_Point))) ((((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)) (a : mat_Point)))))`
                                         ))
                                       ) (MP  
                                          (SPEC `(d : mat_Point)` 
                                           (SPEC `(a : mat_Point)` 
                                            (SPEC `(b : mat_Point)` 
                                             (SPEC `(c : mat_Point)` 
                                              (SPEC `(d : mat_Point)` 
                                               (SPEC `(b : mat_Point)` 
                                                (axiom__ETpermutation))))))
                                          ) (ASSUME `(((((eT (b : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                          ))))
                                  ) (MP  
                                     (SPEC `(c : mat_Point)` 
                                      (SPEC `(d : mat_Point)` 
                                       (SPEC `(b : mat_Point)` 
                                        (SPEC `(d : mat_Point)` 
                                         (SPEC `(a : mat_Point)` 
                                          (SPEC `(b : mat_Point)` 
                                           (axiom__ETsymmetric))))))
                                     ) (ASSUME `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                     )))
                                ) (MP  
                                   (DISCH `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                       (SPEC `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))))` 
                                        (SPEC `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                         (DISCH `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                             (SPEC `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)))` 
                                              (SPEC `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                               (DISCH `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                   (SPEC `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))` 
                                                    (SPEC `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                     (DISCH `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                         (SPEC `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                          (SPEC `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                                           (DISCH `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)` 
                                                            (ASSUME `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)`
                                                            )))
                                                       ) (ASSUME `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))`
                                                       ))))
                                                 ) (ASSUME `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)))`
                                                 ))))
                                           ) (ASSUME `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point))))`
                                           ))))
                                     ) (ASSUME `(mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (c : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((mat_and ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point))) ((((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (b : mat_Point)) (d : mat_Point)) (c : mat_Point)))))`
                                     ))
                                   ) (MP  
                                      (SPEC `(b : mat_Point)` 
                                       (SPEC `(c : mat_Point)` 
                                        (SPEC `(d : mat_Point)` 
                                         (SPEC `(d : mat_Point)` 
                                          (SPEC `(a : mat_Point)` 
                                           (SPEC `(b : mat_Point)` 
                                            (axiom__ETpermutation))))))
                                      ) (ASSUME `(((((eT (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                      ))))
                              ) (MP  
                                 (SPEC `(D : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(D : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (axiom__ETsymmetric))))))
                                 ) (ASSUME `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                 )))
                            ) (MP  
                               (DISCH `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                (MP  
                                 (MP  
                                  (SPEC `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                   (SPEC `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                    (SPEC `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                     (DISCH `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                         (SPEC `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                          (SPEC `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                           (DISCH `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                               (SPEC `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                (SPEC `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                     (SPEC `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                      (SPEC `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                       (DISCH `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                        (ASSUME `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                        )))
                                                   ) (ASSUME `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                   ))))
                                             ) (ASSUME `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                             ))))
                                       ) (ASSUME `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                       ))))
                                 ) (ASSUME `(mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                 ))
                               ) (MP  
                                  (SPEC `(D : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (SPEC `(B : mat_Point)` 
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (axiom__ETpermutation))))))
                                  ) (ASSUME `(((((eT (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                  ))))
                          ) (MP  
                             (SPEC `(C : mat_Point)` 
                              (SPEC `(D : mat_Point)` 
                               (SPEC `(B : mat_Point)` 
                                (SPEC `(D : mat_Point)` 
                                 (SPEC `(A : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (axiom__ETsymmetric))))))
                             ) (ASSUME `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                             )))
                        ) (MP  
                           (DISCH `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                            (MP  
                             (MP  
                              (SPEC `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                               (SPEC `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                (SPEC `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                 (DISCH `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                      (SPEC `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (DISCH `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                            (SPEC `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                             (DISCH `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                              (MP  
                                               (MP  
                                                (SPEC `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (DISCH `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (ASSUME `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                    )))
                                               ) (ASSUME `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                               ))))
                                         ) (ASSUME `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                         ))))
                                   ) (ASSUME `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                   ))))
                             ) (ASSUME `(mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                             ))
                           ) (MP  
                              (SPEC `(B : mat_Point)` 
                               (SPEC `(C : mat_Point)` 
                                (SPEC `(D : mat_Point)` 
                                 (SPEC `(D : mat_Point)` 
                                  (SPEC `(A : mat_Point)` 
                                   (SPEC `(B : mat_Point)` 
                                    (axiom__ETpermutation))))))
                              ) (ASSUME `(((((eT (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                              ))))
                      ) (MP  
                         (SPEC `(b : mat_Point)` 
                          (SPEC `(c : mat_Point)` 
                           (SPEC `(d : mat_Point)` 
                            (SPEC `(d : mat_Point)` 
                             (SPEC `(a : mat_Point)` 
                              (SPEC `(b : mat_Point)` (axiom__congruentequal)
                              )))))
                         ) (ASSUME `(((((cong__3 (b : mat_Point)) (a : mat_Point)) (d : mat_Point)) (d : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                         )))
                    ) (MP  
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(C : mat_Point)` 
                         (SPEC `(D : mat_Point)` 
                          (SPEC `(D : mat_Point)` 
                           (SPEC `(A : mat_Point)` 
                            (SPEC `(B : mat_Point)` (axiom__congruentequal)))
                          )))
                       ) (ASSUME `(((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                       )))
                  ) (MP  
                     (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))))` 
                      (MP  
                       (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))))` 
                        (MP  
                         (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))` 
                          (MP  
                           (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))` 
                            (MP  
                             (SPEC `(c : mat_Point)` 
                              (SPEC `(b : mat_Point)` 
                               (SPEC `(d : mat_Point)` 
                                (SPEC `(a : mat_Point)` 
                                 (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))`
                                 ))))
                             ) (ASSUME `(((pG (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                             ))
                           ) (GEN `(A0 : mat_Point)` 
                              (GEN `(B0 : mat_Point)` 
                               (GEN `(C0 : mat_Point)` 
                                (GEN `(D0 : mat_Point)` 
                                 (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                     (SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                      (SPEC `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                       (DISCH `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                        (ASSUME `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)`
                                        )))
                                   ) (MP  
                                      (SPEC `(D0 : mat_Point)` 
                                       (SPEC `(C0 : mat_Point)` 
                                        (SPEC `(B0 : mat_Point)` 
                                         (SPEC `(A0 : mat_Point)` 
                                          (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))`
                                          ))))
                                      ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                      )))))))))
                         ) (GEN `(A0 : mat_Point)` 
                            (GEN `(B0 : mat_Point)` 
                             (GEN `(C0 : mat_Point)` 
                              (GEN `(D0 : mat_Point)` 
                               (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                (MP  
                                 (MP  
                                  (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                   (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                    (SPEC `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                     (DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                      (ASSUME `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))`
                                      )))
                                 ) (MP  
                                    (SPEC `(D0 : mat_Point)` 
                                     (SPEC `(C0 : mat_Point)` 
                                      (SPEC `(B0 : mat_Point)` 
                                       (SPEC `(A0 : mat_Point)` 
                                        (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))))))))`
                                        ))))
                                    ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                    )))))))))
                       ) (GEN `(A0 : mat_Point)` 
                          (GEN `(B0 : mat_Point)` 
                           (GEN `(C0 : mat_Point)` 
                            (GEN `(D0 : mat_Point)` 
                             (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                              (MP  
                               (MP  
                                (SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                 (SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                  (SPEC `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                   (DISCH `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                    (ASSUME `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))`
                                    )))
                               ) (MP  
                                  (SPEC `(D0 : mat_Point)` 
                                   (SPEC `(C0 : mat_Point)` 
                                    (SPEC `(B0 : mat_Point)` 
                                     (SPEC `(A0 : mat_Point)` 
                                      (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((cong (A00 : mat_Point)) (C00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point))) ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))))`
                                      ))))
                                  ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                  )))))))))
                     ) (GEN `(A0 : mat_Point)` 
                        (GEN `(B0 : mat_Point)` 
                         (GEN `(C0 : mat_Point)` 
                          (GEN `(D0 : mat_Point)` 
                           (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                            (MP  
                             (MP  
                              (SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                               (SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                (SPEC `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                 (DISCH `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                  (ASSUME `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))`
                                  )))
                             ) (MP  
                                (SPEC `(D0 : mat_Point)` 
                                 (SPEC `(C0 : mat_Point)` 
                                  (SPEC `(B0 : mat_Point)` 
                                   (SPEC `(A0 : mat_Point)` (proposition__34)
                                   )))
                                ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                ))))))))))
                ) (MP  
                   (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))))` 
                    (MP  
                     (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))))` 
                      (MP  
                       (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))))))` 
                        (MP  
                         (DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))` 
                          (MP  
                           (SPEC `(C : mat_Point)` 
                            (SPEC `(B : mat_Point)` 
                             (SPEC `(D : mat_Point)` 
                              (SPEC `(A : mat_Point)` 
                               (ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (((((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)) ==> ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))))`
                               ))))
                           ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                           ))
                         ) (GEN `(A0 : mat_Point)` 
                            (GEN `(B0 : mat_Point)` 
                             (GEN `(C0 : mat_Point)` 
                              (GEN `(D0 : mat_Point)` 
                               (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                                (MP  
                                 (MP  
                                  (SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                   (SPEC `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                    (SPEC `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point)` 
                                     (DISCH `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                      (ASSUME `(((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)`
                                      )))
                                 ) (MP  
                                    (SPEC `(D0 : mat_Point)` 
                                     (SPEC `(C0 : mat_Point)` 
                                      (SPEC `(B0 : mat_Point)` 
                                       (SPEC `(A0 : mat_Point)` 
                                        (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))`
                                        ))))
                                    ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                    )))))))))
                       ) (GEN `(A0 : mat_Point)` 
                          (GEN `(B0 : mat_Point)` 
                           (GEN `(C0 : mat_Point)` 
                            (GEN `(D0 : mat_Point)` 
                             (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                              (MP  
                               (MP  
                                (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                 (SPEC `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                  (SPEC `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)` 
                                   (DISCH `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))` 
                                    (ASSUME `(mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))`
                                    )))
                               ) (MP  
                                  (SPEC `(D0 : mat_Point)` 
                                   (SPEC `(C0 : mat_Point)` 
                                    (SPEC `(B0 : mat_Point)` 
                                     (SPEC `(A0 : mat_Point)` 
                                      (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))))))))`
                                      ))))
                                  ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                  )))))))))
                     ) (GEN `(A0 : mat_Point)` 
                        (GEN `(B0 : mat_Point)` 
                         (GEN `(C0 : mat_Point)` 
                          (GEN `(D0 : mat_Point)` 
                           (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                            (MP  
                             (MP  
                              (SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                               (SPEC `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                (SPEC `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)` 
                                 (DISCH `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))` 
                                  (ASSUME `(mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)))`
                                  )))
                             ) (MP  
                                (SPEC `(D0 : mat_Point)` 
                                 (SPEC `(C0 : mat_Point)` 
                                  (SPEC `(B0 : mat_Point)` 
                                   (SPEC `(A0 : mat_Point)` 
                                    (ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (((((pG (A00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) (B00 : mat_Point)) ==> ((mat_and ((((cong (A00 : mat_Point)) (C00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point))) ((mat_and ((((((congA (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point))) ((mat_and ((((((congA (A00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)) (A00 : mat_Point))) ((((((cong__3 (C00 : mat_Point)) (A00 : mat_Point)) (B00 : mat_Point)) (B00 : mat_Point)) (D00 : mat_Point)) (C00 : mat_Point)))))))))`
                                    ))))
                                ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                                )))))))))
                   ) (GEN `(A0 : mat_Point)` 
                      (GEN `(B0 : mat_Point)` 
                       (GEN `(C0 : mat_Point)` 
                        (GEN `(D0 : mat_Point)` 
                         (DISCH `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)` 
                          (MP  
                           (MP  
                            (SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                             (SPEC `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                              (SPEC `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(((cong (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                               (DISCH `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))` 
                                (ASSUME `(mat_and ((((cong (A0 : mat_Point)) (C0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point))) ((mat_and ((((((congA (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))) ((mat_and ((((((congA (A0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point)) (A0 : mat_Point))) ((((((cong__3 (C0 : mat_Point)) (A0 : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) (D0 : mat_Point)) (C0 : mat_Point))))`
                                )))
                           ) (MP  
                              (SPEC `(D0 : mat_Point)` 
                               (SPEC `(C0 : mat_Point)` 
                                (SPEC `(B0 : mat_Point)` 
                                 (SPEC `(A0 : mat_Point)` (proposition__34)))
                               )
                              ) (ASSUME `(((pG (A0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) (B0 : mat_Point)`
                              ))))))))))
              ) (MP  
                 (SPEC `(d : mat_Point)` 
                  (SPEC `(c : mat_Point)` 
                   (SPEC `(b : mat_Point)` 
                    (SPEC `(a : mat_Point)` (lemma__squareparallelogram))))
                 ) (ASSUME `(((sQ (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                 )))
            ) (MP  
               (SPEC `(D : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__squareparallelogram))))
               ) (ASSUME `(((sQ (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
               )))))))))))))
 ;;


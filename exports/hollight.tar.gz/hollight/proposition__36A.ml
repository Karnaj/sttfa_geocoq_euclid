(*proposition__36A :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (! M : mat_Point. (((((pG A) B) C) D) ==> (((((pG E) F) G) H) ==> ((((col A) D) E) ==> ((((col A) D) H) ==> ((((col B) C) F) ==> ((((col B) C) G) ==> (((((cong B) C) F) G) ==> ((((betS B) M) H) ==> ((((betS C) M) E) ==> ((((((((eF A) B) C) D) E) F) G) H))))))))))))))))))`*)
let proposition__36A =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(G : mat_Point)` 
       (GEN `(H : mat_Point)` 
        (GEN `(M : mat_Point)` 
         (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
          (DISCH `(((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
           (DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
            (DISCH `((col (A : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
             (DISCH `((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
              (DISCH `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
               (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                 (DISCH `((betS (C : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                  (MP  
                   (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                    (MP  
                     (DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                      (MP  
                       (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                        (MP  
                         (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                          (MP  
                           (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (MP  
                             (DISCH `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                              (MP  
                               (DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                (MP  
                                 (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                  (MP  
                                   (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                    (MP  
                                     (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                        (MP  
                                         (DISCH `(neq (E : mat_Point)) (H : mat_Point)` 
                                          (MP  
                                           (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                            (MP  
                                             (DISCH `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))` 
                                              (MP  
                                               (DISCH `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `((mat_and ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                                                    (DISCH `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                       (MP  
                                                        (DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (DISCH `(((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(((pG (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                             (MP  
                                                              (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                 (MP  
                                                                  (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((pG (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__EFtransitive
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__EFsymmetric
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point))) ((mat_and ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (H : mat_Point)))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__EFpermutation
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    proposition__35
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((pG (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((pG (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((pG (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((pG (G : mat_Point)) (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__PGsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (B : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (B : mat_Point))) ((mat_and (((col (G : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (G : mat_Point)) (C : mat_Point))) (((col (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (B : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (F : mat_Point)) (B : mat_Point))) ((mat_and (((col (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((col (B : mat_Point)) (F : mat_Point)) (C : mat_Point))) (((col (F : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (C : mat_Point)) (G : mat_Point))) ((mat_and (((col (F : mat_Point)) (G : mat_Point)) (C : mat_Point))) ((mat_and (((col (G : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (G : mat_Point)) (F : mat_Point))) (((col (G : mat_Point)) (F : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (F : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (C : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                    )))
                                                                  ) (
                                                                  MP  
                                                                  (MP  
                                                                   (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                   (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                  )))
                                                                ) (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                   )))
                                                              ) (MP  
                                                                 (MP  
                                                                  (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                  (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (H : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (E : mat_Point)) (H : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                                 )))
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(((pG (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                  (SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                   (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((pG (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((pG (C : mat_Point)) (H : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__PGsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                               )))
                                                          ) (MP  
                                                             (MP  
                                                              (SPEC `(((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                (SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                 (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (G : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (G : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (G : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((((cong (F : mat_Point)) (G : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                             )))
                                                        ) (MP  
                                                           (MP  
                                                            (SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                              (SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                               (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                  (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                           )))
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                           (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                            (SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                             (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                 (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                  (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                   (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((((eF (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__35
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                               ))))
                                                         ) (ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                         ))))
                                                   ) (MP  
                                                      (MP  
                                                       (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                         (conj))
                                                       ) (ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                      )))
                                                 ) (MP  
                                                    (MP  
                                                     (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                       (SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                        (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                             (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                              (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                ))))
                                                          ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                    )))
                                               ) (MP  
                                                  (MP  
                                                   (SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                    (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                     (SPEC `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                      (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                          (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                           (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                            (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                  (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and ((((par (B : mat_Point)) (E : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((par (E : mat_Point)) (B : mat_Point)) (H : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                              ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))`
                                                  )))
                                             ) (MP  
                                                (MP  
                                                 (SPEC `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))` 
                                                  (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                   (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                    (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(mat_and ((((par (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (H : mat_Point))` 
                                                        (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                          (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (MP  
                                                            (MP  
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(M : mat_Point)` 
                                                                (SPEC `(H : mat_Point)` 
                                                                 (SPEC `(E : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__33
                                                                    )))))
                                                               ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                               )
                                                              ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                              )
                                                             ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (H : mat_Point)`
                                                             )
                                                            ) (ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                                )))
                                           ) (MP  
                                              (MP  
                                               (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                 (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                  (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                      (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(H : mat_Point)` 
                                                              (SPEC `(E : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (SPEC `(C : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (lemma__collinearparallel2
                                                                   ))))))
                                                             ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                             )
                                                            ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                                            )
                                                           ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                           )
                                                          ) (ASSUME `(neq (E : mat_Point)) (H : mat_Point)`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                              )))
                                         ) (MP  
                                            (MP  
                                             (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                              (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                               (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                    (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(H : mat_Point)` 
                                                          (SPEC `(E : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (axiom__nocollapse
                                                             ))))
                                                         ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                            )))
                                       ) (MP  
                                          (MP  
                                           (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                             (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                              (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                    (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                           (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                            (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                 (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                              ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                                        ))
                                                      ) (MP  
                                                         (SPEC `(C : mat_Point)` 
                                                          (SPEC `(B : mat_Point)` 
                                                           (SPEC `(A : mat_Point)` 
                                                            (lemma__NCdistinct
                                                            )))
                                                         ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                         )))))
                                                ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                          )))
                                     ) (MP  
                                        (MP  
                                         (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                           (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                            (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                             (MP  
                                              (MP  
                                               (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                         (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                          (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (SPEC `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                               (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (DISCH `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  ASSUME `(mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                            ))))
                                                      ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                      ))
                                                    ) (MP  
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (SPEC `(D : mat_Point)` 
                                                          (SPEC `(A : mat_Point)` 
                                                           (lemma__parallelNC
                                                           ))))
                                                       ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                       )))))
                                              ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                        )))
                                   ) (MP  
                                      (MP  
                                       (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                        (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                         (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                          (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                              (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(D : mat_Point)` 
                                                     (SPEC `(A : mat_Point)` 
                                                      (lemma__parallelsymmetric
                                                      ))))
                                                  ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                  ))))
                                            ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                      )))
                                 ) (MP  
                                    (MP  
                                     (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                      (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                       (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                        (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                         (MP  
                                          (MP  
                                           (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                            (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(H : mat_Point)` 
                                                  (SPEC `(E : mat_Point)` 
                                                   (SPEC `(G : mat_Point)` 
                                                    (SPEC `(F : mat_Point)` 
                                                     (SPEC `(C : mat_Point)` 
                                                      (SPEC `(B : mat_Point)` 
                                                       (lemma__congruencetransitive
                                                       ))))))
                                                 ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                 )
                                                ) (ASSUME `(((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)`
                                                ))))
                                          ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                    )))
                               ) (MP  
                                  (MP  
                                   (SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                    (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                     (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                      (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((cong (F : mat_Point)) (G : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                          (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (SPEC `(G : mat_Point)` 
                                               (SPEC `(H : mat_Point)` 
                                                (SPEC `(E : mat_Point)` 
                                                 (SPEC `(F : mat_Point)` 
                                                  (lemma__congruencesymmetric
                                                  ))))
                                              ) (ASSUME `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                              ))))
                                        ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                  )))
                             ) (MP  
                                (MP  
                                 (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                  (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                   (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                    (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                     (MP  
                                      (MP  
                                       (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                        (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (DISCH `(mat_and ((((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                (SPEC `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))))` 
                                                 (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                  (DISCH `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                      (SPEC `(mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                       (SPEC `(((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                        (DISCH `(mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                            (SPEC `(mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                             (SPEC `(((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                              (DISCH `(mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                                  (SPEC `(((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                   (SPEC `(((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                ) (ASSUME `(mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))`
                                                                ))))
                                                          ) (ASSUME `(mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((cong (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))) ((mat_and ((((cong (E : mat_Point)) (F : mat_Point)) (H : mat_Point)) (G : mat_Point))) ((mat_and ((((((congA (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (E : mat_Point)) (H : mat_Point)) (G : mat_Point)) (G : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((((((cong__3 (F : mat_Point)) (E : mat_Point)) (H : mat_Point)) (H : mat_Point)) (G : mat_Point)) (F : mat_Point)))))`
                                              ))
                                            ) (MP  
                                               (SPEC `(G : mat_Point)` 
                                                (SPEC `(F : mat_Point)` 
                                                 (SPEC `(H : mat_Point)` 
                                                  (SPEC `(E : mat_Point)` 
                                                   (proposition__34))))
                                               ) (ASSUME `(((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                               )))))
                                      ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                )))
                           ) (MP  
                              (MP  
                               (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                 (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                  (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                   (MP  
                                    (MP  
                                     (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (MP  
                                          (DISCH `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                               (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                     (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `(mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                           (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                            (DISCH `(mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                             (MP  
                                                              (MP  
                                                               (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                (SPEC `(((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                 (SPEC `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (and__ind))
                                                                )
                                                               ) (DISCH `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                   (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   )))
                                                              ) (ASSUME `(mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                              ))))
                                                        ) (ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                  ))))
                                            ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                            ))
                                          ) (MP  
                                             (SPEC `(C : mat_Point)` 
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(D : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (proposition__34))))
                                             ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                             )))))
                                    ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                    ))))
                              ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                              )))
                         ) (MP  
                            (MP  
                             (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                              (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                               (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                    (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                            (SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))` 
                                             (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                              (DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                  (SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))` 
                                                   (SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                    (DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                        (SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))` 
                                                         (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                          (DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))` 
                                                           (MP  
                                                            (MP  
                                                             (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                              (SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))` 
                                                               (SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                (and__ind)))
                                                             ) (DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                (DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                  ) (
                                                                  ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))`
                                                                  ))))
                                                            ) (ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))`
                                                            ))))
                                                      ) (ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))`
                                                ))))
                                          ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))))`
                                          ))
                                        ) (MP  
                                           (SPEC `(D : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(A : mat_Point)` 
                                              (lemma__NCdistinct)))
                                           ) (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                           )))))
                                  ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                  ))))
                            ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                            )))
                       ) (MP  
                          (MP  
                           (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                             (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                              (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                               (MP  
                                (MP  
                                 (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (MP  
                                      (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                           (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                 (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                  (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                        (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                         (ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                              ))))
                                        ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                        ))
                                      ) (MP  
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(C : mat_Point)` 
                                           (SPEC `(B : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (lemma__parallelNC))))
                                         ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                         )))))
                                ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                          )))
                     ) (MP  
                        (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                         (MP  
                          (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                           (MP  
                            (MP  
                             (SPEC `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                              (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (MP  
                                  (CONV_CONV_rule `((((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> ((mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)))` 
                                   (DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                    (MP  
                                     (DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                         (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                          (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                           (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                            (MP  
                                             (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)))` 
                                              (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                               (MP  
                                                (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                                                    (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                                          (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                           (conj))
                                                         ) (ASSUME `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)`
                                                        ))))
                                                  ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                  ))
                                                ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                )))
                                             ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                             ))))
                                       ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                       ))
                                     ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                                     )))
                                  ) (ASSUME `(((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                  ))))
                            ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                            ))
                          ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                          ))
                        ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                        )))
                   ) (MP  
                      (CONV_CONV_rule `((((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                       (DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                        (MP  
                         (DISCH `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))` 
                          (MP  
                           (MP  
                            (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                             (SPEC `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                              (SPEC `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                               (DISCH `(((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)` 
                                (MP  
                                 (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                  (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                   (MP  
                                    (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                        (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (MP  
                                             (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (conj))
                                             ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                             )
                                            ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                            ))))
                                      ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                      ))
                                    ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                    )))
                                 ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                 ))))
                           ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                           ))
                         ) (ASSUME `(mat_and ((((par (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((((par (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point))`
                         )))
                      ) (ASSUME `(((pG (E : mat_Point)) (F : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                      ))))))))))))))))))))
 ;;


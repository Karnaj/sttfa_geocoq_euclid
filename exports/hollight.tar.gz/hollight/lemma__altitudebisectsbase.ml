(*lemma__altitudebisectsbase :  |- `! A : mat_Point. (! B : mat_Point. (! M : mat_Point. (! P : mat_Point. ((((betS A) M) B) ==> (((((cong A) P) B) P) ==> ((((per A) M) P) ==> (((midpoint A) M) B)))))))`*)
let lemma__altitudebisectsbase =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(M : mat_Point)` 
   (GEN `(P : mat_Point)` 
    (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
     (DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
      (DISCH `((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
       (MP  
        (CONV_CONV_rule `(((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
         (DISCH `ex (\ C : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))))))` 
          (MP  
           (MP  
            (SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
             (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))))) ==> (return : bool))) ==> ((ex (\ C : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))))))) ==> (return : bool)))` 
              (SPEC `\ C : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point)))))` 
               (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
            ) (GEN `(C : mat_Point)` 
               (DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))))` 
                (MP  
                 (MP  
                  (SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                   (SPEC `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point)))` 
                    (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                     (and__ind)))
                  ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                     (DISCH `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point)))` 
                      (MP  
                       (MP  
                        (SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                         (SPEC `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))` 
                          (SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                           (and__ind)))
                        ) (DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                           (DISCH `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                               (SPEC `(neq (M : mat_Point)) (P : mat_Point)` 
                                (SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point)` 
                                 (DISCH `(neq (M : mat_Point)) (P : mat_Point)` 
                                  (MP  
                                   (DISCH `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                    (MP  
                                     (DISCH `(((cong (C : mat_Point)) (M : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                      (MP  
                                       (DISCH `(((cong (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                        (MP  
                                         (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (P : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))))))) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                          (DISCH `((per (C : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                           (MP  
                                            (DISCH `((per (P : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `(((per (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                               (DISCH `ex (\ Q : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point))))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point))))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point))))))) ==> (return : bool)))` 
                                                    (SPEC `\ Q : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point)))))` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (ex__ind))))
                                                  ) (GEN `(Q : mat_Point)` 
                                                     (DISCH `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point))))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                         (SPEC `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point)))` 
                                                          (SPEC `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                           (DISCH `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point)))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                               (SPEC `(mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point))` 
                                                                (SPEC `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                 (DISCH `(mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (X : mat_Point)) (M : mat_Point)) (C : mat_Point))))) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `((out (M : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((per (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ E : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ E : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (Q : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (A : mat_Point)) (P : mat_Point)) ==> mat_false) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (P : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (P : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (V : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (U : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (V : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))))))))))))))) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((((((congA (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point))) ==> (((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((midpoint (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (P : mat_Point)) (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((((((congA (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (P : mat_Point)) (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((((((congA (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (P : mat_Point)) (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (P : mat_Point)) (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (P : mat_Point)) (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((((((congA (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and ((((((congA (P : mat_Point)) (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((((((congA (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    proposition__04
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (V : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (x : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (V : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))))))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (V : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (U : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (V : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (V : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (U : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (V : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (x : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (x : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))))))))))) ==> (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (V : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (V : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (V : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (V : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (x : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))))))))) ==> (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))))))) ==> (ex (\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and (((out (P : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (P : mat_Point)) (B : mat_Point)) (B : mat_Point))) ((mat_and (((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (P : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (P : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((out (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))`
                                                                    )))))))))
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (Q : mat_Point)) (M : mat_Point))) (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (P : mat_Point)) (B : mat_Point))) ==> (((out (P : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (P : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (P : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((neq (A : mat_Point)) (P : mat_Point)) ==> mat_false) ==> mat_false` 
                                                                    (
                                                                    DISCH `mat_not ((neq (A : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (P : mat_Point))) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((neq (A : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (P : mat_Point))`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (P : mat_Point))) ==> (((neq (P : mat_Point)) (A : mat_Point)) ==> ((((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> (((neq (M : mat_Point)) (P : mat_Point)) ==> (((((cong (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((per (C : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> ((((per (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> ((((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((neq (P : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (P : mat_Point))) ==> (((neq (P : mat_Point)) (A : mat_Point)) ==> ((((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (P : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point)))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((neq (M : mat_Point)) (B : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (C : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((per (B : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((per (B : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((neq (B : mat_Point)) (A : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (B : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point))))))))))))))))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((neq (M : mat_Point)) (x : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((per (C : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> ((((per (x : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((betS (x : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((((cong (x : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((per (x : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (x : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((betS (x : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((neq (x : mat_Point)) (M : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (Q : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (M : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (A : mat_Point)) ==> ((((out (x : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (x : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point)))))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ P0 : mat_Point. (((((cong (A : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (P0 : mat_Point)) ==> (((((cong (A : mat_Point)) (P0 : mat_Point)) (C : mat_Point)) (P0 : mat_Point)) ==> (((neq (M : mat_Point)) (P0 : mat_Point)) ==> (((((cong (C : mat_Point)) (P0 : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> ((((per (C : mat_Point)) (M : mat_Point)) (P0 : mat_Point)) ==> ((((per (P0 : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((betS (P0 : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (P0 : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((((cong (P0 : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (P0 : mat_Point)) (M : mat_Point)) ==> ((((per (P0 : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (P0 : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((betS (P0 : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (P0 : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((cong (P0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (P0 : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (P0 : mat_Point)) (M : mat_Point)) ==> (((((cong (P0 : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (P0 : mat_Point)) (M : mat_Point)) ==> (((neq (P0 : mat_Point)) (M : mat_Point)) ==> (((((cong (P0 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (P0 : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (P0 : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> (((((cong (P0 : mat_Point)) (Q : mat_Point)) (P0 : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (M : mat_Point)) (P0 : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (P0 : mat_Point)) (M : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (P0 : mat_Point))) ==> (((neq (P0 : mat_Point)) (A : mat_Point)) ==> ((((out (P0 : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> (((((cong (A : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((neq (A : mat_Point)) (P0 : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point)))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (M : mat_Point)) (x : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ Q0 : mat_Point. (((((cong (B : mat_Point)) (A : mat_Point)) (Q0 : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) (M : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (Q0 : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (M : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (M : mat_Point)) (Q0 : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (Q0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q0 : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__nocollapse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (P : mat_Point))) ==> (((neq (P : mat_Point)) (A : mat_Point)) ==> ((((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (P : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (P : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point)) ==> (((neq (M : mat_Point)) (P : mat_Point)) ==> (((((cong (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> ((((per (C : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> ((((per (P : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> ((((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (P : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((neq (P : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)) ==> (((((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (M : mat_Point)) (P : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (P : mat_Point))) ==> (((neq (P : mat_Point)) (A : mat_Point)) ==> ((((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (B : mat_Point)))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> (((neq (M : mat_Point)) (B : mat_Point)) ==> (((((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> ((((per (C : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((per (B : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((per (B : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((neq (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((neq (B : mat_Point)) (A : mat_Point)) ==> ((((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point))))))))))))))))))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) (x : mat_Point)) ==> (((neq (M : mat_Point)) (x : mat_Point)) ==> (((((cong (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> ((((per (C : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> ((((per (x : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((betS (x : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((((cong (x : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((per (x : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (x : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((betS (x : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (x : mat_Point)) (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((neq (x : mat_Point)) (M : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (Q : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (x : mat_Point)) (M : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (x : mat_Point))) ==> (((neq (x : mat_Point)) (A : mat_Point)) ==> ((((out (x : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (B : mat_Point)))))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ P0 : mat_Point. (((((cong (A : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) (P0 : mat_Point)) ==> ((((per (A : mat_Point)) (M : mat_Point)) (P0 : mat_Point)) ==> (((((cong (A : mat_Point)) (P0 : mat_Point)) (C : mat_Point)) (P0 : mat_Point)) ==> (((neq (M : mat_Point)) (P0 : mat_Point)) ==> (((((cong (C : mat_Point)) (P0 : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> ((((per (C : mat_Point)) (M : mat_Point)) (P0 : mat_Point)) ==> ((((per (P0 : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((betS (P0 : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (P0 : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((((cong (P0 : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (P0 : mat_Point)) (M : mat_Point)) ==> ((((per (P0 : mat_Point)) (M : mat_Point)) (C : mat_Point)) ==> ((((per (P0 : mat_Point)) (M : mat_Point)) (B : mat_Point)) ==> ((((betS (P0 : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (P0 : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((cong (P0 : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (P0 : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (P0 : mat_Point)) (M : mat_Point)) ==> (((((cong (P0 : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (P0 : mat_Point)) (M : mat_Point)) ==> (((neq (P0 : mat_Point)) (M : mat_Point)) ==> (((((cong (P0 : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (P0 : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (P0 : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P0 : mat_Point)) ==> (((((cong (P0 : mat_Point)) (Q : mat_Point)) (P0 : mat_Point)) (Q : mat_Point)) ==> ((((nCol (A : mat_Point)) (M : mat_Point)) (P0 : mat_Point)) ==> ((mat_not (((col (A : mat_Point)) (P0 : mat_Point)) (M : mat_Point))) ==> ((mat_not ((eq (A : mat_Point)) (P0 : mat_Point))) ==> (((neq (P0 : mat_Point)) (A : mat_Point)) ==> ((((out (P0 : mat_Point)) (A : mat_Point)) (A : mat_Point)) ==> ((((cong (A : mat_Point)) (P0 : mat_Point)) (B : mat_Point)) (B : mat_Point)))))))))))))))))))))))))))))))))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (C : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((per (B : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> (((((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point))))))))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> (((((cong (B : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (M : mat_Point)) (x : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (x : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((((cong (B : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ Q0 : mat_Point. (((((cong (B : mat_Point)) (A : mat_Point)) (Q0 : mat_Point)) (A : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) (M : mat_Point)) ==> ((((betS (B : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (Q0 : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (M : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (M : mat_Point)) (Q0 : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (A : mat_Point)) (Q0 : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q0 : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) ==> (((((cong (A : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) ==> ((((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (B : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (E : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (M : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                                    )))))))))
                                                                    )))))))))
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(eq (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (P : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (P : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (P : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (P : mat_Point))) ==> ((neq (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `(eq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (P : mat_Point))) ((mat_or ((eq (A : mat_Point)) (M : mat_Point))) ((mat_or ((eq (P : mat_Point)) (M : mat_Point))) ((mat_or (((betS (P : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (M : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (P : mat_Point))))))) ==> mat_false` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (M : mat_Point))) ((mat_or ((eq (P : mat_Point)) (M : mat_Point))) ((mat_or (((betS (P : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_or (((betS (A : mat_Point)) (P : mat_Point)) (M : mat_Point))) (((betS (A : mat_Point)) (M : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (P : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (M : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((mat_and (((col (A : mat_Point)) (M : mat_Point)) (P : mat_Point))) (((col (M : mat_Point)) (P : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__rightangleNC
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (Q : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (Q : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (Q : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (Q : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) ((((cong (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (A : mat_Point)) (Q : mat_Point))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__doublereverse
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (Q : mat_Point)) (E : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)) ==> (((((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> ((((cong (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (A : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> (((((cong (x : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((cong (M : mat_Point)) (x : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (x : mat_Point)) ==> (((((cong (M : mat_Point)) (x : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> ((((cong (P : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ Q0 : mat_Point. ((((betS (P : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (A : mat_Point)) (Q0 : mat_Point)) (A : mat_Point)) ==> (((((cong (Q0 : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((cong (M : mat_Point)) (Q0 : mat_Point)) (P : mat_Point)) (M : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q0 : mat_Point)) ==> (((((cong (M : mat_Point)) (Q0 : mat_Point)) (M : mat_Point)) (E : mat_Point)) ==> ((((cong (P : mat_Point)) (B : mat_Point)) (Q0 : mat_Point)) (B : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (A : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point)`
                                                                    )))))))))
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(eq (Q : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__extensionunique
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (E : mat_Point))) ((mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (E : mat_Point))) ((mat_and ((neq (P : mat_Point)) (M : mat_Point))) ((neq (P : mat_Point)) (E : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (E : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (E : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (E : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (E : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((((cong (Q : mat_Point)) (M : mat_Point)) (M : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((((cong (Q : mat_Point)) (M : mat_Point)) (M : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((((cong (Q : mat_Point)) (M : mat_Point)) (M : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (Q : mat_Point)) (M : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (Q : mat_Point)) (M : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((((cong (Q : mat_Point)) (M : mat_Point)) (M : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((((cong (Q : mat_Point)) (M : mat_Point)) (M : mat_Point)) (P : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((((cong (A : mat_Point)) (P : mat_Point)) (P : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (E : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (B : mat_Point)) (E : mat_Point)) (B : mat_Point))) ((neq (M : mat_Point)) (B : mat_Point))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__8__3
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (M : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (x : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (x : mat_Point)) (M : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (X : mat_Point)) (M : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (X : mat_Point)) (M : mat_Point)) (B : mat_Point))) (((betS (X : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__8__2
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((per (C : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point)))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point))))`
                                                       ))))
                                                 ) (ASSUME `ex (\ Q : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (A : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((neq (M : mat_Point)) (A : mat_Point))))))`
                                                 )))
                                              ) (ASSUME `((per (P : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                              ))
                                            ) (MP  
                                               (SPEC `(P : mat_Point)` 
                                                (SPEC `(M : mat_Point)` 
                                                 (SPEC `(A : mat_Point)` 
                                                  (lemma__8__2)))
                                               ) (ASSUME `((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`
                                               ))))
                                         ) (MP  
                                            (SPEC `(A : mat_Point)` 
                                             (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (P : mat_Point)) (x : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (P : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))))))))` 
                                              (SPEC `\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (P : mat_Point)) (X : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point)))))` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (ex__intro))))
                                            ) (MP  
                                               (MP  
                                                (SPEC `(mat_and ((((cong (C : mat_Point)) (M : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point)))` 
                                                 (SPEC `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                  (conj))
                                                ) (ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                )
                                               ) (MP  
                                                  (MP  
                                                   (SPEC `(mat_and ((((cong (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))` 
                                                    (SPEC `(((cong (C : mat_Point)) (M : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                     (conj))
                                                   ) (ASSUME `(((cong (C : mat_Point)) (M : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                   )
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(neq (M : mat_Point)) (P : mat_Point)` 
                                                       (SPEC `(((cong (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)` 
                                                        (conj))
                                                      ) (ASSUME `(((cong (C : mat_Point)) (P : mat_Point)) (A : mat_Point)) (P : mat_Point)`
                                                      )
                                                     ) (ASSUME `(neq (M : mat_Point)) (P : mat_Point)`
                                                     ))))))
                                       ) (MP  
                                          (SPEC `(P : mat_Point)` 
                                           (SPEC `(P : mat_Point)` 
                                            (SPEC `(A : mat_Point)` 
                                             (SPEC `(C : mat_Point)` 
                                              (lemma__congruencesymmetric))))
                                          ) (ASSUME `(((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point)`
                                          )))
                                     ) (MP  
                                        (SPEC `(M : mat_Point)` 
                                         (SPEC `(M : mat_Point)` 
                                          (SPEC `(A : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (lemma__congruencesymmetric))))
                                        ) (ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                        )))
                                   ) (MP  
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(M : mat_Point)` 
                                        (SPEC `(A : mat_Point)` 
                                         (axiom__betweennesssymmetry)))
                                      ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                      )))))
                             ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))`
                             ))))
                       ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point)))`
                       ))))
                 ) (ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))))`
                 ))))
           ) (ASSUME `ex (\ C : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (P : mat_Point)) (C : mat_Point)) (P : mat_Point))) ((neq (M : mat_Point)) (P : mat_Point))))))`
           )))
        ) (ASSUME `((per (A : mat_Point)) (M : mat_Point)) (P : mat_Point)`))
      ))))))
 ;;


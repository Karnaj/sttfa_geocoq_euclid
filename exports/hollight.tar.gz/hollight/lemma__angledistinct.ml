(*lemma__angledistinct :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (((((((congA A) B) C) a) b) c) ==> ((mat_and ((neq A) B)) ((mat_and ((neq B) C)) ((mat_and ((neq A) C)) ((mat_and ((neq a) b)) ((mat_and ((neq b) c)) ((neq a) c))))))))))))`*)
let lemma__angledistinct =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(a : mat_Point)` 
    (GEN `(b : mat_Point)` 
     (GEN `(c : mat_Point)` 
      (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
       (MP  
        (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
         (MP  
          (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))))))` 
           (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
            (MP  
             (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))))))` 
              (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
               (MP  
                (CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))))))` 
                 (DISCH `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
                  (MP  
                   (DISCH `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                    (MP  
                     (DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                      (MP  
                       (CONV_CONV_rule `(((eq (a : mat_Point)) (b : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))))))` 
                        (DISCH `mat_not ((eq (a : mat_Point)) (b : mat_Point))` 
                         (MP  
                          (CONV_CONV_rule `(((eq (b : mat_Point)) (c : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))))))` 
                           (DISCH `mat_not ((eq (b : mat_Point)) (c : mat_Point))` 
                            (MP  
                             (CONV_CONV_rule `(((eq (a : mat_Point)) (c : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))))))` 
                              (DISCH `mat_not ((eq (a : mat_Point)) (c : mat_Point))` 
                               (MP  
                                (MP  
                                 (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))))) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))))))))` 
                                  (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))))` 
                                   (SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                    (conj)))
                                 ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                 )
                                ) (MP  
                                   (MP  
                                    (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))))) ==> ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))))))` 
                                     (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))))` 
                                      (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                       (conj)))
                                    ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                    )
                                   ) (MP  
                                      (MP  
                                       (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))) ==> ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))))))` 
                                        (SPEC `(mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))` 
                                         (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                          (conj)))
                                       ) (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                                       )
                                      ) (MP  
                                         (MP  
                                          (CONV_CONV_rule `(mat_not ((eq (a : mat_Point)) (b : mat_Point))) ==> (((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))) ==> ((mat_and ((neq (a : mat_Point)) (b : mat_Point))) ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))))` 
                                           (SPEC `(mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))` 
                                            (SPEC `(neq (a : mat_Point)) (b : mat_Point)` 
                                             (conj)))
                                          ) (ASSUME `mat_not ((eq (a : mat_Point)) (b : mat_Point))`
                                          )
                                         ) (MP  
                                            (CONV_CONV_rule `(mat_not ((eq (a : mat_Point)) (c : mat_Point))) ==> ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point)))` 
                                             (MP  
                                              (CONV_CONV_rule `(mat_not ((eq (b : mat_Point)) (c : mat_Point))) ==> (((neq (a : mat_Point)) (c : mat_Point)) ==> ((mat_and ((neq (b : mat_Point)) (c : mat_Point))) ((neq (a : mat_Point)) (c : mat_Point))))` 
                                               (SPEC `(neq (a : mat_Point)) (c : mat_Point)` 
                                                (SPEC `(neq (b : mat_Point)) (c : mat_Point)` 
                                                 (conj)))
                                              ) (ASSUME `mat_not ((eq (b : mat_Point)) (c : mat_Point))`
                                              ))
                                            ) (ASSUME `mat_not ((eq (a : mat_Point)) (c : mat_Point))`
                                            )))))))
                             ) (DISCH `(eq (a : mat_Point)) (c : mat_Point)` 
                                (MP  
                                 (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))))) ==> mat_false` 
                                  (DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                   (MP  
                                    (MP  
                                     (SPEC `(c : mat_Point)` 
                                      (SPEC `(b : mat_Point)` 
                                       (SPEC `(a : mat_Point)` 
                                        (col__nCol__False)))
                                     ) (ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                     )
                                    ) (ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                    )))
                                 ) (MP  
                                    (SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                                     (SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                      (or__intror))
                                    ) (MP  
                                       (SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                        (SPEC `(eq (a : mat_Point)) (c : mat_Point)` 
                                         (or__introl))
                                       ) (ASSUME `(eq (a : mat_Point)) (c : mat_Point)`
                                       )))))))
                          ) (DISCH `(eq (b : mat_Point)) (c : mat_Point)` 
                             (MP  
                              (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))))) ==> mat_false` 
                               (DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                (MP  
                                 (MP  
                                  (SPEC `(c : mat_Point)` 
                                   (SPEC `(b : mat_Point)` 
                                    (SPEC `(a : mat_Point)` 
                                     (col__nCol__False)))
                                  ) (ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                  )
                                 ) (ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                 )))
                              ) (MP  
                                 (SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                                  (SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                   (or__intror))
                                 ) (MP  
                                    (SPEC `(mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))` 
                                     (SPEC `(eq (a : mat_Point)) (c : mat_Point)` 
                                      (or__intror))
                                    ) (MP  
                                       (SPEC `(mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                        (SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                         (or__introl))
                                       ) (ASSUME `(eq (b : mat_Point)) (c : mat_Point)`
                                       ))))))))
                       ) (DISCH `(eq (a : mat_Point)) (b : mat_Point)` 
                          (MP  
                           (CONV_CONV_rule `((mat_or ((eq (a : mat_Point)) (b : mat_Point))) ((mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point))))))) ==> mat_false` 
                            (DISCH `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                             (MP  
                              (MP  
                               (SPEC `(c : mat_Point)` 
                                (SPEC `(b : mat_Point)` 
                                 (SPEC `(a : mat_Point)` (col__nCol__False)))
                               ) (ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                               )
                              ) (ASSUME `((col (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                              )))
                           ) (MP  
                              (SPEC `(mat_or ((eq (a : mat_Point)) (c : mat_Point))) ((mat_or ((eq (b : mat_Point)) (c : mat_Point))) ((mat_or (((betS (b : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((mat_or (((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point))) (((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)))))` 
                               (SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                (or__introl))
                              ) (ASSUME `(eq (a : mat_Point)) (b : mat_Point)`
                              )))))
                     ) (MP  
                        (CONV_CONV_rule `((((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                         (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))` 
                          (MP  
                           (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))` 
                            (MP  
                             (MP  
                              (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))) ==> (return : bool)))` 
                                (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))))))` 
                                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                              ) (GEN `(x : mat_Point)` 
                                 (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                     (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))) ==> (return : bool)))` 
                                      (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))))` 
                                       (PINST [(`:mat_Point`,`:A`)] [] 
                                        (ex__ind))))
                                    ) (GEN `(x0 : mat_Point)` 
                                       (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                           (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))) ==> (return : bool)))` 
                                            (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))))` 
                                             (PINST [(`:mat_Point`,`:A`)] [] 
                                              (ex__ind))))
                                          ) (GEN `(x1 : mat_Point)` 
                                             (DISCH `ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                 (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. (((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))) ==> (return : bool)))` 
                                                  (SPEC `\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))))` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (ex__ind))))
                                                ) (GEN `(x2 : mat_Point)` 
                                                   (DISCH `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                       (SPEC `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))` 
                                                        (SPEC `((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point)` 
                                                         (DISCH `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                             (SPEC `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                              (SPEC `((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point)` 
                                                               (DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                   (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point)` 
                                                                  (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (x6 : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (x6 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x5 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (x5 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (x5 : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x4 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x4 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (x4 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x3 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x3 : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x3 : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point)))))))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))`
                                                     ))))
                                               ) (ASSUME `ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))`
                                               ))))
                                         ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x0 : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))`
                                         ))))
                                   ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (x : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))`
                                   ))))
                             ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))`
                             ))
                           ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (U : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (V : mat_Point))) ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (u : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (U : mat_Point)) (B : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (b : mat_Point)) (V : mat_Point)) (B : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (a : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))))))))))`
                           )))
                        ) (ASSUME `(((((congA (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                        )))
                   ) (MP  
                      (SPEC `(c : mat_Point)` 
                       (SPEC `(b : mat_Point)` 
                        (SPEC `(a : mat_Point)` 
                         (SPEC `(C : mat_Point)` 
                          (SPEC `(B : mat_Point)` 
                           (SPEC `(A : mat_Point)` 
                            (lemma__equalanglessymmetric))))))
                      ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                      ))))
                ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                     (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (MP  
                       (MP  
                        (SPEC `(C : mat_Point)` 
                         (SPEC `(B : mat_Point)` 
                          (SPEC `(A : mat_Point)` (col__nCol__False)))
                        ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                        )
                       ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                       )))
                    ) (MP  
                       (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                        (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                         (or__intror))
                       ) (MP  
                          (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                           (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                            (or__introl))
                          ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`)))
                   ))))
             ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                  (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (MP  
                    (MP  
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(A : mat_Point)` (col__nCol__False)))
                     ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                     )
                    ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                    )))
                 ) (MP  
                    (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                     (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                      (or__intror))
                    ) (MP  
                       (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                        (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                         (or__intror))
                       ) (MP  
                          (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                           (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                            (or__introl))
                          ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`)))
                 )))))
          ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
             (MP  
              (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (col__nCol__False)))
                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )))
              ) (MP  
                 (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                  (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__introl))
                 ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)))))
        ) (MP  
           (CONV_CONV_rule `((((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
            (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
             (MP  
              (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))` 
               (MP  
                (MP  
                 (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))) ==> (return : bool)))` 
                   (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(x : mat_Point)` 
                    (DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))` 
                     (MP  
                      (MP  
                       (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))) ==> (return : bool)))` 
                         (SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))))` 
                          (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                       ) (GEN `(x0 : mat_Point)` 
                          (DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                           (MP  
                            (MP  
                             (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))) ==> (return : bool)))` 
                               (SPEC `\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                             ) (GEN `(x1 : mat_Point)` 
                                (DISCH `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. (((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))) ==> (return : bool)))` 
                                     (SPEC `\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))` 
                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                       (ex__ind))))
                                   ) (GEN `(x2 : mat_Point)` 
                                      (DISCH `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                       (MP  
                                        (MP  
                                         (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                           (SPEC `((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point)` 
                                            (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                 (SPEC `((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point)` 
                                                  (DISCH `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                       (SPEC `((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point)` 
                                                        (DISCH `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `(mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                             (SPEC `((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point)` 
                                                              (DISCH `(mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (SPEC `(mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                   (SPEC `(((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                   ))
                                                                 ) (DISCH `(((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                ))))
                                                          ) (ASSUME `(mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))`
                                                          ))))
                                                    ) (ASSUME `(mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))`
                                                    ))))
                                              ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))`
                                              ))))
                                        ) (ASSUME `(mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (x2 : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (x2 : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))`
                                        ))))
                                  ) (ASSUME `ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (x1 : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (x1 : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (x1 : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))`
                                  ))))
                            ) (ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (x0 : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x0 : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (x0 : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))`
                            ))))
                      ) (ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (x : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (x : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))`
                      ))))
                ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
                ))
              ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. ((mat_and (((out (B : mat_Point)) (A : mat_Point)) (U : mat_Point))) ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (V : mat_Point))) ((mat_and (((out (b : mat_Point)) (a : mat_Point)) (u : mat_Point))) ((mat_and (((out (b : mat_Point)) (c : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (U : mat_Point)) (b : mat_Point)) (u : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (V : mat_Point)) (b : mat_Point)) (v : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (V : mat_Point)) (u : mat_Point)) (v : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))))))`
              )))
           ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
           )))))))))
 ;;


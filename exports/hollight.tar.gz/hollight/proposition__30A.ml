(*proposition__30A :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (! G : mat_Point. (! H : mat_Point. (! K : mat_Point. (((((par A) B) E) F) ==> (((((par C) D) E) F) ==> ((((betS G) H) K) ==> ((((betS A) G) B) ==> ((((betS E) H) F) ==> ((((betS C) K) D) ==> (((((tS A) G) H) F) ==> (((((tS F) H) K) C) ==> ((((par A) B) C) D)))))))))))))))))`*)
let proposition__30A =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (GEN `(G : mat_Point)` 
       (GEN `(H : mat_Point)` 
        (GEN `(K : mat_Point)` 
         (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
          (DISCH `(((par (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
           (DISCH `((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
            (DISCH `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
             (DISCH `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
              (DISCH `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
               (DISCH `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                (DISCH `(((tS (F : mat_Point)) (H : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                 (MP  
                  (DISCH `(((par (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                   (MP  
                    (DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                     (MP  
                      (DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                       (MP  
                        (DISCH `ex (\ P : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point))))` 
                         (MP  
                          (MP  
                           (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (G : mat_Point)) (H : mat_Point))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point))))) ==> (return : bool)))` 
                             (SPEC `\ P : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point)))` 
                              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                           ) (GEN `(P : mat_Point)` 
                              (DISCH `(mat_and (((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (SPEC `(((cong (G : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                   (SPEC `((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point)` 
                                    (DISCH `(((cong (G : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                     (MP  
                                      (DISCH `((betS (P : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                       (MP  
                                        (DISCH `((betS (P : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                         (MP  
                                          (CONV_CONV_rule `((((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                           (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))))) ==> (return : bool)))` 
                                                (SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))))` 
                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                  (ex__ind))))
                                              ) (GEN `(M : mat_Point)` 
                                                 (DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (SPEC `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                      (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                       (DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                            (SPEC `((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                             (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                              (MP  
                                                               (CONV_CONV_rule `((((tS (F : mat_Point)) (H : mat_Point)) (K : mat_Point)) (C : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                (DISCH `ex (\ N : mat_Point. ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)))))` 
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (F : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (x : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)))) ==> (return : bool))) ==> ((ex (\ N : mat_Point. ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ N : mat_Point. ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                   ) (
                                                                   GEN `(N : mat_Point)` 
                                                                   (DISCH `(mat_and (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (A : mat_Point)) (A : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (G : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (G : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (H : mat_Point)) (H : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (H : mat_Point))) ((mat_or ((eq (E : mat_Point)) (F : mat_Point))) ((mat_or ((eq (H : mat_Point)) (F : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (F : mat_Point)) (H : mat_Point))) ((mat_or ((eq (F : mat_Point)) (H : mat_Point))) ((mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_or (((betS (F : mat_Point)) (H : mat_Point)) (H : mat_Point))) (((betS (F : mat_Point)) (H : mat_Point)) (H : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (E : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (E : mat_Point)) (H : mat_Point))) ((mat_or ((eq (E : mat_Point)) (H : mat_Point))) ((mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (H : mat_Point))) (((betS (E : mat_Point)) (H : mat_Point)) (H : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or ((eq (K : mat_Point)) (H : mat_Point))) ((mat_or (((betS (K : mat_Point)) (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((betS (H : mat_Point)) (H : mat_Point)) (K : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (K : mat_Point))) ((mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (K : mat_Point)) (D : mat_Point))) ((mat_or (((betS (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (K : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (E : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (K : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (F : mat_Point)) (N : mat_Point))) ((mat_or ((eq (F : mat_Point)) (C : mat_Point))) ((mat_or ((eq (N : mat_Point)) (C : mat_Point))) ((mat_or (((betS (N : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) (((betS (F : mat_Point)) (C : mat_Point)) (N : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (N : mat_Point)) (N : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (N : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (F : mat_Point)) (N : mat_Point))) ((mat_or ((eq (F : mat_Point)) (N : mat_Point))) ((mat_or ((eq (N : mat_Point)) (N : mat_Point))) ((mat_or (((betS (N : mat_Point)) (F : mat_Point)) (N : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (N : mat_Point))) (((betS (F : mat_Point)) (N : mat_Point)) (N : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (N : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (H : mat_Point)) (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (H : mat_Point)) (N : mat_Point))) ((mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or ((eq (N : mat_Point)) (K : mat_Point))) ((mat_or (((betS (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (N : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (H : mat_Point)) (N : mat_Point))) ((mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or ((eq (N : mat_Point)) (H : mat_Point))) ((mat_or (((betS (N : mat_Point)) (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (N : mat_Point)) (H : mat_Point))) (((betS (H : mat_Point)) (H : mat_Point)) (N : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (E : mat_Point)) (C : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (K : mat_Point)) (K : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (K : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (X : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tS (C : mat_Point)) (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (E : mat_Point)) (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (K : mat_Point))) ((mat_or ((eq (C : mat_Point)) (K : mat_Point))) ((mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_or (((betS (C : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (C : mat_Point)) (K : mat_Point)) (K : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (D : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (K : mat_Point)) (D : mat_Point)) (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (D : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (K : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((betS (K : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (K : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (H : mat_Point)) (K : mat_Point)) (D : mat_Point)) (G : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (H : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((betS (G : mat_Point)) (K : mat_Point)) (H : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (K : mat_Point)) (N : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((oS (A : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (G : mat_Point)) (K : mat_Point)) (K : mat_Point))))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)))))) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(((tS (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((tS (A : mat_Point)) (G : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__27
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (G : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (A : mat_Point)) (C : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (C : mat_Point)) (G : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (x : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (X : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (K : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (G : mat_Point)) (K : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (G : mat_Point)) (K : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (K : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (G : mat_Point)) (K : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (K : mat_Point)) (K : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (x : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (U : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (x : mat_Point))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point))) ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) (((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (P : mat_Point)) (G : mat_Point))) ((neq (P : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (G : mat_Point))) ((neq (P : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (G : mat_Point))) ((neq (P : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (G : mat_Point))) ((neq (P : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (K : mat_Point))) ((mat_and ((neq (P : mat_Point)) (G : mat_Point))) ((neq (P : mat_Point)) (K : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (N : mat_Point)) (G : mat_Point))) ((mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (N : mat_Point)) (G : mat_Point))) ((mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (N : mat_Point)) (G : mat_Point))) ((mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (N : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (N : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (N : mat_Point)) (G : mat_Point))) ((mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (N : mat_Point)) (G : mat_Point))) ((mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (K : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (K : mat_Point)) (G : mat_Point))) (((nCol (K : mat_Point)) (G : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesNC
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (N : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((col (N : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (N : mat_Point))) (((col (G : mat_Point)) (N : mat_Point)) (K : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (K : mat_Point)) (N : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (K : mat_Point)) (N : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (((col (K : mat_Point)) (N : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (N : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (K : mat_Point)) (N : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (K : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))) (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((col (M : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (M : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (M : mat_Point))) (((col (G : mat_Point)) (M : mat_Point)) (K : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (K : mat_Point)) (M : mat_Point)) (G : mat_Point)) ==> mat_false) ==> (((col (K : mat_Point)) (M : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (M : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (K : mat_Point)) (M : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (K : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (G : mat_Point))) ((mat_and (((col (K : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((col (G : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((col (K : mat_Point)) (H : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((col (M : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((col (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((col (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((col (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (H : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((col (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((col (M : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((col (K : mat_Point)) (H : mat_Point)) (M : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (M : mat_Point))) (((col (K : mat_Point)) (M : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)) ==> mat_false) ==> (((col (H : mat_Point)) (M : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (M : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (G : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (H : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (K : mat_Point))) ((mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((betS (G : mat_Point)) (K : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((betS (G : mat_Point)) (K : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H : mat_Point)) (G : mat_Point)) (K : mat_Point))) ((mat_or (((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((betS (G : mat_Point)) (K : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((betS (G : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (G : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (K : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) (G : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) (H : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (K : mat_Point)) (D : mat_Point)) (G : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (H : mat_Point)) (K : mat_Point)) (D : mat_Point)) (H : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (K : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (K : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (G : mat_Point)) (H : mat_Point))) (((betS (K : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (K : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (K : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (K : mat_Point)) (H : mat_Point))) ((neq (K : mat_Point)) (G : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (H : mat_Point)) (G : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (K : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (K : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (D : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (D : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (D : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (D : mat_Point)) (H : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (D : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (D : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (K : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (K : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (K : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (K : mat_Point))) ((mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_or (((betS (C : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (C : mat_Point)) (K : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_or (((betS (C : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (C : mat_Point)) (K : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (K : mat_Point)) (C : mat_Point)) (K : mat_Point))) ((mat_or (((betS (C : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (C : mat_Point)) (K : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (K : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(eq (K : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (K : mat_Point))) (((nCol (C : mat_Point)) (K : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H89 : mat_Point. (((((par (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> ((((betS (A0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) ==> ((((betS (C0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) ==> (((((tS (A0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point)) ==> ((mat_and ((((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point))) ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H90 : mat_Point. (((((par (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> ((((betS (A0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) ==> ((((betS (C0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) ==> (((((tS (A0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)) ==> ((((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. (! D0 : mat_Point. (! E0 : mat_Point. (! G0 : mat_Point. (! H90 : mat_Point. (((((par (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)) ==> ((((betS (A0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) ==> ((((betS (C0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)) ==> ((((betS (E0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) ==> (((((tS (A0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)) ==> ((((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)))))))))))))`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (E : mat_Point)) (H : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E0 : mat_Point)` 
                                                                    (
                                                                    GEN `(G0 : mat_Point)` 
                                                                    (
                                                                    GEN `(H90 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (A0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H90 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    ASSUME `! A00 : mat_Point. (! B00 : mat_Point. (! C00 : mat_Point. (! D00 : mat_Point. (! E00 : mat_Point. (! G00 : mat_Point. (! H89 : mat_Point. (((((par (A00 : mat_Point)) (B00 : mat_Point)) (C00 : mat_Point)) (D00 : mat_Point)) ==> ((((betS (A00 : mat_Point)) (G00 : mat_Point)) (B00 : mat_Point)) ==> ((((betS (C00 : mat_Point)) (H89 : mat_Point)) (D00 : mat_Point)) ==> ((((betS (E00 : mat_Point)) (G00 : mat_Point)) (H89 : mat_Point)) ==> (((((tS (A00 : mat_Point)) (G00 : mat_Point)) (H89 : mat_Point)) (D00 : mat_Point)) ==> ((mat_and ((((((congA (E00 : mat_Point)) (G00 : mat_Point)) (B00 : mat_Point)) (G00 : mat_Point)) (H89 : mat_Point)) (D00 : mat_Point))) ((((((rT (B00 : mat_Point)) (G00 : mat_Point)) (H89 : mat_Point)) (G00 : mat_Point)) (H89 : mat_Point)) (D00 : mat_Point))))))))))))))`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(((par (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A0 : mat_Point)) (G0 : mat_Point)) (H90 : mat_Point)) (D0 : mat_Point)`
                                                                    )))))))))
                                                                    )))))))
                                                                    ) (
                                                                    GEN `(A0 : mat_Point)` 
                                                                    (
                                                                    GEN `(B0 : mat_Point)` 
                                                                    (
                                                                    GEN `(C0 : mat_Point)` 
                                                                    (
                                                                    GEN `(D0 : mat_Point)` 
                                                                    (
                                                                    GEN `(E0 : mat_Point)` 
                                                                    (
                                                                    GEN `(G0 : mat_Point)` 
                                                                    (
                                                                    GEN `(H89 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (C0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (A0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point))) ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point))) ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (A0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point))) ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point))` 
                                                                    (
                                                                    ASSUME `(mat_and ((((((congA (E0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point))) ((((((rT (B0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H89 : mat_Point)` 
                                                                    (
                                                                    SPEC `(G0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(E0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(D0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(C0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(B0 : mat_Point)` 
                                                                    (
                                                                    SPEC `(A0 : mat_Point)` 
                                                                    (
                                                                    proposition__29
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(((par (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A0 : mat_Point)) (G0 : mat_Point)) (B0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A0 : mat_Point)) (G0 : mat_Point)) (H89 : mat_Point)) (D0 : mat_Point)`
                                                                    )))))))))
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__planeseparation
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((oS (E : mat_Point)) (C : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (C : mat_Point)) (H : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (x : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (X : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (C : mat_Point)) (X : mat_Point)) (D : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (X : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (K : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (K : mat_Point))) ((mat_or (((betS (K : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (K : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (K : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (K : mat_Point)) (K : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))))) ==> (ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (x : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (U : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (U : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (H : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (x : mat_Point))) ((mat_and (((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))))))) ==> (ex (\ V : mat_Point. ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (H : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (V : mat_Point))) ((mat_and (((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (V : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point))) ((mat_and (((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (E : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (E : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (E : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (E : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (N : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (N : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (N : mat_Point))) ((neq (H : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (N : mat_Point))) ((neq (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (N : mat_Point))) ((neq (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (N : mat_Point))) ((neq (H : mat_Point)) (K : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (N : mat_Point)) (K : mat_Point))) ((mat_and ((neq (H : mat_Point)) (N : mat_Point))) ((neq (H : mat_Point)) (K : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (N : mat_Point)) (K : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or ((eq (N : mat_Point)) (H : mat_Point))) ((mat_or (((betS (N : mat_Point)) (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (N : mat_Point)) (H : mat_Point))) (((betS (H : mat_Point)) (H : mat_Point)) (N : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (N : mat_Point)) (H : mat_Point))) ((mat_or (((betS (N : mat_Point)) (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (N : mat_Point)) (H : mat_Point))) (((betS (H : mat_Point)) (H : mat_Point)) (N : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (H : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (K : mat_Point))) ((mat_or ((eq (N : mat_Point)) (K : mat_Point))) ((mat_or (((betS (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (N : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (N : mat_Point)) (K : mat_Point))) ((mat_or (((betS (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (N : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_or (((betS (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (N : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((betS (H : mat_Point)) (K : mat_Point)) (N : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (N : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (H : mat_Point)) (N : mat_Point)) (K : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (N : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (N : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (N : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (N : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (N : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (N : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (N : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (N : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (N : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (C : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (C : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (N : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (N : mat_Point)) (C : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (N : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (C : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (H : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (N : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (N : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (N : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (N : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (N : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (N : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (N : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (N : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (N : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (N : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (N : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (N : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (N : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (N : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (N : mat_Point))) ((mat_or ((eq (N : mat_Point)) (N : mat_Point))) ((mat_or (((betS (N : mat_Point)) (F : mat_Point)) (N : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (N : mat_Point))) (((betS (F : mat_Point)) (N : mat_Point)) (N : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (N : mat_Point)) (N : mat_Point))) ((mat_or (((betS (N : mat_Point)) (F : mat_Point)) (N : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (N : mat_Point))) (((betS (F : mat_Point)) (N : mat_Point)) (N : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (N : mat_Point)) (F : mat_Point)) (N : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (N : mat_Point))) (((betS (F : mat_Point)) (N : mat_Point)) (N : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (N : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (N : mat_Point)) (N : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (C : mat_Point))) ((mat_or ((eq (N : mat_Point)) (C : mat_Point))) ((mat_or (((betS (N : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) (((betS (F : mat_Point)) (C : mat_Point)) (N : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (N : mat_Point)) (C : mat_Point))) ((mat_or (((betS (N : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) (((betS (F : mat_Point)) (C : mat_Point)) (N : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (N : mat_Point)) (F : mat_Point)) (C : mat_Point))) ((mat_or (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) (((betS (F : mat_Point)) (C : mat_Point)) (N : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) (((betS (F : mat_Point)) (C : mat_Point)) (N : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (N : mat_Point)) (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (C : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (N : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (N : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (N : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (N : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (N : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (N : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (N : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (N : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (N : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (N : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (N : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (N : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (N : mat_Point))) (((nCol (F : mat_Point)) (N : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (N : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (N : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (N : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (N : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (N : mat_Point))) ((neq (K : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (K : mat_Point)) (N : mat_Point))) ((neq (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (N : mat_Point))) ((neq (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (N : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (N : mat_Point))) ((neq (K : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (N : mat_Point)) (H : mat_Point))) ((mat_and ((neq (K : mat_Point)) (N : mat_Point))) ((neq (K : mat_Point)) (H : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (K : mat_Point)) (N : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearbetween
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (N : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (N : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (N : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (N : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (N : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (N : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (N : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (N : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (N : mat_Point))) ((neq (C : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (N : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (K : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (K : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (K : mat_Point))) ((neq (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (D : mat_Point))) ((mat_or ((eq (K : mat_Point)) (D : mat_Point))) ((mat_or (((betS (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (D : mat_Point))) ((mat_or (((betS (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (K : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_or (((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (K : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (K : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (K : mat_Point)) (D : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (N : mat_Point)) (H : mat_Point))) ((mat_and (((col (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (K : mat_Point)) (N : mat_Point)) (H : mat_Point))) ((mat_and (((col (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (K : mat_Point)) (N : mat_Point)) (H : mat_Point))) ((mat_and (((col (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (K : mat_Point)) (N : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (N : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (N : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (N : mat_Point)) (H : mat_Point))) ((mat_and (((col (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (K : mat_Point)) (H : mat_Point)) (N : mat_Point))) ((mat_and (((col (K : mat_Point)) (N : mat_Point)) (H : mat_Point))) ((mat_and (((col (N : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((col (H : mat_Point)) (N : mat_Point)) (K : mat_Point))) (((col (N : mat_Point)) (K : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or ((eq (K : mat_Point)) (H : mat_Point))) ((mat_or (((betS (K : mat_Point)) (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((betS (H : mat_Point)) (H : mat_Point)) (K : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (H : mat_Point))) ((mat_or (((betS (K : mat_Point)) (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((betS (H : mat_Point)) (H : mat_Point)) (K : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (H : mat_Point)) (H : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(eq (H : mat_Point)) (H : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))) (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (H : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (H : mat_Point))) ((mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (H : mat_Point))) (((betS (E : mat_Point)) (H : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (H : mat_Point))) (((betS (E : mat_Point)) (H : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (H : mat_Point))) (((betS (E : mat_Point)) (H : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (H : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (F : mat_Point)) (H : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (E : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (E : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (F : mat_Point))) ((mat_and ((neq (E : mat_Point)) (H : mat_Point))) ((neq (E : mat_Point)) (F : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (F : mat_Point)) (H : mat_Point))) ((mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_or (((betS (F : mat_Point)) (H : mat_Point)) (H : mat_Point))) (((betS (F : mat_Point)) (H : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (H : mat_Point))) ((mat_or (((betS (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_or (((betS (F : mat_Point)) (H : mat_Point)) (H : mat_Point))) (((betS (F : mat_Point)) (H : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_or (((betS (F : mat_Point)) (H : mat_Point)) (H : mat_Point))) (((betS (F : mat_Point)) (H : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (H : mat_Point)) (H : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (H : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (H : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (H : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (F : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (F : mat_Point)) (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (H : mat_Point)) (F : mat_Point)) (E : mat_Point))) ((mat_and (((col (F : mat_Point)) (E : mat_Point)) (H : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (H : mat_Point))) (((col (F : mat_Point)) (H : mat_Point)) (E : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (E : mat_Point)) (F : mat_Point))) ((mat_or ((eq (H : mat_Point)) (F : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (H : mat_Point)) (F : mat_Point))) ((mat_or (((betS (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (H : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_or (((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point))) (((betS (E : mat_Point)) (F : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (K : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((mat_and (((nCol (K : mat_Point)) (F : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (F : mat_Point)) (H : mat_Point)) (K : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (F : mat_Point)) (K : mat_Point))) (((nCol (F : mat_Point)) (K : mat_Point)) (H : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    axiom__betweennesssymmetry
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (K : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (G : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(K : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (K : mat_Point)) (H : mat_Point))) (((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (K : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (G : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (G : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `((((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) ==> ((((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) ==> ((((betS (P : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) ==> ((((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    ASSUME `((((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> ((((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)) ==> ((((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)) ==> ((((betS (P : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)) ==> ((((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point))))))`
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (P : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (P : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point))) ((((((rT (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    ASSUME `(((((congA (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__29
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (E : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                                                    )))))))))
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (H : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (H : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (H : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (H : mat_Point)) (A : mat_Point)) (G : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (G : mat_Point)) (H : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (A : mat_Point)) (H : mat_Point))) (((nCol (A : mat_Point)) (H : mat_Point)) (G : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NCorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (N : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (N : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (F : mat_Point)) (N : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (N : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (F : mat_Point)) (N : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (F : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (F : mat_Point)) (N : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (F : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (G : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (F : mat_Point)) (N : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (N : mat_Point)) (C : mat_Point))) ((mat_and ((neq (F : mat_Point)) (N : mat_Point))) ((neq (F : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(N : mat_Point)` 
                                                                    (
                                                                    SPEC `(F : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (G : mat_Point))) ((neq (A : mat_Point)) (B : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x2 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x3 : mat_Point. (((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x3 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x1 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x4 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x5 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x6 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x7 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x8 : mat_Point. (((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x8 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x4 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x6 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x9 : mat_Point. ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x10 : mat_Point. ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point))))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x11 : mat_Point. ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool))) ==> ((ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x12 : mat_Point. ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool))) ==> ((ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x13 : mat_Point. (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(x13 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (E : mat_Point)) (F : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    SPEC `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x9 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (x11 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    SPEC `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point)` 
                                                                    (
                                                                    DISCH `((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)` 
                                                                    (
                                                                    ASSUME `mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (x13 : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (x13 : mat_Point)) (x10 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x12 : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (x12 : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (x12 : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x11 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x11 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x11 : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x10 : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (x10 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x10 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x9 : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x9 : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x9 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (U : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (x8 : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (x8 : mat_Point)) (x5 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x7 : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (x7 : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (x7 : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x6 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x6 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x6 : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x5 : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (x5 : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x5 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x4 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x4 : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (x4 : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (U : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (u : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (x3 : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (x3 : mat_Point)) (x0 : mat_Point)))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x2 : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (x2 : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (x2 : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (x1 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (x1 : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (x1 : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x0 : mat_Point))) ((mat_and ((neq (x : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (x0 : mat_Point)))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (x : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (x : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (x : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ u : mat_Point. (ex (\ v : mat_Point. (ex (\ X : mat_Point. ((mat_and ((neq (E : mat_Point)) (F : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (U : mat_Point))) ((mat_and (((col (E : mat_Point)) (F : mat_Point)) (V : mat_Point))) ((mat_and ((neq (U : mat_Point)) (V : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (u : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (v : mat_Point))) ((mat_and ((neq (u : mat_Point)) (v : mat_Point))) ((mat_and (mat_not ((((meet (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ((mat_and (((betS (U : mat_Point)) (X : mat_Point)) (v : mat_Point))) (((betS (u : mat_Point)) (X : mat_Point)) (V : mat_Point)))))))))))))))))))))`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(((par (E : mat_Point)) (F : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)))`
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `ex (\ N : mat_Point. ((mat_and (((betS (F : mat_Point)) (N : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (K : mat_Point)) (N : mat_Point))) (((nCol (H : mat_Point)) (K : mat_Point)) (F : mat_Point)))))`
                                                                  )))
                                                               ) (ASSUME `(((tS (F : mat_Point)) (H : mat_Point)) (K : mat_Point)) (C : mat_Point)`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))`
                                                   ))))
                                             ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (F : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (M : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (A : mat_Point)))))`
                                             )))
                                          ) (ASSUME `(((tS (A : mat_Point)) (G : mat_Point)) (H : mat_Point)) (F : mat_Point)`
                                          ))
                                        ) (MP  
                                           (MP  
                                            (SPEC `(K : mat_Point)` 
                                             (SPEC `(H : mat_Point)` 
                                              (SPEC `(G : mat_Point)` 
                                               (SPEC `(P : mat_Point)` 
                                                (lemma__3__7b))))
                                            ) (ASSUME `((betS (P : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                            )
                                           ) (ASSUME `((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                                           )))
                                      ) (MP  
                                         (SPEC `(P : mat_Point)` 
                                          (SPEC `(G : mat_Point)` 
                                           (SPEC `(H : mat_Point)` 
                                            (axiom__betweennesssymmetry)))
                                         ) (ASSUME `((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point)`
                                         )))))
                                ) (ASSUME `(mat_and (((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point))`
                                ))))
                          ) (ASSUME `ex (\ P : mat_Point. ((mat_and (((betS (H : mat_Point)) (G : mat_Point)) (P : mat_Point))) ((((cong (G : mat_Point)) (P : mat_Point)) (G : mat_Point)) (H : mat_Point))))`
                          ))
                        ) (MP  
                           (MP  
                            (SPEC `(H : mat_Point)` 
                             (SPEC `(G : mat_Point)` 
                              (SPEC `(G : mat_Point)` 
                               (SPEC `(H : mat_Point)` (lemma__extension))))
                            ) (ASSUME `(neq (H : mat_Point)) (G : mat_Point)`
                            )
                           ) (ASSUME `(neq (G : mat_Point)) (H : mat_Point)`)
                        ))
                      ) (MP  
                         (SPEC `(H : mat_Point)` 
                          (SPEC `(G : mat_Point)` 
                           (lemma__inequalitysymmetric))
                         ) (ASSUME `(neq (G : mat_Point)) (H : mat_Point)`)))
                    ) (MP  
                       (DISCH `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (K : mat_Point)))` 
                        (MP  
                         (MP  
                          (SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                           (SPEC `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (K : mat_Point))` 
                            (SPEC `(neq (H : mat_Point)) (K : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(neq (H : mat_Point)) (K : mat_Point)` 
                             (DISCH `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (K : mat_Point))` 
                              (MP  
                               (MP  
                                (SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                 (SPEC `(neq (G : mat_Point)) (K : mat_Point)` 
                                  (SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                   (and__ind)))
                                ) (DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                   (DISCH `(neq (G : mat_Point)) (K : mat_Point)` 
                                    (ASSUME `(neq (G : mat_Point)) (H : mat_Point)`
                                    )))
                               ) (ASSUME `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (K : mat_Point))`
                               ))))
                         ) (ASSUME `(mat_and ((neq (H : mat_Point)) (K : mat_Point))) ((mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((neq (G : mat_Point)) (K : mat_Point)))`
                         ))
                       ) (MP  
                          (SPEC `(K : mat_Point)` 
                           (SPEC `(H : mat_Point)` 
                            (SPEC `(G : mat_Point)` (lemma__betweennotequal))
                           )
                          ) (ASSUME `((betS (G : mat_Point)) (H : mat_Point)) (K : mat_Point)`
                          ))))
                  ) (MP  
                     (SPEC `(F : mat_Point)` 
                      (SPEC `(E : mat_Point)` 
                       (SPEC `(D : mat_Point)` 
                        (SPEC `(C : mat_Point)` (lemma__parallelsymmetric))))
                     ) (ASSUME `(((par (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                     )))))))))))))))))))
 ;;


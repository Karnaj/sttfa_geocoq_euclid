(*proposition__12 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((nCol A) B) C) ==> (ex (\ X : mat_Point. (((((perp__at C) X) A) B) X))))))`*)
let proposition__12 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
      (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
       (MP  
        (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
         (MP  
          (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
           (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
            (MP  
             (DISCH `ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
              (MP  
               (MP  
                (SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                 (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((((cong (B : mat_Point)) (x : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                  (SPEC `\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                ) (GEN `(E : mat_Point)` 
                   (DISCH `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                    (MP  
                     (MP  
                      (SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                       (SPEC `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                        (SPEC `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                         (DISCH `(((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                          (MP  
                           (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                            (MP  
                             (DISCH `(neq (E : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (DISCH `ex (\ F : mat_Point. ((mat_and (((betS (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))` 
                                (MP  
                                 (MP  
                                  (SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (x : mat_Point)) (E : mat_Point)) (C : mat_Point))) ==> (return : bool))) ==> ((ex (\ F : mat_Point. ((mat_and (((betS (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))) ==> (return : bool)))` 
                                    (SPEC `\ F : mat_Point. ((mat_and (((betS (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)))` 
                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                      (ex__ind))))
                                  ) (GEN `(F : mat_Point)` 
                                     (DISCH `(mat_and (((betS (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                         (SPEC `(((cong (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                          (SPEC `((betS (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `((betS (E : mat_Point)) (C : mat_Point)) (F : mat_Point)` 
                                           (DISCH `(((cong (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                                            (MP  
                                             (DISCH `(((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                              (MP  
                                               (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                (MP  
                                                 (DISCH `(((cong (C : mat_Point)) (F : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                  (MP  
                                                   (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (MP  
                                                     (DISCH `((betS (E : mat_Point)) (B : mat_Point)) (F : mat_Point)` 
                                                      (MP  
                                                       (DISCH `ex (\ K : mat_Circle. ((((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                                           (CONV_CONV_rule `! return : bool. ((! x : mat_Circle. (((((cI (x : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)) ==> (return : bool))) ==> ((ex (\ K : mat_Circle. ((((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)))) ==> (return : bool)))` 
                                                            (SPEC `\ K : mat_Circle. ((((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point))` 
                                                             (PINST [(`:mat_Circle`,`:A`)] [] 
                                                              (ex__ind))))
                                                          ) (GEN `(K : mat_Circle)` 
                                                             (DISCH `(((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                  (MP  
                                                                   (CONV_CONV_rule `(ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    DISCH `(inCirc (B : mat_Point)) (K : mat_Circle)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ P : mat_Point. (ex (\ Q : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ Q : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (x : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (x : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))) ==> (return : bool))) ==> ((ex (\ P : mat_Point. (ex (\ Q : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ P : mat_Point. (ex (\ Q : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(P : mat_Point)` 
                                                                    (
                                                                    DISCH `ex (\ Q : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (x : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (x : mat_Point)))))) ==> (return : bool))) ==> ((ex (\ Q : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ Q : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    SPEC `(mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(onCirc (P : mat_Point)) (K : mat_Circle)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(onCirc (P : mat_Point)) (K : mat_Circle)` 
                                                                    (
                                                                    DISCH `(mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(onCirc (Q : mat_Point)) (K : mat_Circle)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(onCirc (Q : mat_Point)) (K : mat_Circle)` 
                                                                    (
                                                                    DISCH `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (P : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ((((cong (x : mat_Point)) (P : mat_Point)) (x : mat_Point)) (Q : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))))) ==> (return : bool)))` 
                                                                    (
                                                                    SPEC `\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__ind))
                                                                    ))
                                                                    ) (
                                                                    GEN `(M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (M : mat_Point))) ((mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (M : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))))))) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (P : mat_Point)) (B : mat_Point))) ((mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))))))) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((eq (M : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    DISCH `mat_not ((eq (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    DISCH `((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (M : mat_Point)) (M : mat_Point)) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    DISCH `(eq (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or ((eq (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (M : mat_Point)) (M : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (M : mat_Point))))))) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((per (X : mat_Point)) (M : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))))` 
                                                                    (
                                                                    DISCH `((((perp__at (C : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((((((perp__at (C : mat_Point)) (x : mat_Point)) (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (ex (\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point)))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (((((perp__at (C : mat_Point)) (X : mat_Point)) (A : mat_Point)) (B : mat_Point)) (X : mat_Point))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((((perp__at (C : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((col (C : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point))) (((per (x : mat_Point)) (M : mat_Point)) (C : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((per (X : mat_Point)) (M : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((col (C : mat_Point)) (M : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) (((per (X : mat_Point)) (M : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (M : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (M : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) (((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((per (P : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (M : mat_Point))) ((mat_or ((eq (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (M : mat_Point)) (M : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (M : mat_Point))) ((mat_or (((betS (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (M : mat_Point)) (M : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_or (((betS (C : mat_Point)) (M : mat_Point)) (M : mat_Point))) (((betS (C : mat_Point)) (M : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (M : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (x : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (X : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (X : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (M : mat_Point)) (C : mat_Point))) ==> ((mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((neq (M : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (M : mat_Point)) (C : mat_Point))`
                                                                    )))))))
                                                                    ) (
                                                                    DISCH `(eq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((eq (M : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> ((((col (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) ==> ((((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)) ==> ((((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> ((((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((betS (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> (((((cong (C : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> ((((col (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) ==> ((((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)) ==> ((((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((betS (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> (((((cong (x : mat_Point)) (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> ((((col (P : mat_Point)) (x : mat_Point)) (Q : mat_Point)) ==> ((((col (P : mat_Point)) (Q : mat_Point)) (x : mat_Point)) ==> ((((col (Q : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> ((((col (B : mat_Point)) (x : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (x : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))))` 
                                                                    (
                                                                    SPEC `\ M0 : mat_Point. ((((betS (P : mat_Point)) (M0 : mat_Point)) (Q : mat_Point)) ==> (((((cong (M0 : mat_Point)) (P : mat_Point)) (M0 : mat_Point)) (Q : mat_Point)) ==> (((((cong (P : mat_Point)) (M0 : mat_Point)) (Q : mat_Point)) (M0 : mat_Point)) ==> ((((col (P : mat_Point)) (M0 : mat_Point)) (Q : mat_Point)) ==> ((((col (P : mat_Point)) (Q : mat_Point)) (M0 : mat_Point)) ==> ((((col (Q : mat_Point)) (B : mat_Point)) (M0 : mat_Point)) ==> ((((col (B : mat_Point)) (M0 : mat_Point)) (A : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (M0 : mat_Point)) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__ind__r
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))))))
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (M : mat_Point))) (((col (A : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (B : mat_Point)) (M : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (B : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (Q : mat_Point)) (B : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (A : mat_Point))) ((mat_and (((col (Q : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)) ==> mat_false) ==> (((col (Q : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (Q : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (M : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (M : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))) (((col (Q : mat_Point)) (M : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_and (((col (B : mat_Point)) (Q : mat_Point)) (P : mat_Point))) ((mat_and (((col (Q : mat_Point)) (P : mat_Point)) (B : mat_Point))) ((mat_and (((col (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))) (((col (Q : mat_Point)) (B : mat_Point)) (P : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (P : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (M : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (P : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) (((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (M : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))) ((((cong (M : mat_Point)) (P : mat_Point)) (M : mat_Point)) (Q : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    proposition__10
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (P : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (P : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (P : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (Q : mat_Point))) ((mat_and ((neq (P : mat_Point)) (B : mat_Point))) ((neq (P : mat_Point)) (Q : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (P : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (P : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (P : mat_Point)) (C : mat_Point)) (C : mat_Point)) (Q : mat_Point))) ((((cong (C : mat_Point)) (P : mat_Point)) (Q : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (P : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencetransitive
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (P : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (Q : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__congruencesymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (Q : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(Q : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Circle)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__circle__center__radius
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(onCirc (Q : mat_Point)) (K : mat_Circle)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(P : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Circle)` 
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__circle__center__radius
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(onCirc (P : mat_Point)) (K : mat_Circle)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (Q : mat_Point))) ((mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (Q : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) (((betS (A : mat_Point)) (Q : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (Q : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point)`
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ Q : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `ex (\ P : mat_Point. (ex (\ Q : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (P : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Q : mat_Point))) ((mat_and ((onCirc (P : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Q : mat_Point)) (K : mat_Circle))) (((betS (P : mat_Point)) (B : mat_Point)) (Q : mat_Point)))))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (X : mat_Point))) ((mat_and (((betS (A : mat_Point)) (B : mat_Point)) (Y : mat_Point))) ((mat_and ((onCirc (X : mat_Point)) (K : mat_Circle))) ((mat_and ((onCirc (Y : mat_Point)) (K : mat_Circle))) (((betS (X : mat_Point)) (B : mat_Point)) (Y : mat_Point))))))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(E : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(K : mat_Circle)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    postulate__line__circle
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(inCirc (B : mat_Point)) (K : mat_Circle)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (x : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))) ==> (ex (\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (X : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (X : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (x : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (E : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (x : mat_Point)))))))))))) ==> (ex (\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (E : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point)))))))))))))))` 
                                                                    (
                                                                    SPEC `\ Y : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (Y : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (E : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (Y : mat_Point))))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (x : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (x : mat_Point))) ((mat_and (((betS (x : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (x : mat_Point)) (E : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (x : mat_Point)) (B : mat_Point)) (x : mat_Point)) (B : mat_Point)))))))))) ==> (ex (\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (E : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (B : mat_Point)))))))))))))` 
                                                                    (
                                                                    SPEC `\ U : mat_Point. (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (U : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (U : mat_Point))) ((mat_and (((betS (U : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (U : mat_Point)) (E : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (U : mat_Point)) (B : mat_Point)) (U : mat_Point)) (B : mat_Point))))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. ((ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (C : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (E : mat_Point)) (x : mat_Point)) (W : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ==> (ex (\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (C : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (E : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))))))` 
                                                                    (
                                                                    SPEC `\ V : mat_Point. (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (C : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (E : mat_Point)) (V : mat_Point)) (W : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(E : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and ((((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (x : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> (ex (\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (W : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))))` 
                                                                    (
                                                                    SPEC `\ W : mat_Point. ((mat_and ((((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (W : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (W : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point))) ((((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                   ))))))))))
                                                                  )
                                                                 ) (SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    cn__congruencereflexive
                                                                    ))))
                                                               ) (ASSUME `(((cong (C : mat_Point)) (E : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                               ))))
                                                         ) (ASSUME `ex (\ K : mat_Circle. ((((cI (K : mat_Circle)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(E : mat_Point)` 
                                                           (SPEC `(C : mat_Point)` 
                                                            (postulate__Euclid3
                                                            ))
                                                          ) (ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                                          )))
                                                     ) (MP  
                                                        (MP  
                                                         (SPEC `(F : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(E : mat_Point)` 
                                                             (lemma__3__6b)))
                                                          )
                                                         ) (ASSUME `((betS (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                         )
                                                        ) (ASSUME `((betS (E : mat_Point)) (C : mat_Point)) (F : mat_Point)`
                                                        )))
                                                   ) (MP  
                                                      (SPEC `(E : mat_Point)` 
                                                       (SPEC `(B : mat_Point)` 
                                                        (SPEC `(C : mat_Point)` 
                                                         (axiom__betweennesssymmetry
                                                         )))
                                                      ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                                      )))
                                                 ) (MP  
                                                    (MP  
                                                     (SPEC `(E : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(C : mat_Point)` 
                                                        (SPEC `(E : mat_Point)` 
                                                         (SPEC `(F : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (lemma__congruencetransitive
                                                           ))))))
                                                     ) (ASSUME `(((cong (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                                                     )
                                                    ) (ASSUME `(((cong (E : mat_Point)) (C : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                                                    )))
                                               ) (SPEC `(E : mat_Point)` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (cn__congruencereflexive))
                                               ))
                                             ) (SPEC `(C : mat_Point)` 
                                                (SPEC `(E : mat_Point)` 
                                                 (cn__equalityreverse))))))
                                       ) (ASSUME `(mat_and (((betS (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))`
                                       ))))
                                 ) (ASSUME `ex (\ F : mat_Point. ((mat_and (((betS (E : mat_Point)) (C : mat_Point)) (F : mat_Point))) ((((cong (C : mat_Point)) (F : mat_Point)) (E : mat_Point)) (C : mat_Point))))`
                                 ))
                               ) (MP  
                                  (MP  
                                   (SPEC `(C : mat_Point)` 
                                    (SPEC `(E : mat_Point)` 
                                     (SPEC `(C : mat_Point)` 
                                      (SPEC `(E : mat_Point)` 
                                       (lemma__extension))))
                                   ) (ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                   )
                                  ) (ASSUME `(neq (E : mat_Point)) (C : mat_Point)`
                                  )))
                             ) (MP  
                                (SPEC `(E : mat_Point)` 
                                 (SPEC `(C : mat_Point)` 
                                  (lemma__inequalitysymmetric))
                                ) (ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                )))
                           ) (MP  
                              (DISCH `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point)))` 
                               (MP  
                                (MP  
                                 (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                  (SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))` 
                                   (SPEC `(neq (B : mat_Point)) (E : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(neq (B : mat_Point)) (E : mat_Point)` 
                                    (DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))` 
                                     (MP  
                                      (MP  
                                       (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                        (SPEC `(neq (C : mat_Point)) (E : mat_Point)` 
                                         (SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                          (DISCH `(neq (C : mat_Point)) (E : mat_Point)` 
                                           (ASSUME `(neq (C : mat_Point)) (E : mat_Point)`
                                           )))
                                      ) (ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point))`
                                      ))))
                                ) (ASSUME `(mat_and ((neq (B : mat_Point)) (E : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (E : mat_Point)))`
                                ))
                              ) (MP  
                                 (SPEC `(E : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(C : mat_Point)` 
                                    (lemma__betweennotequal)))
                                 ) (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point)`
                                 ))))))
                     ) (ASSUME `(mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                     ))))
               ) (ASSUME `ex (\ E : mat_Point. ((mat_and (((betS (C : mat_Point)) (B : mat_Point)) (E : mat_Point))) ((((cong (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
               ))
             ) (MP  
                (MP  
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(C : mat_Point)` (lemma__extension))))
                 ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`)
                ) (ASSUME `(neq (C : mat_Point)) (B : mat_Point)`))))
          ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
             (MP  
              (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
               (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (col__nCol__False)))
                  ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                 )))
              ) (MP  
                 (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                  (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__introl))
                 ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)))))
        ) (MP  
           (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> ((neq (C : mat_Point)) (B : mat_Point))` 
            (SPEC `(C : mat_Point)` 
             (SPEC `(B : mat_Point)` (lemma__inequalitysymmetric)))
           ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`))))
     ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
        (MP  
         (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
          (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (MP  
             (SPEC `(C : mat_Point)` 
              (SPEC `(B : mat_Point)` 
               (SPEC `(A : mat_Point)` (col__nCol__False)))
             ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
             )
            ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
            )))
         ) (MP  
            (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
             (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__intror))
            ) (MP  
               (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                (SPEC `(eq (A : mat_Point)) (C : mat_Point)` (or__intror))
               ) (MP  
                  (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                   (SPEC `(eq (B : mat_Point)) (C : mat_Point)` (or__introl))
                  ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`))))))))))
 ;;


(*lemma__supplementsymmetric :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. ((((((supp A) B) C) E) D) ==> (((((supp D) B) E) C) A))))))`*)
let lemma__supplementsymmetric =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
      (MP  
       (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
        (MP  
         (DISCH `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
          (MP  
           (DISCH `((out (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
            (MP  
             (CONV_CONV_rule `((mat_and (((out (B : mat_Point)) (E : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point))) ==> (((((supp (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
              (DISCH `((((supp (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
               (ASSUME `((((supp (D : mat_Point)) (B : mat_Point)) (E : mat_Point)) (C : mat_Point)) (A : mat_Point)`
               ))
             ) (MP  
                (MP  
                 (SPEC `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                  (SPEC `((out (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                   (conj))
                 ) (ASSUME `((out (B : mat_Point)) (E : mat_Point)) (C : mat_Point)`
                 )
                ) (ASSUME `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                )))
           ) (MP  
              (MP  
               (SPEC `((out (B : mat_Point)) (E : mat_Point)) (C : mat_Point)` 
                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                 (SPEC `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                  (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                   (MP  
                    (SPEC `(E : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` (lemma__ray5)))
                    ) (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                    ))))
              ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
              )))
         ) (MP  
            (MP  
             (SPEC `((betS (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
              (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
               (SPEC `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                (and__ind)))
             ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                 (MP  
                  (SPEC `(D : mat_Point)` 
                   (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (axiom__betweennesssymmetry)))
                  ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                  ))))
            ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
            )))
       ) (MP  
          (CONV_CONV_rule `(((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) ==> ((mat_and (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
           (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
            (MP  
             (DISCH `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
              (MP  
               (MP  
                (SPEC `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                 (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                  (SPEC `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                   (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                    (MP  
                     (MP  
                      (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                       (SPEC `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)` 
                        (conj))
                      ) (ASSUME `((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point)`
                      )
                     ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                     ))))
               ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
               ))
             ) (ASSUME `(mat_and (((out (B : mat_Point)) (C : mat_Point)) (E : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
             )))
          ) (ASSUME `((((supp (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)`
          ))))))))
 ;;


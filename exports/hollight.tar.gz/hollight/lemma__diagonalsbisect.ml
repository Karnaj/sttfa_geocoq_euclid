(*lemma__diagonalsbisect :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((pG A) B) C) D) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint A) X) C)) (((midpoint B) X) D))))))))`*)
let lemma__diagonalsbisect =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
       (MP  
        (MP  
         (SPEC `ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
          (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
           (SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
            (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
         ) (GEN `(M : mat_Point)` 
            (DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
             (MP  
              (MP  
               (SPEC `ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                 (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                  (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                   (MP  
                    (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                     (MP  
                      (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                       (MP  
                        (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                           (DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                            (MP  
                             (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                              (MP  
                               (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                  (MP  
                                   (DISCH `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                        (MP  
                                         (DISCH `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))))) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                            (DISCH `(((cR (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (DISCH `(((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (MP  
                                                        (CONV_CONV_rule `((((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                         (DISCH `mat_not (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                          (MP  
                                                           (CONV_CONV_rule `(((nCol (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                            (DISCH `((triangle (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                             (MP  
                                                              (CONV_CONV_rule `((((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> mat_false) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                               (DISCH `mat_not (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                (MP  
                                                                 (CONV_CONV_rule `(((nCol (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                  (DISCH `((triangle (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (M : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((out (D : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (M : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (M : mat_Point)) (D : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point))))))) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (M : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((((congA (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((mat_and (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    DISCH `((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    CONV_CONV_rule `! x : mat_Point. (((mat_and (((midpoint (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))` 
                                                                    (
                                                                    SPEC `\ X : mat_Point. ((mat_and (((midpoint (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((midpoint (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    ex__intro
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((midpoint (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((midpoint (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (conj))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (D : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((cong (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (C : mat_Point)) (M : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((((cong (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((nCol (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((((congA (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) (M : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((cong (M : mat_Point)) (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (M : mat_Point)) (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) ((((((congA (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    proposition__26A
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `((triangle (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesflip
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (M : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (M : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    nCol__not__Col
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NChelper
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (D : mat_Point)`
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (M : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) ((mat_or (((betS (D : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (D : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((col (M : mat_Point)) (D : mat_Point)) (B : mat_Point))) ((mat_and (((col (D : mat_Point)) (B : mat_Point)) (M : mat_Point))) ((mat_and (((col (B : mat_Point)) (D : mat_Point)) (M : mat_Point))) (((col (D : mat_Point)) (M : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (D : mat_Point))) ((mat_or ((eq (M : mat_Point)) (D : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (D : mat_Point))) ((mat_or (((betS (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_or (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (M : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (D : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (D : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (B : mat_Point))) (((betS (D : mat_Point)) (B : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (D : mat_Point)) (B : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((neq (C : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (A : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (B : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (D : mat_Point)) (A : mat_Point))) ((neq (D : mat_Point)) (B : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((eq (A : mat_Point)) (A : mat_Point)))) ==> (((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((eq (A : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (B : mat_Point)) (D : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (D : mat_Point))) (((betS (B : mat_Point)) (D : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__29B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (M : mat_Point)) (C : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__ABCequalsCBA
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (M : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((triangle (M : mat_Point)) (C : mat_Point)) (D : mat_Point)))) ==> (((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (((nCol (M : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((triangle (M : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (M : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (C : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((eq (C : mat_Point)) (C : mat_Point)))) ==> (((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((eq (C : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (C : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))` 
                                                                    (
                                                                    SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (A : mat_Point))) (((betS (C : mat_Point)) (A : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (D : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (C : mat_Point)) (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (D : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (C : mat_Point)) (D : mat_Point))) ((mat_and ((neq (A : mat_Point)) (D : mat_Point))) ((mat_and ((neq (C : mat_Point)) (A : mat_Point))) ((mat_and ((neq (D : mat_Point)) (C : mat_Point))) ((neq (D : mat_Point)) (A : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((eq (D : mat_Point)) (D : mat_Point)))) ==> (((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((eq (D : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (D : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglestransitive
                                                                    )))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (M : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglessymmetric
                                                                    ))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalangleshelper
                                                                    ))))))))
                                                                    ) (
                                                                    ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((out (A : mat_Point)) (C : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) (((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point)))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (A : mat_Point))) ((mat_and ((neq (C : mat_Point)) (B : mat_Point))) ((neq (C : mat_Point)) (A : mat_Point))))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> (((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((eq (B : mat_Point)) (B : mat_Point)))) ==> (((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> ((eq (B : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    )))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    PINST [(`:mat_Point`,`:A`)] [] 
                                                                    (
                                                                    eq__refl)
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((out (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__ray4
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or ((eq (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__equalanglesreflexive
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    proposition__29B
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelflip
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    nCol__notCol
                                                                    )))
                                                                    ) (
                                                                    ASSUME `mat_not (((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                              ) (DISCH `((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (MP  
                                                                  (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (M : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))))) ==> mat_false` 
                                                                   (DISCH `((col (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (M : mat_Point)) (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (D : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) (((col (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) ==> mat_false) ==> (((col (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (C : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (M : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))))` 
                                                                   (SPEC `(eq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))` 
                                                                   (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                   (SPEC `(eq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                   (SPEC `((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                   (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                  ))))))))))
                                                           ) (MP  
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(A : mat_Point)` 
                                                                (SPEC `(M : mat_Point)` 
                                                                 (nCol__notCol
                                                                 )))
                                                              ) (ASSUME `mat_not (((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                              ))))
                                                        ) (DISCH `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                           (MP  
                                                            (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (M : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))))) ==> mat_false` 
                                                             (DISCH `((col (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                              (MP  
                                                               (DISCH `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                (MP  
                                                                 (DISCH `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                  (MP  
                                                                   (DISCH `(neq (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__parallelNC
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    not__nCol__Col
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    col__nCol__False
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    lemma__collinear4
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (M : mat_Point)) (A : mat_Point)`
                                                                    )))))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                                   ) (
                                                                   MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__inequalitysymmetric
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(neq (A : mat_Point)) (M : mat_Point)`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                   )))
                                                                 ) (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (A : mat_Point)) (M : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__betweennotequal
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )))
                                                               ) (MP  
                                                                  (MP  
                                                                   (SPEC `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                   ) (
                                                                   DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((col (M : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((col (C : mat_Point)) (A : mat_Point)) (M : mat_Point))) ((mat_and (((col (A : mat_Point)) (C : mat_Point)) (M : mat_Point))) (((col (C : mat_Point)) (M : mat_Point)) (A : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(M : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                  ) (
                                                                  ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                  ))))
                                                            ) (MP  
                                                               (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))))` 
                                                                (SPEC `(eq (A : mat_Point)) (M : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (MP  
                                                                  (SPEC `(mat_or ((eq (M : mat_Point)) (C : mat_Point))) ((mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point))))` 
                                                                   (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point)))` 
                                                                   (SPEC `(eq (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point))` 
                                                                   (SPEC `((betS (M : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (M : mat_Point)` 
                                                                   (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                                  )))))))))
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                             (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (MP  
                                                               (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                   (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                  (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__congruenceflip
                                                                    ))))
                                                                  ) (
                                                                  ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                  )))))
                                                         ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                         )))
                                                    ) (MP  
                                                       (MP  
                                                        (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                         (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (MP  
                                                             (DISCH `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                  (SPEC `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((mat_and ((((((congA (A : mat_Point)) (D : mat_Point)) (C : mat_Point)) (C : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((((((cong__3 (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (D : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    proposition__34
                                                                    ))))
                                                                ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                )))))
                                                       ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                       )))
                                                  ) (MP  
                                                     (MP  
                                                      (SPEC `(((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (DISCH `(mat_and ((((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((tS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((tS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `(((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                               (SPEC `(mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((tS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((tS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                (SPEC `(((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `(((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                 (DISCH `(mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((tS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((tS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))` 
                                                                  (MP  
                                                                   (MP  
                                                                    (
                                                                    SPEC `(((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((((tS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((tS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `(((tS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((((tS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((tS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `(((tS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(((tS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(((tS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((((tS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((tS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((tS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((tS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)))`
                                                                   ))))
                                                             ) (ASSUME `(mat_and ((((tS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((tS (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((tS (D : mat_Point)) (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ((((tS (D : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point))))`
                                                             ))
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(C : mat_Point)` 
                                                                (SPEC `(A : mat_Point)` 
                                                                 (SPEC `(D : mat_Point)` 
                                                                  (SPEC `(B : mat_Point)` 
                                                                   (lemma__crossimpliesopposite
                                                                   ))))
                                                               ) (ASSUME `(((cR (B : mat_Point)) (D : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                               )
                                                              ) (ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                              )))))
                                                     ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                     )))
                                                ) (MP  
                                                   (MP  
                                                    (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                     (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                       (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (MP  
                                                         (DISCH `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                              (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                               (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                   (SPEC `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                  (DISCH `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (A : mat_Point))) ((mat_and (((nCol (C : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) (((nCol (C : mat_Point)) (B : mat_Point)) (A : mat_Point)))))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(B : mat_Point)` 
                                                              (SPEC `(A : mat_Point)` 
                                                               (lemma__NCorder
                                                               )))
                                                            ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                            )))))
                                                   ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                   )))
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                     (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                            (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                             (DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                  (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                               ))))
                                                         ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                                         ))
                                                       ) (MP  
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(D : mat_Point)` 
                                                            (SPEC `(B : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (lemma__parallelNC
                                                              ))))
                                                          ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                          )))))
                                                 ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                 ))))
                                           ) (MP  
                                              (SPEC `(M : mat_Point)` 
                                               (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))))))` 
                                                (SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point)))` 
                                                 (PINST [(`:mat_Point`,`:A`)] [] 
                                                  (ex__intro))))
                                              ) (MP  
                                                 (MP  
                                                  (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                    (conj))
                                                  ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                  )
                                                 ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                 ))))
                                         ) (MP  
                                            (MP  
                                             (SPEC `((betS (D : mat_Point)) (M : mat_Point)) (B : mat_Point)` 
                                              (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (SPEC `(D : mat_Point)` 
                                                   (SPEC `(M : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (axiom__betweennesssymmetry
                                                     )))
                                                  ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                  ))))
                                            ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                            )))
                                       ) (MP  
                                          (MP  
                                           (SPEC `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                            (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(M : mat_Point)` 
                                                  (SPEC `(A : mat_Point)` 
                                                   (axiom__betweennesssymmetry
                                                   )))
                                                ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                ))))
                                          ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                          )))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                            (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                             (MP  
                                              (DISCH `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                   (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                        (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                         (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                          (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                           (ASSUME `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)))`
                                                ))
                                              ) (MP  
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(D : mat_Point)` 
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (lemma__parallelflip))))
                                                 ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                 )))))
                                        ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                        )))
                                   ) (MP  
                                      (MP  
                                       (SPEC `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                        (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                          (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (DISCH `(mat_and ((((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                (SPEC `(mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                 (SPEC `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `(mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (SPEC `(mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                       (SPEC `(((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                        (DISCH `(mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                            (SPEC `(((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                             (SPEC `(((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                              (and__ind)))
                                                           ) (DISCH `(((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                              (DISCH `(((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                               (ASSUME `(((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                               )))
                                                          ) (ASSUME `(mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                                                          ))))
                                                    ) (ASSUME `(mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point)))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((tS (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and ((((tS (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((tS (C : mat_Point)) (D : mat_Point)) (B : mat_Point)) (A : mat_Point))))`
                                              ))
                                            ) (MP  
                                               (MP  
                                                (SPEC `(D : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (SPEC `(C : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (lemma__crossimpliesopposite
                                                    ))))
                                                ) (ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                )
                                               ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                               )))))
                                      ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                      )))
                                 ) (MP  
                                    (MP  
                                     (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                      (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                        (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                         (MP  
                                          (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))` 
                                           (MP  
                                            (MP  
                                             (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                              (SPEC `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                               (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                (DISCH `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                                                 (MP  
                                                  (MP  
                                                   (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                    (SPEC `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                     (SPEC `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (and__ind)))
                                                   ) (DISCH `((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                      (DISCH `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                       (MP  
                                                        (MP  
                                                         (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                          (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                           (SPEC `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                            (and__ind)))
                                                         ) (DISCH `((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                            (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                             (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                                             )))
                                                        ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                        ))))
                                                  ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))`
                                                  ))))
                                            ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))))`
                                            ))
                                          ) (MP  
                                             (SPEC `(C : mat_Point)` 
                                              (SPEC `(D : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (lemma__parallelNC))))
                                             ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                             )))))
                                    ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                    )))
                               ) (MP  
                                  (MP  
                                   (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                    (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (DISCH `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                            (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                             (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                              (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                  (SPEC `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                   (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                    (DISCH `(((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                     (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point)`
                                                     )))
                                                ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point))`
                                                ))))
                                          ) (ASSUME `(mat_and ((((par (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((((par (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (C : mat_Point)))`
                                          ))
                                        ) (MP  
                                           (SPEC `(D : mat_Point)` 
                                            (SPEC `(C : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(A : mat_Point)` 
                                               (lemma__parallelflip))))
                                           ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                           )))))
                                  ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                  )))
                             ) (MP  
                                (MP  
                                 (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                  (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                    (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                     (MP  
                                      (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                                       (MP  
                                        (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                         (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                           (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                            ))))
                                      ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                      ))))
                                ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                ))))
                          ) (MP  
                             (SPEC `(M : mat_Point)` 
                              (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))` 
                               (SPEC `\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))` 
                                (PINST [(`:mat_Point`,`:A`)] [] (ex__intro)))
                              )
                             ) (MP  
                                (MP  
                                 (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                  (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                                   (conj))
                                 ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                 )
                                ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                ))))
                        ) (MP  
                           (MP  
                            (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                             (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (MP  
                                 (DISCH `(mat_and ((neq (M : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                     (SPEC `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                      (SPEC `(neq (M : mat_Point)) (D : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(neq (M : mat_Point)) (D : mat_Point)` 
                                       (DISCH `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                           (SPEC `(neq (B : mat_Point)) (D : mat_Point)` 
                                            (SPEC `(neq (B : mat_Point)) (M : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(neq (B : mat_Point)) (M : mat_Point)` 
                                             (DISCH `(neq (B : mat_Point)) (D : mat_Point)` 
                                              (ASSUME `(neq (B : mat_Point)) (D : mat_Point)`
                                              )))
                                         ) (ASSUME `(mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point))`
                                         ))))
                                   ) (ASSUME `(mat_and ((neq (M : mat_Point)) (D : mat_Point))) ((mat_and ((neq (B : mat_Point)) (M : mat_Point))) ((neq (B : mat_Point)) (D : mat_Point)))`
                                   ))
                                 ) (MP  
                                    (SPEC `(D : mat_Point)` 
                                     (SPEC `(M : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (lemma__betweennotequal)))
                                    ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                    )))))
                           ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                           )))
                      ) (MP  
                         (MP  
                          (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                           (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (and__ind)))
                          ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                             (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (DISCH `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                                (MP  
                                 (MP  
                                  (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                    (SPEC `(neq (M : mat_Point)) (C : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(neq (M : mat_Point)) (C : mat_Point)` 
                                     (DISCH `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                         (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                          (SPEC `(neq (A : mat_Point)) (M : mat_Point)` 
                                           (and__ind)))
                                        ) (DISCH `(neq (A : mat_Point)) (M : mat_Point)` 
                                           (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                                            (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                            )))
                                       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))`
                                       ))))
                                 ) (ASSUME `(mat_and ((neq (M : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (M : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))`
                                 ))
                               ) (MP  
                                  (SPEC `(C : mat_Point)` 
                                   (SPEC `(M : mat_Point)` 
                                    (SPEC `(A : mat_Point)` 
                                     (lemma__betweennotequal)))
                                  ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                  )))))
                         ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                         )))
                    ) (MP  
                       (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)))` 
                        (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                         (MP  
                          (DISCH `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                           (MP  
                            (MP  
                             (SPEC `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                              (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                     (conj))
                                   ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                   )
                                  ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                  ))))
                            ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                            ))
                          ) (ASSUME `(mat_and ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                          )))
                       ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                       )))))
              ) (ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))`
              ))))
        ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))`
        ))
      ) (MP  
         (SPEC `(D : mat_Point)` 
          (SPEC `(C : mat_Point)` 
           (SPEC `(B : mat_Point)` 
            (SPEC `(A : mat_Point)` (lemma__diagonalsmeet))))
         ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
         )))))))
 ;;


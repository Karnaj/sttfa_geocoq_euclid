(*proposition__03 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. (((((lt C) D) A) B) ==> (((((cong E) F) A) B) ==> (ex (\ X : mat_Point. ((mat_and (((betS E) X) F)) ((((cong E) X) C) D)))))))))))`*)
let proposition__03 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (DISCH `(((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
       (DISCH `(((cong (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
        (MP  
         (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
          (MP  
           (DISCH `(((lt (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
            (MP  
             (CONV_CONV_rule `((((lt (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point)))))` 
              (DISCH `ex (\ G : mat_Point. ((mat_and (((betS (E : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
               (MP  
                (MP  
                 (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                  (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (E : mat_Point)) (x : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (x : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ G : mat_Point. ((mat_and (((betS (E : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                   (SPEC `\ G : mat_Point. ((mat_and (((betS (E : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point)))` 
                    (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                 ) (GEN `(G : mat_Point)` 
                    (DISCH `(mat_and (((betS (E : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
                     (MP  
                      (MP  
                       (CONV_CONV_rule `((((betS (E : mat_Point)) (G : mat_Point)) (F : mat_Point)) ==> (((((cong (E : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((lt (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)))) ==> (((mat_and (((betS (E : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))))` 
                        (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (E : mat_Point)) (X : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (X : mat_Point)) (C : mat_Point)) (D : mat_Point))))` 
                         (SPEC `(((cong (E : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                          (SPEC `((betS (E : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                           (and__ind))))
                       ) (DISCH `((betS (E : mat_Point)) (G : mat_Point)) (F : mat_Point)` 
                          (DISCH `(((cong (E : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                           (ASSUME `(((lt (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                           )))
                      ) (ASSUME `(mat_and (((betS (E : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point))`
                      ))))
                ) (ASSUME `ex (\ G : mat_Point. ((mat_and (((betS (E : mat_Point)) (G : mat_Point)) (F : mat_Point))) ((((cong (E : mat_Point)) (G : mat_Point)) (C : mat_Point)) (D : mat_Point))))`
                )))
             ) (ASSUME `(((lt (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
             ))
           ) (MP  
              (MP  
               (SPEC `(F : mat_Point)` 
                (SPEC `(E : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` 
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(C : mat_Point)` (lemma__lessthancongruence))))))
               ) (ASSUME `(((lt (C : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
               )
              ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (F : mat_Point)`
              )))
         ) (MP  
            (SPEC `(B : mat_Point)` 
             (SPEC `(F : mat_Point)` 
              (SPEC `(E : mat_Point)` 
               (SPEC `(A : mat_Point)` (lemma__congruencesymmetric))))
            ) (ASSUME `(((cong (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)`
            ))))))))))
 ;;


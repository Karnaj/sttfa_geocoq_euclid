(*lemma__fiveline :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! a : mat_Point. (! b : mat_Point. (! c : mat_Point. (! d : mat_Point. ((((col A) B) C) ==> (((((cong A) B) a) b) ==> (((((cong B) C) b) c) ==> (((((cong A) D) a) d) ==> (((((cong C) D) c) d) ==> (((((cong A) C) a) c) ==> (((neq A) C) ==> ((((cong B) D) b) d)))))))))))))))`*)
let lemma__fiveline =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(a : mat_Point)` 
     (GEN `(b : mat_Point)` 
      (GEN `(c : mat_Point)` 
       (GEN `(d : mat_Point)` 
        (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
         (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
          (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
           (DISCH `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
            (DISCH `(((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
             (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
              (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
               (MP  
                (CONV_CONV_rule `(((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                 (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                  (MP  
                   (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                    (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                    )
                   ) (MP  
                      (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                       (MP  
                        (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                         (MP  
                          (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                           (MP  
                            (MP  
                             (MP  
                              (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                               (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                 (or__ind)))
                              ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                 (MP  
                                  (DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                   (MP  
                                    (DISCH `(((cong (a : mat_Point)) (b : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                     (MP  
                                      (CONV_CONV_rule `(((neq (a : mat_Point)) (b : mat_Point)) ==> mat_false) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                       (DISCH `mat_not ((neq (a : mat_Point)) (b : mat_Point))` 
                                        (MP  
                                         (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                          (MP  
                                           (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                            (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                            )
                                           ) (MP  
                                              (SPEC `(b : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> (! y : mat_Point. (((eq (a : mat_Point)) (y : mat_Point)) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (y : mat_Point)) (d : mat_Point))))` 
                                                 (SPEC `\ X : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (X : mat_Point)) (d : mat_Point))` 
                                                  (SPEC `(a : mat_Point)` 
                                                   (PINST [(`:mat_Point`,`:A`)] [] 
                                                    (eq__ind))))
                                                ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                ))
                                              ) (MP  
                                                 (CONV_CONV_rule `(mat_not ((neq (a : mat_Point)) (b : mat_Point))) ==> ((eq (a : mat_Point)) (b : mat_Point))` 
                                                  (SPEC `(eq (a : mat_Point)) (b : mat_Point)` 
                                                   (nNPP))
                                                 ) (ASSUME `mat_not ((neq (a : mat_Point)) (b : mat_Point))`
                                                 ))))
                                         ) (MP  
                                            (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (MP  
                                                  (MP  
                                                   (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((neq (A : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point))))))))` 
                                                    (SPEC `(A : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `((((col (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((neq (x : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (x : mat_Point)) (B : mat_Point))) ((mat_or ((eq (x : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_or (((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (x : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point))))))))))` 
                                                       (SPEC `\ A0 : mat_Point. ((((col (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((neq (A0 : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (A0 : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A0 : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A0 : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A0 : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point))))))))` 
                                                        (SPEC `(B : mat_Point)` 
                                                         (PINST [(`:mat_Point`,`:A`)] [] 
                                                          (eq__ind__r))))
                                                      ) (DISCH `((col (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                          (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                           (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                            (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                             (DISCH `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                              (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                              )))))))))
                                                   ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                   )
                                                  ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                  )
                                                 ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                 )
                                                ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                )
                                               ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                               )
                                              ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                              ))
                                            ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                            ))))
                                      ) (DISCH `(neq (a : mat_Point)) (b : mat_Point)` 
                                         (MP  
                                          (DISCH `(neq (B : mat_Point)) (B : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                             (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                              (MP  
                                               (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                (ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                )
                                               ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                               )))
                                            ) (SPEC `(B : mat_Point)` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (eq__refl))))
                                          ) (MP  
                                             (MP  
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(B : mat_Point)` 
                                                (SPEC `(b : mat_Point)` 
                                                 (SPEC `(a : mat_Point)` 
                                                  (axiom__nocollapse))))
                                              ) (ASSUME `(neq (a : mat_Point)) (b : mat_Point)`
                                              )
                                             ) (ASSUME `(((cong (a : mat_Point)) (b : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                             )))))
                                    ) (MP  
                                       (SPEC `(b : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (SPEC `(B : mat_Point)` 
                                          (SPEC `(a : mat_Point)` 
                                           (lemma__congruencesymmetric))))
                                       ) (ASSUME `(((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                       )))
                                  ) (MP  
                                     (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))` 
                                      (MP  
                                       (MP  
                                        (MP  
                                         (MP  
                                          (MP  
                                           (MP  
                                            (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((neq (A : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))))))))` 
                                             (SPEC `(A : mat_Point)` 
                                              (MP  
                                               (CONV_CONV_rule `((((col (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((neq (B : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((col (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (x : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((neq (x : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (x : mat_Point)) (B : mat_Point))) ((mat_or ((eq (x : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point))) ((mat_or (((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (x : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))))))))))` 
                                                (SPEC `\ A0 : mat_Point. ((((col (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A0 : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (A0 : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)) ==> (((((cong (A0 : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)) ==> (((neq (A0 : mat_Point)) (C : mat_Point)) ==> (((mat_or ((eq (A0 : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A0 : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A0 : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A0 : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point))))))))` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (PINST [(`:mat_Point`,`:A`)] [] 
                                                   (eq__ind__r))))
                                               ) (DISCH `((col (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                   (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)` 
                                                    (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                     (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                                      (DISCH `(mat_or ((eq (B : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                                       (ASSUME `(((cong (B : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                       )))))))))
                                            ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                            )
                                           ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                           )
                                          ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                          )
                                         ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                         )
                                        ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                        )
                                       ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                       ))
                                     ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                     ))))
                             ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                (MP  
                                 (MP  
                                  (MP  
                                   (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                    (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                     (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                      (or__ind)))
                                   ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                      (MP  
                                       (DISCH `(((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                        (MP  
                                         (DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (B : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `(((neq (b : mat_Point)) (c : mat_Point)) ==> mat_false) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                            (DISCH `mat_not ((neq (b : mat_Point)) (c : mat_Point))` 
                                             (MP  
                                              (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                 (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                 )
                                                ) (MP  
                                                   (SPEC `(b : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `((((cong (B : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)) ==> (! x : mat_Point. (((eq (x : mat_Point)) (c : mat_Point)) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (x : mat_Point)) (d : mat_Point))))` 
                                                      (SPEC `\ X : mat_Point. ((((cong (B : mat_Point)) (D : mat_Point)) (X : mat_Point)) (d : mat_Point))` 
                                                       (SPEC `(c : mat_Point)` 
                                                        (PINST [(`:mat_Point`,`:A`)] [] 
                                                         (eq__ind__r))))
                                                     ) (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                     ))
                                                   ) (MP  
                                                      (CONV_CONV_rule `(mat_not ((neq (b : mat_Point)) (c : mat_Point))) ==> ((eq (b : mat_Point)) (c : mat_Point))` 
                                                       (SPEC `(eq (b : mat_Point)) (c : mat_Point)` 
                                                        (nNPP))
                                                      ) (ASSUME `mat_not ((neq (b : mat_Point)) (c : mat_Point))`
                                                      ))))
                                              ) (MP  
                                                 (MP  
                                                  (MP  
                                                   (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point))))` 
                                                    (MP  
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> (((((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (B : mat_Point)) ==> ((((cong (B : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point))))))))` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (MP  
                                                           (CONV_CONV_rule `((((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))))))) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (b : mat_Point)) (c : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> ((((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (x : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (x : mat_Point)) (C : mat_Point))) ((mat_or (((betS (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point))))))) ==> (((((cong (x : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (b : mat_Point)) (c : mat_Point)) (x : mat_Point)) (x : mat_Point)) ==> ((((cong (x : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point))))))))))` 
                                                            (SPEC `\ B0 : mat_Point. ((((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (B0 : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B0 : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B0 : mat_Point))))))) ==> (((((cong (B0 : mat_Point)) (B0 : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((((cong (b : mat_Point)) (c : mat_Point)) (B0 : mat_Point)) (B0 : mat_Point)) ==> ((((cong (B0 : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point))))))))` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (PINST [(`:mat_Point`,`:A`)] [] 
                                                               (eq__ind__r)))
                                                            )
                                                           ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                              (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                               (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))))))` 
                                                                 (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                                  (DISCH `(((cong (b : mat_Point)) (c : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                                   (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                                   )))))))))
                                                        ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                        )
                                                       ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                      )
                                                     ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                     ))
                                                   ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                   )
                                                  ) (ASSUME `(((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                  )
                                                 ) (ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                 ))))
                                           ) (DISCH `(neq (b : mat_Point)) (c : mat_Point)` 
                                              (MP  
                                               (DISCH `(neq (B : mat_Point)) (B : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                  (DISCH `(eq (B : mat_Point)) (B : mat_Point)` 
                                                   (MP  
                                                    (CONV_CONV_rule `((eq (B : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                     (ASSUME `(neq (B : mat_Point)) (B : mat_Point)`
                                                     )
                                                    ) (ASSUME `(eq (B : mat_Point)) (B : mat_Point)`
                                                    )))
                                                 ) (SPEC `(B : mat_Point)` 
                                                    (PINST [(`:mat_Point`,`:A`)] [] 
                                                     (eq__refl))))
                                               ) (MP  
                                                  (MP  
                                                   (SPEC `(B : mat_Point)` 
                                                    (SPEC `(B : mat_Point)` 
                                                     (SPEC `(c : mat_Point)` 
                                                      (SPEC `(b : mat_Point)` 
                                                       (axiom__nocollapse))))
                                                   ) (ASSUME `(neq (b : mat_Point)) (c : mat_Point)`
                                                   )
                                                  ) (ASSUME `(((cong (b : mat_Point)) (c : mat_Point)) (B : mat_Point)) (B : mat_Point)`
                                                  )))))
                                         ) (MP  
                                            (SPEC `(c : mat_Point)` 
                                             (SPEC `(B : mat_Point)` 
                                              (SPEC `(B : mat_Point)` 
                                               (SPEC `(b : mat_Point)` 
                                                (lemma__congruencesymmetric))
                                              ))
                                            ) (ASSUME `(((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                            )))
                                       ) (MP  
                                          (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (MP  
                                              (MP  
                                               (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> ((((cong (B : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                (SPEC `(B : mat_Point)` 
                                                 (MP  
                                                  (CONV_CONV_rule `((((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))))))) ==> ((((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((col (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (x : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (x : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (x : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (x : mat_Point)) (C : mat_Point))) ((mat_or (((betS (x : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point))))))) ==> ((((cong (x : mat_Point)) (x : mat_Point)) (b : mat_Point)) (c : mat_Point))))))))` 
                                                   (SPEC `\ B0 : mat_Point. ((((col (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((((cong (A : mat_Point)) (B0 : mat_Point)) (a : mat_Point)) (b : mat_Point)) ==> (((((cong (B0 : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)) ==> (((mat_or ((eq (A : mat_Point)) (B0 : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B0 : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B0 : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B0 : mat_Point))))))) ==> ((((cong (B0 : mat_Point)) (B0 : mat_Point)) (b : mat_Point)) (c : mat_Point))))))` 
                                                    (SPEC `(C : mat_Point)` 
                                                     (PINST [(`:mat_Point`,`:A`)] [] 
                                                      (eq__ind__r))))
                                                  ) (DISCH `((col (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                                                     (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                      (DISCH `(((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                       (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (C : mat_Point)) (C : mat_Point))) ((mat_or (((betS (C : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))))))` 
                                                        (ASSUME `(((cong (C : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                        )))))))
                                               ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                               )
                                              ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                              )
                                             ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                             )
                                            ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                            ))
                                          ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                          ))))
                                  ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                     (MP  
                                      (MP  
                                       (MP  
                                        (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                         (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                          (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                           (or__ind)))
                                        ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (DISCH `((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                             (MP  
                                              (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((betS (c : mat_Point)) (a : mat_Point)) (b : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                       (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                       )
                                                      ) (MP  
                                                         (DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                             (SPEC `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                              (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                               (DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                   (SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                  (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                   (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                   )))
                                                                 ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(b : mat_Point)` 
                                                             (SPEC `(d : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (lemma__congruenceflip
                                                                ))))
                                                            ) (ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (d : mat_Point)) (b : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(d : mat_Point)` 
                                                             (SPEC `(b : mat_Point)` 
                                                              (SPEC `(a : mat_Point)` 
                                                               (SPEC `(c : mat_Point)` 
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (SPEC `(C : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                            ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                            )
                                                           ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                          )
                                                         ) (ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                         )
                                                        ) (ASSUME `((betS (c : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(b : mat_Point)` 
                                                         (SPEC `(a : mat_Point)` 
                                                          (SPEC `(c : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (SPEC `(C : mat_Point)` 
                                                              (lemma__betweennesspreserved
                                                              ))))))
                                                        ) (ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                      )
                                                     ) (ASSUME `((betS (C : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                       (SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                        (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                         (DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                             (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                              (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                               (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)))`
                                                     ))
                                                   ) (MP  
                                                      (SPEC `(c : mat_Point)` 
                                                       (SPEC `(b : mat_Point)` 
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (lemma__congruenceflip
                                                          ))))
                                                      ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                      ))))
                                              ) (MP  
                                                 (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)))` 
                                                  (MP  
                                                   (MP  
                                                    (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                     (SPEC `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                      (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                       (and__ind)))
                                                    ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                       (DISCH `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                           (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                            (SPEC `(((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                             (and__ind)))
                                                          ) (DISCH `(((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point)` 
                                                             (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)` 
                                                              (ASSUME `(((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point)`
                                                              )))
                                                         ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point))`
                                                         ))))
                                                   ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (c : mat_Point)) (a : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (A : mat_Point)) (a : mat_Point)) (c : mat_Point))) ((((cong (A : mat_Point)) (C : mat_Point)) (c : mat_Point)) (a : mat_Point)))`
                                                   ))
                                                 ) (MP  
                                                    (SPEC `(c : mat_Point)` 
                                                     (SPEC `(a : mat_Point)` 
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(A : mat_Point)` 
                                                        (lemma__congruenceflip
                                                        ))))
                                                    ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                    ))))
                                            ) (MP  
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(A : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (axiom__betweennesssymmetry
                                                  )))
                                               ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                               ))))
                                       ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                          (MP  
                                           (MP  
                                            (MP  
                                             (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                              (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                               (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (or__ind)))
                                             ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (DISCH `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                  (MP  
                                                   (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                    (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                    )
                                                   ) (MP  
                                                      (MP  
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (SPEC `(d : mat_Point)` 
                                                            (SPEC `(c : mat_Point)` 
                                                             (SPEC `(b : mat_Point)` 
                                                              (SPEC `(a : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (lemma__interior5
                                                                   ))))))))
                                                           ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                           )
                                                          ) (ASSUME `((betS (a : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                          )
                                                         ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                      )))
                                                 ) (MP  
                                                    (MP  
                                                     (MP  
                                                      (MP  
                                                       (SPEC `(c : mat_Point)` 
                                                        (SPEC `(b : mat_Point)` 
                                                         (SPEC `(a : mat_Point)` 
                                                          (SPEC `(C : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(A : mat_Point)` 
                                                             (lemma__betweennesspreserved
                                                             ))))))
                                                       ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                      )
                                                     ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                     )
                                                    ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                    ))))
                                            ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                               (MP  
                                                (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                   (MP  
                                                    (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                     (MP  
                                                      (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                       (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                       )
                                                      ) (MP  
                                                         (DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                             (SPEC `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                              (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                               (DISCH `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                   (SPEC `(((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                    (
                                                                    SPEC `(((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point)` 
                                                                  (DISCH `(((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)` 
                                                                   (ASSUME `(((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point)`
                                                                   )))
                                                                 ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point))`
                                                                 ))))
                                                           ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (b : mat_Point)) (d : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (D : mat_Point)) (d : mat_Point)) (b : mat_Point))) ((((cong (D : mat_Point)) (B : mat_Point)) (b : mat_Point)) (d : mat_Point)))`
                                                           ))
                                                         ) (MP  
                                                            (SPEC `(b : mat_Point)` 
                                                             (SPEC `(d : mat_Point)` 
                                                              (SPEC `(B : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (lemma__congruenceflip
                                                                ))))
                                                            ) (ASSUME `(((cong (D : mat_Point)) (B : mat_Point)) (d : mat_Point)) (b : mat_Point)`
                                                            ))))
                                                    ) (MP  
                                                       (MP  
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(d : mat_Point)` 
                                                             (SPEC `(b : mat_Point)` 
                                                              (SPEC `(c : mat_Point)` 
                                                               (SPEC `(a : mat_Point)` 
                                                                (SPEC `(D : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(C : mat_Point)` 
                                                                   (SPEC `(A : mat_Point)` 
                                                                    (
                                                                    axiom__5__line
                                                                    ))))))))
                                                            ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                            )
                                                           ) (ASSUME `(((cong (A : mat_Point)) (D : mat_Point)) (a : mat_Point)) (d : mat_Point)`
                                                           )
                                                          ) (ASSUME `(((cong (C : mat_Point)) (D : mat_Point)) (c : mat_Point)) (d : mat_Point)`
                                                          )
                                                         ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                         )
                                                        ) (ASSUME `((betS (a : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                       )))
                                                  ) (MP  
                                                     (MP  
                                                      (MP  
                                                       (MP  
                                                        (SPEC `(b : mat_Point)` 
                                                         (SPEC `(c : mat_Point)` 
                                                          (SPEC `(a : mat_Point)` 
                                                           (SPEC `(B : mat_Point)` 
                                                            (SPEC `(C : mat_Point)` 
                                                             (SPEC `(A : mat_Point)` 
                                                              (lemma__betweennesspreserved
                                                              ))))))
                                                        ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (a : mat_Point)) (c : mat_Point)`
                                                        )
                                                       ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (a : mat_Point)) (b : mat_Point)`
                                                       )
                                                      ) (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                      )
                                                     ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                     )))
                                                ) (MP  
                                                   (DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                       (SPEC `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                        (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                         (DISCH `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                             (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                              (SPEC `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `(((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point)` 
                                                               (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)` 
                                                                (ASSUME `(((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (c : mat_Point)) (b : mat_Point))) ((mat_and ((((cong (C : mat_Point)) (B : mat_Point)) (b : mat_Point)) (c : mat_Point))) ((((cong (B : mat_Point)) (C : mat_Point)) (c : mat_Point)) (b : mat_Point)))`
                                                     ))
                                                   ) (MP  
                                                      (SPEC `(c : mat_Point)` 
                                                       (SPEC `(b : mat_Point)` 
                                                        (SPEC `(C : mat_Point)` 
                                                         (SPEC `(B : mat_Point)` 
                                                          (lemma__congruenceflip
                                                          ))))
                                                      ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (b : mat_Point)) (c : mat_Point)`
                                                      )))))
                                           ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                           )))
                                      ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                      )))
                                 ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                 )))
                            ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                            ))
                          ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                          ))
                        ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                        ))
                      ) (MP  
                         (CONV_CONV_rule `((mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false) ==> ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                          (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                           (nNPP))
                         ) (DISCH `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                            (MP  
                             (MP  
                              (MP  
                               (SPEC `mat_false` 
                                (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                 (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                  (or__ind)))
                               ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                  (MP  
                                   (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                    (MP  
                                     (DISCH `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                      (MP  
                                       (DISCH `mat_false` 
                                        (MP  
                                         (DISCH `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                          (MP  
                                           (DISCH `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                                            (MP  
                                             (DISCH `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                              (MP  
                                               (DISCH `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                                (MP  
                                                 (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                  (MP  
                                                   (DISCH `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                    (MP  
                                                     (SPEC `mat_false` 
                                                      (false__ind)
                                                     ) (ASSUME `mat_false`))
                                                   ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                      (MP  
                                                       (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                       ) (MP  
                                                          (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                           (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                            (or__intror))
                                                          ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                          )))))
                                                 ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (MP  
                                                     (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                     ) (MP  
                                                        (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                         (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                          (or__introl))
                                                        ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                        )))))
                                               ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                  (MP  
                                                   (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                   ) (MP  
                                                      (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                       (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                        (or__intror))
                                                      ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                      )))))
                                             ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                (MP  
                                                 (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                 ) (MP  
                                                    (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                     (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                      (or__introl))
                                                    ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                    )))))
                                           ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                              (MP  
                                               (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                               ) (MP  
                                                  (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                   (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                    (or__intror))
                                                  ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                  )))))
                                         ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                            (MP  
                                             (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                             ) (MP  
                                                (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                 (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                  (or__introl))
                                                ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                )))))
                                       ) (MP  
                                          (ASSUME `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false`
                                          ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                          )))
                                     ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                        (MP  
                                         (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                          (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                          )
                                         ) (MP  
                                            (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                             (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                              (or__intror))
                                            ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                            )))))
                                   ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                      (MP  
                                       (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                        (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                        )
                                       ) (MP  
                                          (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                           (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                            (or__introl))
                                          ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                          ))))))
                              ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                 (MP  
                                  (MP  
                                   (MP  
                                    (SPEC `mat_false` 
                                     (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                      (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                       (or__ind)))
                                    ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (DISCH `mat_false` 
                                         (MP  
                                          (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                           (MP  
                                            (DISCH `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                             (MP  
                                              (DISCH `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                               (MP  
                                                (DISCH `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                                                 (MP  
                                                  (DISCH `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                   (MP  
                                                    (DISCH `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                                     (MP  
                                                      (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                       (MP  
                                                        (DISCH `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                         (MP  
                                                          (SPEC `mat_false` 
                                                           (false__ind)
                                                          ) (ASSUME `mat_false`
                                                          ))
                                                        ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                           (MP  
                                                            (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                            ) (MP  
                                                               (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                               )))))
                                                      ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                          ) (MP  
                                                             (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                              (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                               (or__introl))
                                                             ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                             )))))
                                                    ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                       (MP  
                                                        (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                        ) (MP  
                                                           (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                            (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (or__intror))
                                                           ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                           )))))
                                                  ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                     (MP  
                                                      (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                      ) (MP  
                                                         (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                          (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                           (or__introl))
                                                         ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                         )))))
                                                ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                   (MP  
                                                    (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                                    ) (MP  
                                                       (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                        (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                         (or__intror))
                                                       ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                       )))))
                                              ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                                  ) (MP  
                                                     (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                      (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                       (or__introl))
                                                     ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                     )))))
                                            ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                               (MP  
                                                (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                                 (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                 )
                                                ) (MP  
                                                   (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                    (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                     (or__intror))
                                                   ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                   )))))
                                          ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                             (MP  
                                              (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                               (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                               )
                                              ) (MP  
                                                 (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                  (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                   (or__introl))
                                                 ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                 )))))
                                        ) (MP  
                                           (CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                            (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                            )
                                           ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                           ))))
                                   ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                      (MP  
                                       (MP  
                                        (MP  
                                         (SPEC `mat_false` 
                                          (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                           (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                            (or__ind)))
                                         ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                            (MP  
                                             (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                              (MP  
                                               (DISCH `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                                (MP  
                                                 (DISCH `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                  (MP  
                                                   (DISCH `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                                                    (MP  
                                                     (DISCH `mat_false` 
                                                      (MP  
                                                       (DISCH `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                        (MP  
                                                         (DISCH `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                                          (MP  
                                                           (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                            (MP  
                                                             (DISCH `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                              (MP  
                                                               (SPEC `mat_false` 
                                                                (false__ind)
                                                               ) (ASSUME `mat_false`
                                                               ))
                                                             ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                (MP  
                                                                 (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                           ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (MP  
                                                               (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                               ) (MP  
                                                                  (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                  )))))
                                                         ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                            (MP  
                                                             (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                             ) (MP  
                                                                (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                 (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                  (or__intror
                                                                  ))
                                                                ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                )))))
                                                       ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                           ) (MP  
                                                              (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                               (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                (or__introl))
                                                              ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                              )))))
                                                     ) (MP  
                                                        (ASSUME `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false`
                                                        ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                        )))
                                                   ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                      (MP  
                                                       (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                                       ) (MP  
                                                          (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                           (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                            (or__intror))
                                                          ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                          )))))
                                                 ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                    (MP  
                                                     (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                                     ) (MP  
                                                        (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                         (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                          (or__introl))
                                                        ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                        )))))
                                               ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                  (MP  
                                                   (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                                    (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                    )
                                                   ) (MP  
                                                      (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                       (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                        (or__intror))
                                                      ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                      )))))
                                             ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                (MP  
                                                 (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                                  (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                  )
                                                 ) (MP  
                                                    (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                     (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                      (or__introl))
                                                    ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                    ))))))
                                        ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                           (MP  
                                            (MP  
                                             (MP  
                                              (SPEC `mat_false` 
                                               (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                 (or__ind)))
                                              ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                   (MP  
                                                    (DISCH `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                                     (MP  
                                                      (DISCH `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                       (MP  
                                                        (DISCH `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                                                         (MP  
                                                          (DISCH `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                           (MP  
                                                            (DISCH `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                                             (MP  
                                                              (DISCH `mat_false` 
                                                               (MP  
                                                                (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                 (MP  
                                                                  (DISCH `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                   (MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                  ) (
                                                                  DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                  (MP  
                                                                   (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                   )))))
                                                                ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                              ) (MP  
                                                                 (ASSUME `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false`
                                                                 ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                 )))
                                                            ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                               (MP  
                                                                (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                                ) (MP  
                                                                   (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                   )))))
                                                          ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                             (MP  
                                                              (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                              ) (MP  
                                                                 (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                  (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                   (or__introl
                                                                   ))
                                                                 ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                 )))))
                                                        ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                           (MP  
                                                            (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                                            ) (MP  
                                                               (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                               )))))
                                                      ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                                          ) (MP  
                                                             (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                              (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                               (or__introl))
                                                             ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                             )))))
                                                    ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                       (MP  
                                                        (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                                         (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                         )
                                                        ) (MP  
                                                           (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                            (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                             (or__intror))
                                                           ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                           )))))
                                                  ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                     (MP  
                                                      (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                                       (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                       )
                                                      ) (MP  
                                                         (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                          (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                           (or__introl))
                                                         ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                         ))))))
                                             ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                (MP  
                                                 (MP  
                                                  (MP  
                                                   (SPEC `mat_false` 
                                                    (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (or__ind)))
                                                   ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (MP  
                                                       (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                        (MP  
                                                         (DISCH `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                                          (MP  
                                                           (DISCH `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                            (MP  
                                                             (DISCH `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                                                              (MP  
                                                               (DISCH `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                (MP  
                                                                 (DISCH `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                                                  (MP  
                                                                   (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    ASSUME `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false`
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                   ) (
                                                                   DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                   (MP  
                                                                    (
                                                                    ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    )))))
                                                                 ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )))))
                                                               ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                  (MP  
                                                                   (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                   )))))
                                                             ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                (MP  
                                                                 (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                                                 ) (MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                    )))))
                                                           ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                              (MP  
                                                               (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                                               ) (MP  
                                                                  (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                   (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                  )))))
                                                         ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                            (MP  
                                                             (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                                              (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                              )
                                                             ) (MP  
                                                                (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                 (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                  (or__intror
                                                                  ))
                                                                ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                                )))))
                                                       ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                          (MP  
                                                           (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                                            (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                            )
                                                           ) (MP  
                                                              (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                               (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                (or__introl))
                                                              ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                              ))))))
                                                  ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                     (MP  
                                                      (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                       (MP  
                                                        (DISCH `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                                                         (MP  
                                                          (DISCH `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                           (MP  
                                                            (DISCH `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                                                             (MP  
                                                              (DISCH `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                               (MP  
                                                                (DISCH `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                                                 (MP  
                                                                  (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                   (MP  
                                                                    (
                                                                    DISCH `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    ASSUME `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false`
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    )))))
                                                                  ) (
                                                                  DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                  (MP  
                                                                   (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                   )))))
                                                                ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )))))
                                                              ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                 (MP  
                                                                  (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                   (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                  )))))
                                                            ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                               (MP  
                                                                (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                                                ) (MP  
                                                                   (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                                   )))))
                                                          ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                             (MP  
                                                              (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                                              ) (MP  
                                                                 (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                                  (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                                   (or__introl
                                                                   ))
                                                                 ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                 )))))
                                                        ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                           (MP  
                                                            (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                                             (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                             )
                                                            ) (MP  
                                                               (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                                (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                                 (or__intror)
                                                                )
                                                               ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                               )))))
                                                      ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                         (MP  
                                                          (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                                                           (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                           )
                                                          ) (MP  
                                                             (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                              (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                               (or__introl))
                                                             ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                             ))))))
                                                 ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                 )))
                                            ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                            )))
                                       ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                       )))
                                  ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                  )))
                             ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                             )))))))
                ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                ))))))))))))))))
 ;;


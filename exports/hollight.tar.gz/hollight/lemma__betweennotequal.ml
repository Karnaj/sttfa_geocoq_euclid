(*lemma__betweennotequal :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((betS A) B) C) ==> ((mat_and ((neq B) C)) ((mat_and ((neq A) B)) ((neq A) C))))))`*)
let lemma__betweennotequal =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
      (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
       (MP  
        (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
         (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
          (MP  
           (CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
            (DISCH `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
             (MP  
              (MP  
               (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))) ==> ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))))` 
                (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))` 
                 (SPEC `(neq (B : mat_Point)) (C : mat_Point)` (conj)))
               ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`)
              ) (MP  
                 (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point)))` 
                  (MP  
                   (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((neq (A : mat_Point)) (C : mat_Point)) ==> ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((neq (A : mat_Point)) (C : mat_Point))))` 
                    (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                     (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (conj)))
                   ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                   ))
                 ) (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`))
             ))
           ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
              (MP  
               (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                (MP  
                 (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                  (MP  
                   (CONV_CONV_rule `(((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false` 
                    (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                    )
                   ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                   ))
                 ) (SPEC `(B : mat_Point)` 
                    (SPEC `(A : mat_Point)` (axiom__betweennessidentity))))
               ) (MP  
                  (CONV_CONV_rule `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                   (MP  
                    (MP  
                     (CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))))` 
                      (SPEC `(A : mat_Point)` 
                       (MP  
                        (CONV_CONV_rule `((((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not ((eq (C : mat_Point)) (B : mat_Point))) ==> (((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not ((eq (x : mat_Point)) (B : mat_Point))) ==> (((betS (x : mat_Point)) (B : mat_Point)) (x : mat_Point))))))` 
                         (SPEC `\ A0 : mat_Point. ((((betS (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((mat_not ((eq (A0 : mat_Point)) (B : mat_Point))) ==> (((betS (A0 : mat_Point)) (B : mat_Point)) (A0 : mat_Point))))` 
                          (SPEC `(C : mat_Point)` 
                           (PINST [(`:mat_Point`,`:A`)] [] (eq__ind__r))))
                        ) (DISCH `((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                           (DISCH `mat_not ((eq (C : mat_Point)) (B : mat_Point))` 
                            (ASSUME `((betS (C : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                            )))))
                     ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`)
                    ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                    ))
                  ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`)
               )))))
        ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
           (MP  
            (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
             (MP  
              (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
               (MP  
                (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))` 
                 (MP  
                  (CONV_CONV_rule `(((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)) ==> mat_false` 
                   (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point))`
                   )
                  ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (A : mat_Point)`
                  ))
                ) (SPEC `(B : mat_Point)` 
                   (SPEC `(A : mat_Point)` (axiom__betweennessidentity))))
              ) (MP  
                 (MP  
                  (SPEC `(C : mat_Point)` 
                   (SPEC `(A : mat_Point)` 
                    (SPEC `(B : mat_Point)` 
                     (SPEC `(A : mat_Point)` (axiom__innertransitivity))))
                  ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                 )))
            ) (MP  
               (MP  
                (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                 (SPEC `(A : mat_Point)` 
                  (MP  
                   (CONV_CONV_rule `((((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (B : mat_Point)) ==> ((((betS (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((betS (B : mat_Point)) (x : mat_Point)) (C : mat_Point)))))` 
                    (SPEC `\ A0 : mat_Point. ((((betS (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((betS (B : mat_Point)) (A0 : mat_Point)) (C : mat_Point)))` 
                     (SPEC `(B : mat_Point)` 
                      (PINST [(`:mat_Point`,`:A`)] [] (eq__ind__r))))
                   ) (DISCH `((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (ASSUME `((betS (B : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                      ))))) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)
               ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
               ))))))
     ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
        (MP  
         (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
          (MP  
           (DISCH `((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
            (MP  
             (DISCH `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
              (MP  
               (CONV_CONV_rule `(((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                (ASSUME `mat_not (((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                )
               ) (ASSUME `((betS (B : mat_Point)) (C : mat_Point)) (B : mat_Point)`
               ))
             ) (SPEC `(C : mat_Point)` 
                (SPEC `(B : mat_Point)` (axiom__betweennessidentity))))
           ) (MP  
              (MP  
               (SPEC `(B : mat_Point)` 
                (SPEC `(C : mat_Point)` 
                 (SPEC `(B : mat_Point)` 
                  (SPEC `(A : mat_Point)` (lemma__3__6a))))
               ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
               )
              ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
              )))
         ) (MP  
            (MP  
             (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
              (SPEC `(B : mat_Point)` 
               (MP  
                (CONV_CONV_rule `((((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (C : mat_Point)) ==> ((((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (x : mat_Point)))))` 
                 (SPEC `\ B0 : mat_Point. ((((betS (A : mat_Point)) (B0 : mat_Point)) (C : mat_Point)) ==> (((betS (A : mat_Point)) (C : mat_Point)) (B0 : mat_Point)))` 
                  (SPEC `(C : mat_Point)` 
                   (PINST [(`:mat_Point`,`:A`)] [] (eq__ind__r))))
                ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point)` 
                   (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (C : mat_Point)`
                   ))))) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`)
            ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
            ))))))))
 ;;


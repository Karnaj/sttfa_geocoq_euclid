(*classic :  |- `! x : bool. ((mat_or x) (mat_not x))`*)
let classic =

 new_axiom `! x : bool. ((mat_or (x : bool)) (mat_not (x : bool)))`
 ;;

(*nNPP :  |- `! p : bool. ((mat_not (mat_not p)) ==> p)`*)
let nNPP =

 CONV_CONV_rule `! p0 : bool. ((mat_not (mat_not (p0 : bool))) ==> (p0 : bool))` 
 (GEN `(p : bool)` 
  (DISCH `((p : bool) ==> mat_false) ==> mat_false` 
   (MP  
    (MP  
     (MP  
      (SPEC `(p : bool)` 
       (SPEC `mat_not (p : bool)` (SPEC `(p : bool)` (or__ind)))
      ) (DISCH `(p : bool)` (ASSUME `(p : bool)`))
     ) (DISCH `mat_not (p : bool)` 
        (MP  
         (SPEC `(p : bool)` (false__ind)
         ) (MP  
            (CONV_CONV_rule `(mat_not (p : bool)) ==> mat_false` 
             (ASSUME `((p : bool) ==> mat_false) ==> mat_false`)
            ) (ASSUME `mat_not (p : bool)`))))) (SPEC `(p : bool)` (classic))
   )))
 ;;

(*col__or__nCol :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((mat_or (((col A) B) C)) (((nCol A) B) C))))`*)
let col__or__nCol =

 CONV_CONV_rule `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((mat_or (((col (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point))) (((nCol (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)))))` 
 (GEN `(A : mat_Point)` 
  (GEN `(B : mat_Point)` 
   (GEN `(C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `((mat_not ((mat_or ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))) ==> mat_false) ==> ((mat_or ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))` 
      (SPEC `(mat_or ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))` 
       (nNPP))
     ) (DISCH `mat_not ((mat_or ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))` 
        (MP  
         (DISCH `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
          (MP  
           (DISCH `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))) ==> mat_false` 
            (MP  
             (DISCH `((neq (A : mat_Point)) (B : mat_Point)) ==> (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false)` 
              (MP  
               (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                (MP  
                 (DISCH `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                  (MP  
                   (DISCH `((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                    (MP  
                     (DISCH `((neq (A : mat_Point)) (C : mat_Point)) ==> (((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false)` 
                      (MP  
                       (DISCH `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                        (MP  
                         (DISCH `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                          (MP  
                           (DISCH `((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false` 
                            (MP  
                             (DISCH `((neq (B : mat_Point)) (C : mat_Point)) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false)` 
                              (MP  
                               (DISCH `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                (MP  
                                 (DISCH `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                                  (MP  
                                   (DISCH `((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false` 
                                    (MP  
                                     (DISCH `(mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false)` 
                                      (MP  
                                       (DISCH `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                        (MP  
                                         (DISCH `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                          (MP  
                                           (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                            (MP  
                                             (DISCH `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                              (MP  
                                               (DISCH `((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false` 
                                                (MP  
                                                 (DISCH `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false)` 
                                                  (MP  
                                                   (DISCH `(mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                    (MP  
                                                     (DISCH `mat_false` 
                                                      (MP  
                                                       (SPEC `mat_false` 
                                                        (false__ind)
                                                       ) (ASSUME `mat_false`)
                                                      )
                                                     ) (MP  
                                                        (CONV_CONV_rule `((((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                                         (ASSUME `(mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false`
                                                         )
                                                        ) (ASSUME `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false`
                                                        )))
                                                   ) (MP  
                                                      (CONV_CONV_rule `((((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false)` 
                                                       (ASSUME `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false)`
                                                       )
                                                      ) (ASSUME `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false`
                                                      )))
                                                 ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                    (DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                     (MP  
                                                      (ASSUME `((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false`
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                           (SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                            (conj))
                                                          ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                          )
                                                         ) (ASSUME `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                         ))))))
                                               ) (MP  
                                                  (CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false)` 
                                                   (ASSUME `(mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false)`
                                                   )
                                                  ) (ASSUME `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false`
                                                  )))
                                             ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                (MP  
                                                 (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                 ) (MP  
                                                    (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (or__intror))
                                                    ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                    )))))
                                           ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (MP  
                                               (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                               ) (MP  
                                                  (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (or__introl))
                                                  ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                  )))))
                                         ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                            (MP  
                                             (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                             ) (MP  
                                                (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                 (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                  (or__intror))
                                                ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                )))))
                                       ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                          (MP  
                                           (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                           ) (MP  
                                              (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                               (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                (or__introl))
                                              ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                              )))))
                                     ) (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                        (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                         (MP  
                                          (ASSUME `((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false`
                                          ) (MP  
                                             (MP  
                                              (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                               (SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                (conj))
                                              ) (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                              )
                                             ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                             ))))))
                                   ) (MP  
                                      (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false)` 
                                       (ASSUME `((neq (B : mat_Point)) (C : mat_Point)) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false)`
                                       )
                                      ) (ASSUME `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false`
                                      )))
                                 ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                    (MP  
                                     (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                     ) (MP  
                                        (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                         (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                          (or__intror))
                                        ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                        )))))
                               ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                   ) (MP  
                                      (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                       (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                        (or__introl))
                                      ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                      )))))
                             ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                 (MP  
                                  (ASSUME `((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false`
                                  ) (MP  
                                     (MP  
                                      (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                       (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                        (conj))
                                      ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                      )
                                     ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                     ))))))
                           ) (MP  
                              (CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false)` 
                               (ASSUME `((neq (A : mat_Point)) (C : mat_Point)) ==> (((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false)`
                               )
                              ) (ASSUME `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false`
                              )))
                         ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                            (MP  
                             (ASSUME `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false`
                             ) (MP  
                                (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                 (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                  (or__intror))
                                ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                )))))
                       ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                          (MP  
                           (ASSUME `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false`
                           ) (MP  
                              (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                               (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                (or__introl))
                              ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                              )))))
                     ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                        (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                         (MP  
                          (ASSUME `((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false`
                          ) (MP  
                             (MP  
                              (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                               (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                (conj))
                              ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                              )
                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                             ))))))
                   ) (MP  
                      (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false)` 
                       (ASSUME `((neq (A : mat_Point)) (B : mat_Point)) ==> (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false)`
                       )
                      ) (ASSUME `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false`
                      )))
                 ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                    (MP  
                     (ASSUME `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false`
                     ) (MP  
                        (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                         (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                          (or__intror))
                        ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                        )))))
               ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                  (MP  
                   (ASSUME `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false`
                   ) (MP  
                      (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                       (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                        (or__introl))
                      ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)))))
             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                 (MP  
                  (ASSUME `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))) ==> mat_false`
                  ) (MP  
                     (MP  
                      (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                       (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (conj))
                      ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)
                     ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                     ))))))
           ) (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))` 
              (MP  
               (CONV_CONV_rule `((mat_or ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ==> mat_false` 
                (ASSUME `mat_not ((mat_or ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))`
                )
               ) (MP  
                  (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))` 
                   (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                    (or__intror))
                  ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))`
                  )))))
         ) (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
            (MP  
             (CONV_CONV_rule `((mat_or ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ==> mat_false` 
              (ASSUME `mat_not ((mat_or ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))`
              )
             ) (MP  
                (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))` 
                 (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                  (or__introl))
                ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                ))))))))))
 ;;

(*nCol__or__Col :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((mat_or (((nCol A) B) C)) (((col A) B) C))))`*)
let nCol__or__Col =

 CONV_CONV_rule `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((mat_or (((nCol (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point))) (((col (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)))))` 
 (GEN `(A : mat_Point)` 
  (GEN `(B : mat_Point)` 
   (GEN `(C : mat_Point)` 
    (MP  
     (CONV_CONV_rule `((mat_not ((mat_or ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))) ==> mat_false) ==> ((mat_or ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))` 
      (SPEC `(mat_or ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))` 
       (nNPP))
     ) (DISCH `mat_not ((mat_or ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))` 
        (MP  
         (DISCH `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))) ==> mat_false` 
          (MP  
           (DISCH `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
            (MP  
             (DISCH `((neq (A : mat_Point)) (B : mat_Point)) ==> (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false)` 
              (MP  
               (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                (MP  
                 (DISCH `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
                  (MP  
                   (DISCH `((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                    (MP  
                     (DISCH `((neq (A : mat_Point)) (C : mat_Point)) ==> (((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false)` 
                      (MP  
                       (DISCH `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                        (MP  
                         (DISCH `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                          (MP  
                           (DISCH `((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false` 
                            (MP  
                             (DISCH `((neq (B : mat_Point)) (C : mat_Point)) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false)` 
                              (MP  
                               (DISCH `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                (MP  
                                 (DISCH `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                                  (MP  
                                   (DISCH `((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false` 
                                    (MP  
                                     (DISCH `(mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false)` 
                                      (MP  
                                       (DISCH `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                        (MP  
                                         (DISCH `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                          (MP  
                                           (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                            (MP  
                                             (DISCH `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                              (MP  
                                               (DISCH `((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false` 
                                                (MP  
                                                 (DISCH `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false)` 
                                                  (MP  
                                                   (DISCH `(mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                    (MP  
                                                     (DISCH `mat_false` 
                                                      (MP  
                                                       (SPEC `mat_false` 
                                                        (false__ind)
                                                       ) (ASSUME `mat_false`)
                                                      )
                                                     ) (MP  
                                                        (CONV_CONV_rule `((((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                                         (ASSUME `(mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false`
                                                         )
                                                        ) (ASSUME `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false`
                                                        )))
                                                   ) (MP  
                                                      (CONV_CONV_rule `((((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false)` 
                                                       (ASSUME `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false)`
                                                       )
                                                      ) (ASSUME `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false`
                                                      )))
                                                 ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                    (DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                     (MP  
                                                      (ASSUME `((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false`
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                           (SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                            (conj))
                                                          ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                          )
                                                         ) (ASSUME `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                         ))))))
                                               ) (MP  
                                                  (CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false)` 
                                                   (ASSUME `(mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false)`
                                                   )
                                                  ) (ASSUME `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false`
                                                  )))
                                             ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                (MP  
                                                 (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                                 ) (MP  
                                                    (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                     (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                      (or__intror))
                                                    ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                    )))))
                                           ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (MP  
                                               (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                               ) (MP  
                                                  (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                   (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (or__introl))
                                                  ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                  )))))
                                         ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                            (MP  
                                             (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                             ) (MP  
                                                (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                 (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                  (or__intror))
                                                ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                )))))
                                       ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                          (MP  
                                           (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                           ) (MP  
                                              (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                               (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                (or__introl))
                                              ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                              )))))
                                     ) (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                        (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                         (MP  
                                          (ASSUME `((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false`
                                          ) (MP  
                                             (MP  
                                              (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                               (SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                                (conj))
                                              ) (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                              )
                                             ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                             ))))))
                                   ) (MP  
                                      (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false)` 
                                       (ASSUME `((neq (B : mat_Point)) (C : mat_Point)) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false)`
                                       )
                                      ) (ASSUME `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false`
                                      )))
                                 ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                    (MP  
                                     (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                     ) (MP  
                                        (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                         (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                          (or__intror))
                                        ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                        )))))
                               ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                  (MP  
                                   (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                   ) (MP  
                                      (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                       (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                        (or__introl))
                                      ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                      )))))
                             ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                                (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                 (MP  
                                  (ASSUME `((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false`
                                  ) (MP  
                                     (MP  
                                      (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                       (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                                        (conj))
                                      ) (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                      )
                                     ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                     ))))))
                           ) (MP  
                              (CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false)` 
                               (ASSUME `((neq (A : mat_Point)) (C : mat_Point)) ==> (((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false)`
                               )
                              ) (ASSUME `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false`
                              )))
                         ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                            (MP  
                             (ASSUME `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false`
                             ) (MP  
                                (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                 (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                  (or__intror))
                                ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                )))))
                       ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                          (MP  
                           (ASSUME `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false`
                           ) (MP  
                              (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                               (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                (or__introl))
                              ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                              )))))
                     ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                        (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                         (MP  
                          (ASSUME `((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false`
                          ) (MP  
                             (MP  
                              (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                               (SPEC `(neq (A : mat_Point)) (C : mat_Point)` 
                                (conj))
                              ) (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                              )
                             ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                             ))))))
                   ) (MP  
                      (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false)` 
                       (ASSUME `((neq (A : mat_Point)) (B : mat_Point)) ==> (((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false)`
                       )
                      ) (ASSUME `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false`
                      )))
                 ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                    (MP  
                     (ASSUME `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false`
                     ) (MP  
                        (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                         (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                          (or__intror))
                        ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                        )))))
               ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                  (MP  
                   (ASSUME `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false`
                   ) (MP  
                      (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                       (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                        (or__introl))
                      ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)))))
             ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
                (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                 (MP  
                  (ASSUME `((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))) ==> mat_false`
                  ) (MP  
                     (MP  
                      (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                       (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (conj))
                      ) (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`)
                     ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                     ))))))
           ) (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
              (MP  
               (CONV_CONV_rule `((mat_or ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ==> mat_false` 
                (ASSUME `mat_not ((mat_or ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))`
                )
               ) (MP  
                  (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                   (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))` 
                    (or__intror))
                  ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                  )))))
         ) (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))` 
            (MP  
             (CONV_CONV_rule `((mat_or ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ==> mat_false` 
              (ASSUME `mat_not ((mat_or ((mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))) ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))`
              )
             ) (MP  
                (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                 (SPEC `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))` 
                  (or__introl))
                ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))`
                ))))))))))
 ;;

(*eq__or__neq :  |- `! A : mat_Point. (! B : mat_Point. ((mat_or ((eq A) B)) ((neq A) B)))`*)
let eq__or__neq =

 CONV_CONV_rule `! A0 : mat_Point. (! B0 : mat_Point. ((mat_or ((eq (A0 : mat_Point)) (B0 : mat_Point))) ((neq (A0 : mat_Point)) (B0 : mat_Point))))` 
 (GEN `(A : mat_Point)` 
  (GEN `(B : mat_Point)` 
   (MP  
    (CONV_CONV_rule `((mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) (mat_not ((eq (A : mat_Point)) (B : mat_Point))))) ==> mat_false) ==> ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) (mat_not ((eq (A : mat_Point)) (B : mat_Point))))` 
     (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) (mat_not ((eq (A : mat_Point)) (B : mat_Point)))` 
      (nNPP))
    ) (DISCH `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) (mat_not ((eq (A : mat_Point)) (B : mat_Point))))` 
       (MP  
        (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
         (MP  
          (DISCH `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> mat_false` 
           (MP  
            (DISCH `mat_false` 
             (MP  (SPEC `mat_false` (false__ind)) (ASSUME `mat_false`))
            ) (MP  
               (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> mat_false` 
                (ASSUME `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> mat_false`
                )
               ) (ASSUME `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false`
               )))
          ) (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
             (MP  
              (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ==> mat_false` 
               (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) (mat_not ((eq (A : mat_Point)) (B : mat_Point))))`
               )
              ) (MP  
                 (SPEC `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                  (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__intror))
                 ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`))
             )))
        ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
           (MP  
            (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ==> mat_false` 
             (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) (mat_not ((eq (A : mat_Point)) (B : mat_Point))))`
             )
            ) (MP  
               (SPEC `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__introl))
               ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)))))))))
 ;;

(*neq__or__eq :  |- `! A : mat_Point. (! B : mat_Point. ((mat_or ((neq A) B)) ((eq A) B)))`*)
let neq__or__eq =

 CONV_CONV_rule `! A0 : mat_Point. (! B0 : mat_Point. ((mat_or ((neq (A0 : mat_Point)) (B0 : mat_Point))) ((eq (A0 : mat_Point)) (B0 : mat_Point))))` 
 (GEN `(A : mat_Point)` 
  (GEN `(B : mat_Point)` 
   (MP  
    (CONV_CONV_rule `((mat_not ((mat_or (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ((eq (A : mat_Point)) (B : mat_Point)))) ==> mat_false) ==> ((mat_or (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ((eq (A : mat_Point)) (B : mat_Point)))` 
     (SPEC `(mat_or (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ((eq (A : mat_Point)) (B : mat_Point))` 
      (nNPP))
    ) (DISCH `mat_not ((mat_or (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ((eq (A : mat_Point)) (B : mat_Point)))` 
       (MP  
        (DISCH `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> mat_false` 
         (MP  
          (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
           (MP  
            (DISCH `mat_false` 
             (MP  (SPEC `mat_false` (false__ind)) (ASSUME `mat_false`))
            ) (MP  
               (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> mat_false` 
                (ASSUME `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> mat_false`
                )
               ) (ASSUME `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false`
               )))
          ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
             (MP  
              (CONV_CONV_rule `((mat_or (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ((eq (A : mat_Point)) (B : mat_Point))) ==> mat_false` 
               (ASSUME `mat_not ((mat_or (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ((eq (A : mat_Point)) (B : mat_Point)))`
               )
              ) (MP  
                 (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                  (SPEC `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                   (or__intror))
                 ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)))))
        ) (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
           (MP  
            (CONV_CONV_rule `((mat_or (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ((eq (A : mat_Point)) (B : mat_Point))) ==> mat_false` 
             (ASSUME `mat_not ((mat_or (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ((eq (A : mat_Point)) (B : mat_Point)))`
             )
            ) (MP  
               (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                (SPEC `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                 (or__introl))
               ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`))))
       )))))
 ;;

(*col__nCol__False :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((nCol A) B) C) ==> ((((col A) B) C) ==> mat_false))))`*)
let col__nCol__False =

 CONV_CONV_rule `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((((nCol (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> ((((col (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> mat_false))))` 
 (GEN `(A : mat_Point)` 
  (GEN `(B : mat_Point)` 
   (GEN `(C : mat_Point)` 
    (DISCH `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))` 
     (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
      (MP  
       (MP  
        (SPEC `mat_false` 
         (SPEC `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
          (SPEC `(neq (A : mat_Point)) (B : mat_Point)` (and__ind)))
        ) (DISCH `(neq (A : mat_Point)) (B : mat_Point)` 
           (DISCH `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
            (MP  
             (MP  
              (SPEC `mat_false` 
               (SPEC `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                (SPEC `(neq (A : mat_Point)) (C : mat_Point)` (and__ind)))
              ) (DISCH `(neq (A : mat_Point)) (C : mat_Point)` 
                 (DISCH `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                  (MP  
                   (MP  
                    (SPEC `mat_false` 
                     (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                      (SPEC `(neq (B : mat_Point)) (C : mat_Point)` 
                       (and__ind)))
                    ) (DISCH `(neq (B : mat_Point)) (C : mat_Point)` 
                       (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                        (MP  
                         (MP  
                          (SPEC `mat_false` 
                           (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                            (SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                             (and__ind)))
                          ) (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                             (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                              (MP  
                               (MP  
                                (SPEC `mat_false` 
                                 (SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                  (SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                   (and__ind)))
                                ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                   (DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                    (MP  
                                     (MP  
                                      (MP  
                                       (SPEC `mat_false` 
                                        (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                         (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                          (or__ind)))
                                       ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                          (MP  
                                           (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                            (ASSUME `(neq (A : mat_Point)) (B : mat_Point)`
                                            )
                                           ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                           )))
                                      ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                         (MP  
                                          (MP  
                                           (MP  
                                            (SPEC `mat_false` 
                                             (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                              (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                               (or__ind)))
                                            ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                 (ASSUME `(neq (A : mat_Point)) (C : mat_Point)`
                                                 )
                                                ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                )))
                                           ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (MP  
                                                 (SPEC `mat_false` 
                                                  (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                   (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                    (or__ind)))
                                                 ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                    (MP  
                                                     (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                      (ASSUME `(neq (B : mat_Point)) (C : mat_Point)`
                                                      )
                                                     ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                     )))
                                                ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                   (MP  
                                                    (MP  
                                                     (MP  
                                                      (SPEC `mat_false` 
                                                       (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                        (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                         (or__ind)))
                                                      ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (DISCH `mat_false` 
                                                           (MP  
                                                            (SPEC `mat_false` 
                                                             (false__ind)
                                                            ) (ASSUME `mat_false`
                                                            ))
                                                          ) (MP  
                                                             (CONV_CONV_rule `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                              (ASSUME `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                              )
                                                             ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                             ))))
                                                     ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (SPEC `mat_false` 
                                                            (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (or__ind)))
                                                           ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                              (MP  
                                                               (DISCH `mat_false` 
                                                                (MP  
                                                                 (SPEC `mat_false` 
                                                                  (false__ind
                                                                  )
                                                                 ) (ASSUME `mat_false`
                                                                 ))
                                                               ) (MP  
                                                                  (CONV_CONV_rule `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                   (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                  ))))
                                                          ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                             (MP  
                                                              (DISCH `mat_false` 
                                                               (MP  
                                                                (SPEC `mat_false` 
                                                                 (false__ind)
                                                                ) (ASSUME `mat_false`
                                                                ))
                                                              ) (MP  
                                                                 (CONV_CONV_rule `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                  (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                  )
                                                                 ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                 ))))
                                                         ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                         )))
                                                    ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                    )))
                                               ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                               )))
                                          ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                          )))
                                     ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                     ))))
                               ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                               ))))
                         ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                         ))))
                   ) (ASSUME `(mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                   ))))
             ) (ASSUME `(mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
             ))))
       ) (ASSUME `(mat_and ((neq (A : mat_Point)) (B : mat_Point))) ((mat_and ((neq (A : mat_Point)) (C : mat_Point))) ((mat_and ((neq (B : mat_Point)) (C : mat_Point))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))`
       )))))))
 ;;

(*nCol__notCol :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((mat_not (((col A) B) C)) ==> (((nCol A) B) C))))`*)
let nCol__notCol =

 CONV_CONV_rule `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((mat_not (((col (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point))) ==> (((nCol (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)))))` 
 (GEN `(A : mat_Point)` 
  (GEN `(B : mat_Point)` 
   (GEN `(C : mat_Point)` 
    (DISCH `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
     (MP  
      (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
       (MP  
        (DISCH `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
         (MP  
          (DISCH `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
           (MP  
            (DISCH `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
             (MP  
              (DISCH `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
               (MP  
                (DISCH `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                 (MP  
                  (DISCH `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                   (MP  
                    (DISCH `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                     (MP  
                      (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                       (MP  
                        (DISCH `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                         (MP  
                          (MP  
                           (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> ((mat_and (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))))` 
                            (SPEC `(mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                             (SPEC `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                              (conj)))
                           ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                              (MP  
                               (DISCH `mat_false` 
                                (MP  
                                 (SPEC `mat_false` (false__ind)
                                 ) (ASSUME `mat_false`))
                               ) (MP  
                                  (ASSUME `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false`
                                  ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                  ))))
                          ) (MP  
                             (MP  
                              (CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> ((mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))))` 
                               (SPEC `(mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                (SPEC `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
                                 (conj)))
                              ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                 (MP  
                                  (DISCH `mat_false` 
                                   (MP  
                                    (SPEC `mat_false` (false__ind)
                                    ) (ASSUME `mat_false`))
                                  ) (MP  
                                     (ASSUME `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false`
                                     ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                     ))))
                             ) (MP  
                                (MP  
                                 (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))` 
                                  (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                   (SPEC `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                                    (conj)))
                                 ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                    (MP  
                                     (DISCH `mat_false` 
                                      (MP  
                                       (SPEC `mat_false` (false__ind)
                                       ) (ASSUME `mat_false`))
                                     ) (MP  
                                        (ASSUME `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false`
                                        ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                        ))))
                                ) (MP  
                                   (MP  
                                    (CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                                     (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                      (SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                       (conj)))
                                    ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (DISCH `mat_false` 
                                         (MP  
                                          (SPEC `mat_false` (false__ind)
                                          ) (ASSUME `mat_false`))
                                        ) (MP  
                                           (ASSUME `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false`
                                           ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                           ))))
                                   ) (MP  
                                      (CONV_CONV_rule `((((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                       (MP  
                                        (CONV_CONV_rule `((((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                                         (SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                          (SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                           (conj)))
                                        ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                           (MP  
                                            (DISCH `mat_false` 
                                             (MP  
                                              (SPEC `mat_false` (false__ind)
                                              ) (ASSUME `mat_false`))
                                            ) (MP  
                                               (ASSUME `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false`
                                               ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                               )))))
                                      ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                         (MP  
                                          (DISCH `mat_false` 
                                           (MP  
                                            (SPEC `mat_false` (false__ind)
                                            ) (ASSUME `mat_false`))
                                          ) (MP  
                                             (ASSUME `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false`
                                             ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                             )))))))))
                        ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                           (MP  
                            (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                            ) (MP  
                               (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (or__intror))
                               ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                               )))))
                      ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                          ) (MP  
                             (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                              (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (or__introl))
                             ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             )))))
                    ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                       (MP  
                        (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                        ) (MP  
                           (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                            (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                             (or__intror))
                           ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                           )))))
                  ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                     (MP  
                      (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                      ) (MP  
                         (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                          (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                           (or__introl))
                         ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                         )))))
                ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                   (MP  
                    (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                    ) (MP  
                       (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                        (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                         (or__intror))
                       ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                       )))))
              ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                 (MP  
                  (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                  ) (MP  
                     (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                      (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                       (or__introl))
                     ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`)))))
            ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
               (MP  
                (ASSUME `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false`
                ) (MP  
                   (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                    (SPEC `(eq (A : mat_Point)) (C : mat_Point)` (or__intror)
                    )
                   ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                   )))))
          ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
             (MP  
              (ASSUME `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false`
              ) (MP  
                 (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                  (SPEC `(eq (A : mat_Point)) (C : mat_Point)` (or__introl))
                 ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`)))))
        ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
           (MP  
            (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
             (ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
             )
            ) (MP  
               (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__intror))
               ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
               )))))
      ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
         (MP  
          (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
           (ASSUME `mat_not (((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
           )
          ) (MP  
             (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
              (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__introl))
             ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)))))))))
 ;;

(*not__nCol__Col :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((mat_not (((nCol A) B) C)) ==> (((col A) B) C))))`*)
let not__nCol__Col =

 CONV_CONV_rule `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((mat_not (((nCol (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point))) ==> (((col (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)))))` 
 (GEN `(A : mat_Point)` 
  (GEN `(B : mat_Point)` 
   (GEN `(C : mat_Point)` 
    (DISCH `mat_not (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
     (MP  
      (CONV_CONV_rule `((mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ==> mat_false) ==> ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))` 
       (SPEC `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
        (nNPP))
      ) (DISCH `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))` 
         (MP  
          (DISCH `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false)` 
           (MP  
            (DISCH `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
             (MP  
              (DISCH `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false` 
               (MP  
                (DISCH `((mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false` 
                 (MP  
                  (DISCH `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false)` 
                   (MP  
                    (DISCH `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                     (MP  
                      (DISCH `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false` 
                       (MP  
                        (DISCH `((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false` 
                         (MP  
                          (DISCH `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false)` 
                           (MP  
                            (DISCH `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                             (MP  
                              (DISCH `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false` 
                               (MP  
                                (DISCH `((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false` 
                                 (MP  
                                  (DISCH `(mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false)` 
                                   (MP  
                                    (DISCH `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                     (MP  
                                      (DISCH `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false` 
                                       (MP  
                                        (DISCH `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                         (MP  
                                          (DISCH `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                           (MP  
                                            (DISCH `((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false` 
                                             (MP  
                                              (DISCH `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false)` 
                                               (MP  
                                                (DISCH `(mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false` 
                                                 (MP  
                                                  (DISCH `mat_false` 
                                                   (MP  
                                                    (SPEC `mat_false` 
                                                     (false__ind)
                                                    ) (ASSUME `mat_false`))
                                                  ) (MP  
                                                     (CONV_CONV_rule `((((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> mat_false` 
                                                      (ASSUME `(mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false`
                                                      )
                                                     ) (ASSUME `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false`
                                                     )))
                                                ) (MP  
                                                   (CONV_CONV_rule `((((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false) ==> ((mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false)` 
                                                    (ASSUME `(mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> ((mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ==> mat_false)`
                                                    )
                                                   ) (ASSUME `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false`
                                                   )))
                                              ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                 (DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                  (MP  
                                                   (ASSUME `((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false`
                                                   ) (MP  
                                                      (MP  
                                                       (SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                                        (SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                         (conj))
                                                       ) (ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                       )
                                                      ) (ASSUME `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                      ))))))
                                            ) (MP  
                                               (CONV_CONV_rule `((((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false)` 
                                                (ASSUME `(mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))) ==> mat_false)`
                                                )
                                               ) (ASSUME `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false`
                                               )))
                                          ) (DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                             (MP  
                                              (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                              ) (MP  
                                                 (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                  (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (or__intror))
                                                 ) (ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                 )))))
                                        ) (DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                           (MP  
                                            (ASSUME `((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))) ==> mat_false`
                                            ) (MP  
                                               (SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                (SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                 (or__introl))
                                               ) (ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                               )))))
                                      ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                         (MP  
                                          (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                          ) (MP  
                                             (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                              (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                               (or__intror))
                                             ) (ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                             )))))
                                    ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                       (MP  
                                        (ASSUME `((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) ==> mat_false`
                                        ) (MP  
                                           (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                            (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                             (or__introl))
                                           ) (ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                           )))))
                                  ) (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                     (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                      (MP  
                                       (ASSUME `((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false`
                                       ) (MP  
                                          (MP  
                                           (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                            (SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                             (conj))
                                           ) (ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                           )
                                          ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                          ))))))
                                ) (MP  
                                   (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false)` 
                                    (ASSUME `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))) ==> mat_false)`
                                    )
                                   ) (ASSUME `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false`
                                   )))
                              ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                 (MP  
                                  (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                  ) (MP  
                                     (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                      (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                       (or__intror))
                                     ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                     )))))
                            ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (ASSUME `((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))) ==> mat_false`
                                ) (MP  
                                   (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                    (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                     (or__introl))
                                   ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                   )))))
                          ) (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                             (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                              (MP  
                               (ASSUME `((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false`
                               ) (MP  
                                  (MP  
                                   (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                                    (SPEC `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                                     (conj))
                                   ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                   )
                                  ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                                  ))))))
                        ) (MP  
                           (CONV_CONV_rule `(((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false)` 
                            (ASSUME `(mat_not ((eq (A : mat_Point)) (C : mat_Point))) ==> (((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))) ==> mat_false)`
                            )
                           ) (ASSUME `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false`
                           )))
                      ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                         (MP  
                          (ASSUME `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false`
                          ) (MP  
                             (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                              (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                               (or__intror))
                             ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                             )))))
                    ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                       (MP  
                        (ASSUME `((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))) ==> mat_false`
                        ) (MP  
                           (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                            (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                             (or__introl))
                           ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`))
                       )))
                  ) (DISCH `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
                     (DISCH `(mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                      (MP  
                       (ASSUME `((mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false`
                       ) (MP  
                          (MP  
                           (SPEC `(mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                            (SPEC `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
                             (conj))
                           ) (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                           )
                          ) (ASSUME `(mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                          ))))))
                ) (MP  
                   (CONV_CONV_rule `(((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false) ==> (((mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false)` 
                    (ASSUME `(mat_not ((eq (A : mat_Point)) (B : mat_Point))) ==> (((mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))) ==> mat_false)`
                    )
                   ) (ASSUME `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false`
                   )))
              ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                 (MP  
                  (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                   (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))`
                   )
                  ) (MP  
                     (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                      (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                       (or__intror))
                     ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                     )))))
            ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
               (MP  
                (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                 (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))`
                 )
                ) (MP  
                   (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                    (SPEC `(eq (A : mat_Point)) (B : mat_Point)` (or__introl)
                    )) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`)))))
          ) (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
             (DISCH `(mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
              (MP  
               (CONV_CONV_rule `((mat_and (mat_not ((eq (A : mat_Point)) (B : mat_Point)))) ((mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))))) ==> mat_false` 
                (ASSUME `mat_not (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                )
               ) (MP  
                  (MP  
                   (SPEC `(mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                    (SPEC `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
                     (conj))
                   ) (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                   )
                  ) (ASSUME `(mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                  ))))))))))))
 ;;

(*nCol__not__Col :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. ((((nCol A) B) C) ==> (mat_not (((col A) B) C)))))`*)
let nCol__not__Col =

 CONV_CONV_rule `! A0 : mat_Point. (! B0 : mat_Point. (! C0 : mat_Point. ((((nCol (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point)) ==> (mat_not (((col (A0 : mat_Point)) (B0 : mat_Point)) (C0 : mat_Point))))))` 
 (GEN `(A : mat_Point)` 
  (GEN `(B : mat_Point)` 
   (GEN `(C : mat_Point)` 
    (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
     (MP  
      (CONV_CONV_rule `((mat_not (mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))) ==> mat_false) ==> (mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))` 
       (SPEC `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))` 
        (nNPP))
      ) (DISCH `mat_not (mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))` 
         (MP  
          (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
           (MP  
            (SPEC `mat_false` 
             (SPEC `(mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
              (SPEC `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
               (and__ind)))
            ) (DISCH `mat_not ((eq (A : mat_Point)) (B : mat_Point))` 
               (DISCH `(mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))` 
                (MP  
                 (MP  
                  (SPEC `mat_false` 
                   (SPEC `(mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                    (SPEC `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
                     (and__ind)))
                  ) (DISCH `mat_not ((eq (A : mat_Point)) (C : mat_Point))` 
                     (DISCH `(mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))` 
                      (MP  
                       (MP  
                        (SPEC `mat_false` 
                         (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                          (SPEC `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                           (and__ind)))
                        ) (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                           (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))` 
                            (MP  
                             (MP  
                              (SPEC `mat_false` 
                               (SPEC `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                (SPEC `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                 (and__ind)))
                              ) (DISCH `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                 (DISCH `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (SPEC `mat_false` 
                                     (SPEC `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                      (SPEC `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                       (and__ind)))
                                    ) (DISCH `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                       (DISCH `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))` 
                                        (MP  
                                         (DISCH `mat_false` 
                                          (MP  
                                           (DISCH `mat_false` 
                                            (MP  
                                             (SPEC `mat_false` (false__ind)
                                             ) (ASSUME `mat_false`))
                                           ) (ASSUME `mat_false`))
                                         ) (MP  
                                            (CONV_CONV_rule `(((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false) ==> mat_false` 
                                             (DISCH `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))` 
                                              (MP  
                                               (CONV_CONV_rule `(mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))) ==> mat_false` 
                                                (ASSUME `mat_not (mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))))`
                                                )
                                               ) (ASSUME `mat_not ((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))))`
                                               )))
                                            ) (DISCH `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))` 
                                               (MP  
                                                (MP  
                                                 (MP  
                                                  (SPEC `mat_false` 
                                                   (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                    (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                                                     (or__ind)))
                                                  ) (DISCH `(eq (A : mat_Point)) (B : mat_Point)` 
                                                     (MP  
                                                      (DISCH `mat_false` 
                                                       (MP  
                                                        (SPEC `mat_false` 
                                                         (false__ind)
                                                        ) (ASSUME `mat_false`
                                                        ))
                                                      ) (MP  
                                                         (CONV_CONV_rule `((eq (A : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                          (ASSUME `mat_not ((eq (A : mat_Point)) (B : mat_Point))`
                                                          )
                                                         ) (ASSUME `(eq (A : mat_Point)) (B : mat_Point)`
                                                         ))))
                                                 ) (DISCH `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                                                    (MP  
                                                     (MP  
                                                      (MP  
                                                       (SPEC `mat_false` 
                                                        (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                         (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                                          (or__ind)))
                                                       ) (DISCH `(eq (A : mat_Point)) (C : mat_Point)` 
                                                          (MP  
                                                           (DISCH `mat_false` 
                                                            (MP  
                                                             (SPEC `mat_false` 
                                                              (false__ind)
                                                             ) (ASSUME `mat_false`
                                                             ))
                                                           ) (MP  
                                                              (CONV_CONV_rule `((eq (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                               (ASSUME `mat_not ((eq (A : mat_Point)) (C : mat_Point))`
                                                               )
                                                              ) (ASSUME `(eq (A : mat_Point)) (C : mat_Point)`
                                                              ))))
                                                      ) (DISCH `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (SPEC `mat_false` 
                                                             (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                              (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                                               (or__ind)))
                                                            ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                                                               (MP  
                                                                (DISCH `mat_false` 
                                                                 (MP  
                                                                  (SPEC `mat_false` 
                                                                   (false__ind
                                                                   )
                                                                  ) (
                                                                  ASSUME `mat_false`
                                                                  ))
                                                                ) (MP  
                                                                   (CONV_CONV_rule `((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                   ) (
                                                                   ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                                                   ))))
                                                           ) (DISCH `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                                              (MP  
                                                               (MP  
                                                                (MP  
                                                                 (SPEC `mat_false` 
                                                                  (SPEC `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                   (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (or__ind)
                                                                   ))
                                                                 ) (DISCH `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                ) (DISCH `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (or__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    DISCH `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `mat_false` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `mat_false` 
                                                                    (
                                                                    false__ind
                                                                    )
                                                                    ) (
                                                                    ASSUME `mat_false`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    CONV_CONV_rule `(((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) ==> mat_false` 
                                                                    (
                                                                    ASSUME `mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))`
                                                                    )))
                                                               ) (ASSUME `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))`
                                                               )))
                                                          ) (ASSUME `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))`
                                                          )))
                                                     ) (ASSUME `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))`
                                                     )))
                                                ) (ASSUME `(mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))`
                                                )))))))
                                   ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))`
                                   ))))
                             ) (ASSUME `(mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))`
                             ))))
                       ) (ASSUME `(mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point)))))`
                       ))))
                 ) (ASSUME `(mat_and (mat_not ((eq (A : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not ((eq (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point)))) ((mat_and (mat_not (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))) (mat_not (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))))))`
                 )))))
          ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
          ))))))))
 ;;


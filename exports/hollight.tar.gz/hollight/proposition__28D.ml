(*proposition__28D :  |- `! B : mat_Point. (! D : mat_Point. (! E : mat_Point. (! G : mat_Point. (! H : mat_Point. ((((betS E) G) H) ==> (((((((congA E) G) B) G) H) D) ==> (((((oS B) D) G) H) ==> ((((par G) B) H) D))))))))`*)
let proposition__28D =

 GEN `(B : mat_Point)` 
 (GEN `(D : mat_Point)` 
  (GEN `(E : mat_Point)` 
   (GEN `(G : mat_Point)` 
    (GEN `(H : mat_Point)` 
     (DISCH `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
      (DISCH `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
       (DISCH `(((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)` 
        (MP  
         (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
          (MP  
           (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
            (MP  
             (DISCH `(neq (H : mat_Point)) (D : mat_Point)` 
              (MP  
               (DISCH `(neq (D : mat_Point)) (H : mat_Point)` 
                (MP  
                 (DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                  (MP  
                   (DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
                    (MP  
                     (DISCH `ex (\ A : mat_Point. ((mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                      (MP  
                       (MP  
                        (SPEC `(((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (G : mat_Point)) (x : mat_Point))) ((((cong (G : mat_Point)) (x : mat_Point)) (G : mat_Point)) (B : mat_Point))) ==> (return : bool))) ==> ((ex (\ A : mat_Point. ((mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point))))) ==> (return : bool)))` 
                          (SPEC `\ A : mat_Point. ((mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(A : mat_Point)` 
                           (DISCH `(mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                            (MP  
                             (MP  
                              (SPEC `(((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                               (SPEC `(((cong (G : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                (SPEC `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                 (and__ind)))
                              ) (DISCH `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                 (DISCH `(((cong (G : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                  (MP  
                                   (DISCH `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                    (MP  
                                     (DISCH `ex (\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                      (MP  
                                       (MP  
                                        (SPEC `(((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                         (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (D : mat_Point)) (H : mat_Point)) (x : mat_Point))) ((((cong (H : mat_Point)) (x : mat_Point)) (H : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
                                          (SPEC `\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                           (PINST [(`:mat_Point`,`:A`)] [] 
                                            (ex__ind))))
                                        ) (GEN `(C : mat_Point)` 
                                           (DISCH `(mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                            (MP  
                                             (MP  
                                              (SPEC `(((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                               (SPEC `(((cong (H : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                (SPEC `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                 (and__ind)))
                                              ) (DISCH `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                 (DISCH `(((cong (H : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                  (MP  
                                                   (DISCH `((betS (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                    (MP  
                                                     (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                      (MP  
                                                       (CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (H : mat_Point))) ((mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (H : mat_Point)) (C : mat_Point))) ((mat_or (((betS (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point))))))) ==> ((((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                        (DISCH `((col (D : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                         (MP  
                                                          (DISCH `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                           (MP  
                                                            (DISCH `(neq (H : mat_Point)) (D : mat_Point)` 
                                                             (MP  
                                                              (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                               (MP  
                                                                (DISCH `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                 (MP  
                                                                  (CONV_CONV_rule `((mat_or ((eq (B : mat_Point)) (G : mat_Point))) ((mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (G : mat_Point)) (A : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point))))))) ==> ((((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                   (DISCH `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (H : mat_Point)) (D : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    DISCH `(((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `(((par (G : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(((par (H : mat_Point)) (D : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                    ) (
                                                                    ASSUME `(((par (H : mat_Point)) (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )
                                                                    ) (
                                                                    ASSUME `(neq (G : mat_Point)) (B : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_and (((col (G : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((col (A : mat_Point)) (B : mat_Point)) (G : mat_Point))) ((mat_and (((col (B : mat_Point)) (A : mat_Point)) (G : mat_Point))) (((col (A : mat_Point)) (G : mat_Point)) (B : mat_Point)))))`
                                                                    ))
                                                                    ) (
                                                                    MP  
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    lemma__collinearorder
                                                                    )))
                                                                    ) (
                                                                    ASSUME `((col (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                    )))))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or ((eq (B : mat_Point)) (A : mat_Point))) ((mat_or ((eq (G : mat_Point)) (A : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))))` 
                                                                   (SPEC `(eq (B : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or ((eq (G : mat_Point)) (A : mat_Point))) ((mat_or (((betS (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point))))` 
                                                                   (SPEC `(eq (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (G : mat_Point)) (B : mat_Point)) (A : mat_Point))) ((mat_or (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point)))` 
                                                                   (SPEC `(eq (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `(mat_or (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) (((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point))` 
                                                                   (SPEC `((betS (G : mat_Point)) (B : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                  ) (
                                                                  MP  
                                                                  (SPEC `((betS (B : mat_Point)) (A : mat_Point)) (G : mat_Point)` 
                                                                   (SPEC `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                  ) (
                                                                  ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                                                  )))))))
                                                                ) (MP  
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__parallelsymmetric
                                                                    ))))
                                                                   ) (
                                                                   ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                   )))
                                                              ) (MP  
                                                                 (MP  
                                                                  (MP  
                                                                   (SPEC `(D : mat_Point)` 
                                                                    (
                                                                    SPEC `(C : mat_Point)` 
                                                                    (
                                                                    SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(B : mat_Point)` 
                                                                    (
                                                                    SPEC `(A : mat_Point)` 
                                                                    (
                                                                    lemma__collinearparallel
                                                                    )))))
                                                                   ) (
                                                                   ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                                   )
                                                                  ) (
                                                                  ASSUME `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                  )
                                                                 ) (ASSUME `(neq (H : mat_Point)) (D : mat_Point)`
                                                                 )))
                                                            ) (MP  
                                                               (DISCH `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))))))` 
                                                                (MP  
                                                                 (MP  
                                                                  (SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                   (SPEC `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                  ) (
                                                                  DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                                                                  (DISCH `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))))` 
                                                                   (MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    SPEC `(neq (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `(neq (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(neq (D : mat_Point)) (G : mat_Point)` 
                                                                    (
                                                                    ASSUME `(neq (H : mat_Point)) (D : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))))`
                                                                    ))))
                                                                 ) (ASSUME `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))))))`
                                                                 ))
                                                               ) (MP  
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (SPEC `(H : mat_Point)` 
                                                                    (
                                                                    SPEC `(G : mat_Point)` 
                                                                    (
                                                                    lemma__NCdistinct
                                                                    )))
                                                                  ) (
                                                                  ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                  ))))
                                                          ) (MP  
                                                             (DISCH `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))))` 
                                                              (MP  
                                                               (MP  
                                                                (SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                 (SPEC `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                                                  (SPEC `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (and__ind)
                                                                  ))
                                                                ) (DISCH `((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                   (DISCH `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    SPEC `((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                                    (
                                                                    MP  
                                                                    (
                                                                    MP  
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    SPEC `((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    and__ind)
                                                                    ))
                                                                    ) (
                                                                    DISCH `((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    DISCH `((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                    (
                                                                    ASSUME `((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point)`
                                                                    )))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))`
                                                                    ))))
                                                                    ) (
                                                                    ASSUME `(mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point))))`
                                                                    ))))
                                                               ) (ASSUME `(mat_and (((col (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_and (((col (H : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((col (C : mat_Point)) (D : mat_Point)) (H : mat_Point))) ((mat_and (((col (D : mat_Point)) (C : mat_Point)) (H : mat_Point))) (((col (C : mat_Point)) (H : mat_Point)) (D : mat_Point)))))`
                                                               ))
                                                             ) (MP  
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(H : mat_Point)` 
                                                                  (SPEC `(D : mat_Point)` 
                                                                   (lemma__collinearorder
                                                                   )))
                                                                ) (ASSUME `((col (D : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                                )))))
                                                       ) (MP  
                                                          (SPEC `(mat_or ((eq (D : mat_Point)) (C : mat_Point))) ((mat_or ((eq (H : mat_Point)) (C : mat_Point))) ((mat_or (((betS (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point)))))` 
                                                           (SPEC `(eq (D : mat_Point)) (H : mat_Point)` 
                                                            (or__intror))
                                                          ) (MP  
                                                             (SPEC `(mat_or ((eq (H : mat_Point)) (C : mat_Point))) ((mat_or (((betS (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point))))` 
                                                              (SPEC `(eq (D : mat_Point)) (C : mat_Point)` 
                                                               (or__intror))
                                                             ) (MP  
                                                                (SPEC `(mat_or (((betS (H : mat_Point)) (D : mat_Point)) (C : mat_Point))) ((mat_or (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point)))` 
                                                                 (SPEC `(eq (H : mat_Point)) (C : mat_Point)` 
                                                                  (or__intror
                                                                  ))
                                                                ) (MP  
                                                                   (SPEC `(mat_or (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) (((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point))` 
                                                                    (
                                                                    SPEC `((betS (H : mat_Point)) (D : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__intror
                                                                    ))
                                                                   ) (
                                                                   MP  
                                                                   (SPEC `((betS (D : mat_Point)) (C : mat_Point)) (H : mat_Point)` 
                                                                    (
                                                                    SPEC `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)` 
                                                                    (
                                                                    or__introl
                                                                    ))
                                                                   ) (
                                                                   ASSUME `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                                   )))))))
                                                     ) (MP  
                                                        (MP  
                                                         (MP  
                                                          (MP  
                                                           (MP  
                                                            (SPEC `(H : mat_Point)` 
                                                             (SPEC `(G : mat_Point)` 
                                                              (SPEC `(E : mat_Point)` 
                                                               (SPEC `(D : mat_Point)` 
                                                                (SPEC `(C : mat_Point)` 
                                                                 (SPEC `(B : mat_Point)` 
                                                                  (SPEC `(A : mat_Point)` 
                                                                   (proposition__28A
                                                                   )))))))
                                                            ) (ASSUME `((betS (A : mat_Point)) (G : mat_Point)) (B : mat_Point)`
                                                            )
                                                           ) (ASSUME `((betS (C : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                           )
                                                          ) (ASSUME `((betS (E : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                          )
                                                         ) (ASSUME `(((((congA (E : mat_Point)) (G : mat_Point)) (B : mat_Point)) (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                         )
                                                        ) (ASSUME `(((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)`
                                                        )))
                                                   ) (MP  
                                                      (SPEC `(C : mat_Point)` 
                                                       (SPEC `(H : mat_Point)` 
                                                        (SPEC `(D : mat_Point)` 
                                                         (axiom__betweennesssymmetry
                                                         )))
                                                      ) (ASSUME `((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point)`
                                                      )))))
                                             ) (ASSUME `(mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                             ))))
                                       ) (ASSUME `ex (\ C : mat_Point. ((mat_and (((betS (D : mat_Point)) (H : mat_Point)) (C : mat_Point))) ((((cong (H : mat_Point)) (C : mat_Point)) (H : mat_Point)) (D : mat_Point))))`
                                       ))
                                     ) (MP  
                                        (MP  
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(H : mat_Point)` 
                                           (SPEC `(H : mat_Point)` 
                                            (SPEC `(D : mat_Point)` 
                                             (lemma__extension))))
                                         ) (ASSUME `(neq (D : mat_Point)) (H : mat_Point)`
                                         )
                                        ) (ASSUME `(neq (H : mat_Point)) (D : mat_Point)`
                                        )))
                                   ) (MP  
                                      (SPEC `(A : mat_Point)` 
                                       (SPEC `(G : mat_Point)` 
                                        (SPEC `(B : mat_Point)` 
                                         (axiom__betweennesssymmetry)))
                                      ) (ASSUME `((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point)`
                                      )))))
                             ) (ASSUME `(mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point))`
                             ))))
                       ) (ASSUME `ex (\ A : mat_Point. ((mat_and (((betS (B : mat_Point)) (G : mat_Point)) (A : mat_Point))) ((((cong (G : mat_Point)) (A : mat_Point)) (G : mat_Point)) (B : mat_Point))))`
                       ))
                     ) (MP  
                        (MP  
                         (SPEC `(B : mat_Point)` 
                          (SPEC `(G : mat_Point)` 
                           (SPEC `(G : mat_Point)` 
                            (SPEC `(B : mat_Point)` (lemma__extension))))
                         ) (ASSUME `(neq (B : mat_Point)) (G : mat_Point)`)
                        ) (ASSUME `(neq (G : mat_Point)) (B : mat_Point)`)))
                   ) (MP  
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(G : mat_Point)` (lemma__inequalitysymmetric))
                      ) (ASSUME `(neq (G : mat_Point)) (B : mat_Point)`)))
                 ) (MP  
                    (DISCH `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point))))))` 
                     (MP  
                      (MP  
                       (SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                        (SPEC `(mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point)))))` 
                         (SPEC `(neq (G : mat_Point)) (H : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                          (DISCH `(mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point)))))` 
                           (MP  
                            (MP  
                             (SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                              (SPEC `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point))))` 
                               (SPEC `(neq (H : mat_Point)) (B : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `(neq (H : mat_Point)) (B : mat_Point)` 
                                (DISCH `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point))))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                    (SPEC `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point)))` 
                                     (SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `(neq (G : mat_Point)) (B : mat_Point)` 
                                      (DISCH `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                          (SPEC `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point))` 
                                           (SPEC `(neq (H : mat_Point)) (G : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                            (DISCH `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(neq (G : mat_Point)) (B : mat_Point)` 
                                                (SPEC `(neq (B : mat_Point)) (G : mat_Point)` 
                                                 (SPEC `(neq (B : mat_Point)) (H : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(neq (B : mat_Point)) (H : mat_Point)` 
                                                  (DISCH `(neq (B : mat_Point)) (G : mat_Point)` 
                                                   (ASSUME `(neq (G : mat_Point)) (B : mat_Point)`
                                                   )))
                                              ) (ASSUME `(mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point)))`
                                        ))))
                                  ) (ASSUME `(mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point))))`
                                  ))))
                            ) (ASSUME `(mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point)))))`
                            ))))
                      ) (ASSUME `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (B : mat_Point))) ((mat_and ((neq (G : mat_Point)) (B : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (B : mat_Point)) (H : mat_Point))) ((neq (B : mat_Point)) (G : mat_Point))))))`
                      ))
                    ) (MP  
                       (SPEC `(B : mat_Point)` 
                        (SPEC `(H : mat_Point)` 
                         (SPEC `(G : mat_Point)` (lemma__NCdistinct)))
                       ) (ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                       ))))
               ) (MP  
                  (SPEC `(D : mat_Point)` 
                   (SPEC `(H : mat_Point)` (lemma__inequalitysymmetric))
                  ) (ASSUME `(neq (H : mat_Point)) (D : mat_Point)`)))
             ) (MP  
                (DISCH `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))))))` 
                 (MP  
                  (MP  
                   (SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                    (SPEC `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))))` 
                     (SPEC `(neq (G : mat_Point)) (H : mat_Point)` (and__ind)
                     ))
                   ) (DISCH `(neq (G : mat_Point)) (H : mat_Point)` 
                      (DISCH `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))))` 
                       (MP  
                        (MP  
                         (SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                          (SPEC `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))))` 
                           (SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `(neq (H : mat_Point)) (D : mat_Point)` 
                            (DISCH `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))))` 
                             (MP  
                              (MP  
                               (SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                (SPEC `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))` 
                                 (SPEC `(neq (G : mat_Point)) (D : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `(neq (G : mat_Point)) (D : mat_Point)` 
                                  (DISCH `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))` 
                                   (MP  
                                    (MP  
                                     (SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                      (SPEC `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))` 
                                       (SPEC `(neq (H : mat_Point)) (G : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `(neq (H : mat_Point)) (G : mat_Point)` 
                                        (DISCH `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))` 
                                         (MP  
                                          (MP  
                                           (SPEC `(neq (H : mat_Point)) (D : mat_Point)` 
                                            (SPEC `(neq (D : mat_Point)) (G : mat_Point)` 
                                             (SPEC `(neq (D : mat_Point)) (H : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `(neq (D : mat_Point)) (H : mat_Point)` 
                                              (DISCH `(neq (D : mat_Point)) (G : mat_Point)` 
                                               (ASSUME `(neq (H : mat_Point)) (D : mat_Point)`
                                               )))
                                          ) (ASSUME `(mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))`
                                          ))))
                                    ) (ASSUME `(mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))`
                                    ))))
                              ) (ASSUME `(mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))))`
                              ))))
                        ) (ASSUME `(mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point)))))`
                        ))))
                  ) (ASSUME `(mat_and ((neq (G : mat_Point)) (H : mat_Point))) ((mat_and ((neq (H : mat_Point)) (D : mat_Point))) ((mat_and ((neq (G : mat_Point)) (D : mat_Point))) ((mat_and ((neq (H : mat_Point)) (G : mat_Point))) ((mat_and ((neq (D : mat_Point)) (H : mat_Point))) ((neq (D : mat_Point)) (G : mat_Point))))))`
                  ))
                ) (MP  
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(H : mat_Point)` 
                     (SPEC `(G : mat_Point)` (lemma__NCdistinct)))
                   ) (ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                   ))))
           ) (MP  
              (CONV_CONV_rule `((((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
               (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))))` 
                (MP  
                 (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))))` 
                  (MP  
                   (MP  
                    (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                     (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))))) ==> (return : bool)))` 
                      (SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))))))))` 
                       (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                    ) (GEN `(x : mat_Point)` 
                       (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))` 
                        (MP  
                         (MP  
                          (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                           (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))) ==> (return : bool)))` 
                            (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))))))` 
                             (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                          ) (GEN `(x0 : mat_Point)` 
                             (DISCH `ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))` 
                              (MP  
                               (MP  
                                (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                 (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))) ==> (return : bool)))` 
                                  (SPEC `\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))))` 
                                   (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))
                                  ))
                                ) (GEN `(x1 : mat_Point)` 
                                   (DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))` 
                                    (MP  
                                     (MP  
                                      (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                       (SPEC `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))` 
                                        (SPEC `((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point)` 
                                         (and__ind)))
                                      ) (DISCH `((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point)` 
                                         (DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))` 
                                          (MP  
                                           (MP  
                                            (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                             (SPEC `(mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                              (SPEC `((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point)` 
                                               (and__ind)))
                                            ) (DISCH `((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point)` 
                                               (DISCH `(mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                                (MP  
                                                 (MP  
                                                  (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                   (SPEC `(mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                    (SPEC `((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                     (and__ind)))
                                                  ) (DISCH `((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                     (DISCH `(mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                      (MP  
                                                       (MP  
                                                        (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                         (SPEC `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                          (SPEC `((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                           (and__ind)))
                                                        ) (DISCH `((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                           (DISCH `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                            (MP  
                                                             (MP  
                                                              (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                               (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                 (and__ind)))
                                                              ) (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                                 (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                  (ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)`
                                                                  )))
                                                             ) (ASSUME `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                                             ))))
                                                       ) (ASSUME `(mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))`
                                                       ))))
                                                 ) (ASSUME `(mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))`
                                                 ))))
                                           ) (ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))`
                                           ))))
                                     ) (ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))`
                                     ))))
                               ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))`
                               ))))
                         ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))`
                         ))))
                   ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))))`
                   ))
                 ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))))`
                 )))
              ) (ASSUME `(((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)`
              )))
         ) (MP  
            (CONV_CONV_rule `((((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)) ==> (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))` 
             (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))))` 
              (MP  
               (DISCH `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))))` 
                (MP  
                 (MP  
                  (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                   (CONV_CONV_rule `! return : bool. ((! x : mat_Point. ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))) ==> (return : bool))) ==> ((ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))))) ==> (return : bool)))` 
                    (SPEC `\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))))))))` 
                     (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                  ) (GEN `(x : mat_Point)` 
                     (DISCH `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))` 
                      (MP  
                       (MP  
                        (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                         (CONV_CONV_rule `! return : bool. ((! x0 : mat_Point. ((ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))) ==> (return : bool))) ==> ((ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))) ==> (return : bool)))` 
                          (SPEC `\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))))))` 
                           (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                        ) (GEN `(x0 : mat_Point)` 
                           (DISCH `ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))` 
                            (MP  
                             (MP  
                              (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                               (CONV_CONV_rule `! return : bool. ((! x1 : mat_Point. (((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))) ==> (return : bool))) ==> ((ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))) ==> (return : bool)))` 
                                (SPEC `\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))))` 
                                 (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
                              ) (GEN `(x1 : mat_Point)` 
                                 (DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))` 
                                  (MP  
                                   (MP  
                                    (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                     (SPEC `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))` 
                                      (SPEC `((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point)` 
                                       (DISCH `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))` 
                                        (MP  
                                         (MP  
                                          (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                           (SPEC `(mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                            (SPEC `((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point)` 
                                             (DISCH `(mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))` 
                                              (MP  
                                               (MP  
                                                (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                 (SPEC `(mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                  (SPEC `((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                   (and__ind)))
                                                ) (DISCH `((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point)` 
                                                   (DISCH `(mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))` 
                                                    (MP  
                                                     (MP  
                                                      (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                       (SPEC `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                        (SPEC `((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                         (and__ind)))
                                                      ) (DISCH `((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point)` 
                                                         (DISCH `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))` 
                                                          (MP  
                                                           (MP  
                                                            (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                             (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                              (SPEC `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                               (and__ind)))
                                                            ) (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)` 
                                                               (DISCH `((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)` 
                                                                (ASSUME `((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point)`
                                                                )))
                                                           ) (ASSUME `(mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))`
                                                           ))))
                                                     ) (ASSUME `(mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))`
                                                     ))))
                                               ) (ASSUME `(mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))`
                                               ))))
                                         ) (ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point)))))`
                                         ))))
                                   ) (ASSUME `(mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x1 : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (x1 : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))`
                                   ))))
                             ) (ASSUME `ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (x0 : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (x0 : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))`
                             ))))
                       ) (ASSUME `ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (x : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (x : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))`
                       ))))
                 ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))))`
                 ))
               ) (ASSUME `ex (\ X : mat_Point. (ex (\ U : mat_Point. (ex (\ V : mat_Point. ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (U : mat_Point))) ((mat_and (((col (G : mat_Point)) (H : mat_Point)) (V : mat_Point))) ((mat_and (((betS (B : mat_Point)) (U : mat_Point)) (X : mat_Point))) ((mat_and (((betS (D : mat_Point)) (V : mat_Point)) (X : mat_Point))) ((mat_and (((nCol (G : mat_Point)) (H : mat_Point)) (B : mat_Point))) (((nCol (G : mat_Point)) (H : mat_Point)) (D : mat_Point))))))))))))`
               )))
            ) (ASSUME `(((oS (B : mat_Point)) (D : mat_Point)) (G : mat_Point)) (H : mat_Point)`
            ))))))))))
 ;;


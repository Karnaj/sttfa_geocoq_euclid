(*lemma__rectanglerotate :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (((((rE A) B) C) D) ==> ((((rE B) C) D) A)))))`*)
let lemma__rectanglerotate =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (DISCH `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
     (MP  
      (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
       (MP  
        (DISCH `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
         (MP  
          (MP  
           (SPEC `(((rE (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
            (CONV_CONV_rule `! return : bool. ((! x : mat_Point. (((mat_and (((betS (A : mat_Point)) (x : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) ==> (return : bool))) ==> ((ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))) ==> (return : bool)))` 
             (SPEC `\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))` 
              (PINST [(`:mat_Point`,`:A`)] [] (ex__ind))))
           ) (GEN `(M : mat_Point)` 
              (DISCH `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))` 
               (MP  
                (MP  
                 (SPEC `(((rE (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                  (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                   (SPEC `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                    (and__ind)))
                 ) (DISCH `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)` 
                    (DISCH `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                     (MP  
                      (MP  
                       (SPEC `(((rE (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                        (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                         (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (and__ind)))
                       ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                          (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                           (MP  
                            (MP  
                             (SPEC `(((rE (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                              (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                               (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (and__ind)))
                             ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                 (MP  
                                  (MP  
                                   (SPEC `(((rE (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                    (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                     (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (and__ind)))
                                   ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                      (DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((rE (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                          (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                           (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                            (DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                             (MP  
                                              (DISCH `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                               (MP  
                                                (CONV_CONV_rule `(ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (A : mat_Point))))) ==> ((((rE (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                 (DISCH `(((cR (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                  (MP  
                                                   (CONV_CONV_rule `((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cR (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))))) ==> ((((rE (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                    (DISCH `(((rE (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                     (ASSUME `(((rE (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                     ))
                                                   ) (MP  
                                                      (MP  
                                                       (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cR (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))))` 
                                                        (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                         (conj))
                                                       ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                       )
                                                      ) (MP  
                                                         (MP  
                                                          (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cR (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)))` 
                                                           (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                            (conj))
                                                          ) (ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                                          )
                                                         ) (MP  
                                                            (MP  
                                                             (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((((cR (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point))` 
                                                              (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                               (conj))
                                                             ) (ASSUME `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                             )
                                                            ) (MP  
                                                               (MP  
                                                                (SPEC `(((cR (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                                                                 (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                                                  (conj))
                                                                ) (ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                                                )
                                                               ) (ASSUME `(((cR (B : mat_Point)) (D : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                                                               )))))))
                                                ) (MP  
                                                   (SPEC `(M : mat_Point)` 
                                                    (CONV_CONV_rule `! x : mat_Point. (((mat_and (((betS (B : mat_Point)) (x : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (x : mat_Point)) (A : mat_Point))) ==> (ex (\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (A : mat_Point))))))` 
                                                     (SPEC `\ X : mat_Point. ((mat_and (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))) (((betS (C : mat_Point)) (X : mat_Point)) (A : mat_Point)))` 
                                                      (PINST [(`:mat_Point`,`:A`)] [] 
                                                       (ex__intro))))
                                                   ) (MP  
                                                      (MP  
                                                       (SPEC `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)` 
                                                        (SPEC `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)` 
                                                         (conj))
                                                       ) (ASSUME `((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)`
                                                       )
                                                      ) (ASSUME `((betS (C : mat_Point)) (M : mat_Point)) (A : mat_Point)`
                                                      ))))
                                              ) (MP  
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(M : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (axiom__betweennesssymmetry
                                                    )))
                                                 ) (ASSUME `((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point)`
                                                 )))))
                                        ) (ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                        ))))
                                  ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                                  ))))
                            ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                            ))))
                      ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
                      ))))
                ) (ASSUME `(mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))`
                ))))
          ) (ASSUME `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))`
          ))
        ) (MP  
           (CONV_CONV_rule `((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))) ==> (ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point)))))` 
            (MP  
             (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
              (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))` 
               (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                (and__ind)))
             ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))` 
                 (MP  
                  (MP  
                   (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                    (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))` 
                     (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (and__ind)))
                   ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                      (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))` 
                       (MP  
                        (MP  
                         (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                          (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                           (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (and__ind)))
                         ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                            (DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))` 
                             (MP  
                              (MP  
                               (SPEC `ex (\ M : mat_Point. ((mat_and (((betS (A : mat_Point)) (M : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (M : mat_Point)) (D : mat_Point))))` 
                                (SPEC `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                 (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                  (and__ind)))
                               ) (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                  (DISCH `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))` 
                                   (ASSUME `ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))`
                                   )))
                              ) (ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))`
                              ))))
                        ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point))))))`
                        ))))
                  ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) (ex (\ X : mat_Point. ((mat_and (((betS (A : mat_Point)) (X : mat_Point)) (C : mat_Point))) (((betS (B : mat_Point)) (X : mat_Point)) (D : mat_Point)))))))`
                  )))))
           ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
           )))
      ) (MP  
         (CONV_CONV_rule `((((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))))` 
          (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
           (MP  
            (DISCH `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
             (MP  
              (MP  
               (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                 (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                  (and__ind)))
               ) (DISCH `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                  (DISCH `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                   (MP  
                    (MP  
                     (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                      (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                       (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (and__ind)))
                     ) (DISCH `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                        (DISCH `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                         (MP  
                          (MP  
                           (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                            (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                             (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                              (and__ind)))
                           ) (DISCH `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                              (DISCH `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                               (MP  
                                (MP  
                                 (SPEC `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))` 
                                  (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                   (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                    (and__ind)))
                                 ) (DISCH `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                    (DISCH `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                     (MP  
                                      (MP  
                                       (SPEC `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
                                        (SPEC `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                                         (conj))
                                       ) (ASSUME `((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                                       )
                                      ) (MP  
                                         (MP  
                                          (SPEC `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                                           (SPEC `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (conj))
                                          ) (ASSUME `((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                          )
                                         ) (MP  
                                            (MP  
                                             (SPEC `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                                              (SPEC `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (conj))
                                             ) (ASSUME `((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                             )
                                            ) (MP  
                                               (MP  
                                                (SPEC `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                                 (SPEC `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                  (conj))
                                                ) (ASSUME `((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                )
                                               ) (ASSUME `(((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)`
                                               )))))))
                                ) (ASSUME `(mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                                ))))
                          ) (ASSUME `(mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                          ))))
                    ) (ASSUME `(mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
                    ))))
              ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
              ))
            ) (ASSUME `(mat_and (((per (D : mat_Point)) (A : mat_Point)) (B : mat_Point))) ((mat_and (((per (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((per (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((per (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((cR (A : mat_Point)) (C : mat_Point)) (B : mat_Point)) (D : mat_Point)))))`
            )))
         ) (ASSUME `(((rE (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
         )))))))
 ;;


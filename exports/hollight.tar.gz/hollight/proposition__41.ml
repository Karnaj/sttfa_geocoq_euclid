(*proposition__41 :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (((((pG A) B) C) D) ==> ((((col A) D) E) ==> ((((((eT A) B) C) E) B) C)))))))`*)
let proposition__41 =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (DISCH `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
      (DISCH `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
       (MP  
        (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
         (MP  
          (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
           (MP  
            (CONV_CONV_rule `(((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
             (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
              (MP  
               (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                (ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                )
               ) (MP  
                  (DISCH `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                   (MP  
                    (DISCH `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                     (MP  
                      (DISCH `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))` 
                       (MP  
                        (MP  
                         (MP  
                          (SPEC `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                           (SPEC `(neq (A : mat_Point)) (E : mat_Point)` 
                            (SPEC `(eq (A : mat_Point)) (E : mat_Point)` 
                             (or__ind)))
                          ) (DISCH `(eq (A : mat_Point)) (E : mat_Point)` 
                             (MP  
                              (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                 (ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                 )
                                ) (MP  
                                   (MP  
                                    (MP  
                                     (MP  
                                      (MP  
                                       (MP  
                                        (MP  
                                         (CONV_CONV_rule `((eq (A : mat_Point)) (E : mat_Point)) ==> (((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                          (SPEC `(A : mat_Point)` 
                                           (MP  
                                            (CONV_CONV_rule `(((((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (E : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)))))))) ==> (! x : mat_Point. (((eq (x : mat_Point)) (E : mat_Point)) ==> (((((pG (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (x : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((par (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((nCol (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((eT (x : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))))` 
                                             (SPEC `\ A0 : mat_Point. (((((pG (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((col (A0 : mat_Point)) (D : mat_Point)) (E : mat_Point)) ==> (((((par (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((nCol (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((triangle (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> (((((((eT (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> ((((((eT (A0 : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point))))))))` 
                                              (SPEC `(E : mat_Point)` 
                                               (PINST [(`:mat_Point`,`:A`)] [] 
                                                (eq__ind__r))))
                                            ) (DISCH `(((pG (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                               (DISCH `((col (E : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                                (DISCH `(((par (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                                 (DISCH `((nCol (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                  (DISCH `((triangle (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                   (DISCH `(((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                                    (ASSUME `(((((eT (E : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                    )))))))))
                                         ) (ASSUME `(eq (A : mat_Point)) (E : mat_Point)`
                                         )
                                        ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                        )
                                       ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                       )
                                      ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                      )
                                     ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                     )
                                    ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    )
                                   ) (ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                   )))
                              ) (MP  
                                 (SPEC `(C : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(A : mat_Point)` 
                                    (lemma__ETreflexive)))
                                 ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                 ))))
                         ) (DISCH `(neq (A : mat_Point)) (E : mat_Point)` 
                            (MP  
                             (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                              (MP  
                               (DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                (MP  
                                 (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                  (MP  
                                   (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                    (MP  
                                     (DISCH `(neq (E : mat_Point)) (A : mat_Point)` 
                                      (MP  
                                       (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                        (MP  
                                         (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                          (MP  
                                           (DISCH `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                            (MP  
                                             (DISCH `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                              (ASSUME `(((((eT (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                              )
                                             ) (MP  
                                                (SPEC `(E : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (SPEC `(A : mat_Point)` 
                                                    (proposition__37))))
                                                ) (ASSUME `(((par (A : mat_Point)) (E : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                                )))
                                           ) (MP  
                                              (SPEC `(E : mat_Point)` 
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(C : mat_Point)` 
                                                 (SPEC `(B : mat_Point)` 
                                                  (lemma__parallelsymmetric))
                                                ))
                                              ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                              )))
                                         ) (MP  
                                            (DISCH `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                (SPEC `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                 (SPEC `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                                  (DISCH `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))` 
                                                   (MP  
                                                    (MP  
                                                     (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                      (SPEC `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                       (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                        (and__ind)))
                                                     ) (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                        (DISCH `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                         (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                         )))
                                                    ) (ASSUME `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point))`
                                                    ))))
                                              ) (ASSUME `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (E : mat_Point)))`
                                              ))
                                            ) (MP  
                                               (SPEC `(A : mat_Point)` 
                                                (SPEC `(E : mat_Point)` 
                                                 (SPEC `(C : mat_Point)` 
                                                  (SPEC `(B : mat_Point)` 
                                                   (lemma__parallelflip))))
                                               ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (A : mat_Point)`
                                               ))))
                                       ) (MP  
                                          (MP  
                                           (MP  
                                            (SPEC `(A : mat_Point)` 
                                             (SPEC `(D : mat_Point)` 
                                              (SPEC `(E : mat_Point)` 
                                               (SPEC `(C : mat_Point)` 
                                                (SPEC `(B : mat_Point)` 
                                                 (lemma__collinearparallel)))
                                              ))
                                            ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                            )
                                           ) (ASSUME `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                           )
                                          ) (ASSUME `(neq (E : mat_Point)) (A : mat_Point)`
                                          )))
                                     ) (MP  
                                        (SPEC `(E : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (lemma__inequalitysymmetric))
                                        ) (ASSUME `(neq (A : mat_Point)) (E : mat_Point)`
                                        )))
                                   ) (MP  
                                      (DISCH `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                       (MP  
                                        (MP  
                                         (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                          (SPEC `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                           (SPEC `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                            (and__ind)))
                                         ) (DISCH `(((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                            (DISCH `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                             (MP  
                                              (MP  
                                               (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                (SPEC `(((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                 (SPEC `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                  (and__ind)))
                                               ) (DISCH `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                  (DISCH `(((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                   (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point)`
                                                   )))
                                              ) (ASSUME `(mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                              ))))
                                        ) (ASSUME `(mat_and ((((par (C : mat_Point)) (B : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and ((((par (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (A : mat_Point))) ((((par (C : mat_Point)) (B : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                        ))
                                      ) (MP  
                                         (SPEC `(D : mat_Point)` 
                                          (SPEC `(A : mat_Point)` 
                                           (SPEC `(C : mat_Point)` 
                                            (SPEC `(B : mat_Point)` 
                                             (lemma__parallelflip))))
                                         ) (ASSUME `(((par (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (D : mat_Point)`
                                         ))))
                                 ) (MP  
                                    (SPEC `(C : mat_Point)` 
                                     (SPEC `(B : mat_Point)` 
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (lemma__parallelsymmetric))))
                                    ) (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                    )))
                               ) (MP  
                                  (DISCH `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))` 
                                   (MP  
                                    (MP  
                                     (SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                      (SPEC `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                       (SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                        (and__ind)))
                                     ) (DISCH `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                        (DISCH `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))` 
                                         (MP  
                                          (MP  
                                           (SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                            (SPEC `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                             (SPEC `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                              (and__ind)))
                                           ) (DISCH `((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point)` 
                                              (DISCH `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))` 
                                               (MP  
                                                (MP  
                                                 (SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                  (SPEC `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                   (SPEC `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                    (and__ind)))
                                                 ) (DISCH `((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point)` 
                                                    (DISCH `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))` 
                                                     (MP  
                                                      (MP  
                                                       (SPEC `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)` 
                                                        (SPEC `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                         (SPEC `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                          (and__ind)))
                                                       ) (DISCH `((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                                          (DISCH `((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)` 
                                                           (ASSUME `((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point)`
                                                           )))
                                                      ) (ASSUME `(mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))`
                                                      ))))
                                                ) (ASSUME `(mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))`
                                                ))))
                                          ) (ASSUME `(mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point))))`
                                          ))))
                                    ) (ASSUME `(mat_and (((col (D : mat_Point)) (A : mat_Point)) (E : mat_Point))) ((mat_and (((col (D : mat_Point)) (E : mat_Point)) (A : mat_Point))) ((mat_and (((col (E : mat_Point)) (A : mat_Point)) (D : mat_Point))) ((mat_and (((col (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) (((col (E : mat_Point)) (D : mat_Point)) (A : mat_Point)))))`
                                    ))
                                  ) (MP  
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (lemma__collinearorder)))
                                     ) (ASSUME `((col (A : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                     ))))
                             ) (MP  
                                (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
                                 (MP  
                                  (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                   (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                    (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                     (and__ind)))
                                  ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                                     (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                                      (ASSUME `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                      ))))
                                ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                                ))))
                        ) (ASSUME `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                        ))
                      ) (ASSUME `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                      ))
                    ) (ASSUME `(mat_or ((eq (A : mat_Point)) (E : mat_Point))) ((neq (A : mat_Point)) (E : mat_Point))`
                    ))
                  ) (SPEC `(E : mat_Point)` 
                     (SPEC `(A : mat_Point)` (eq__or__neq))))))
            ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
            ))
          ) (MP  
             (DISCH `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))` 
              (MP  
               (MP  
                (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (SPEC `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                  (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (and__ind)))
                ) (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                   (DISCH `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))` 
                    (MP  
                     (MP  
                      (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                       (SPEC `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                        (SPEC `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                         (and__ind)))
                      ) (DISCH `((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                         (DISCH `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))` 
                          (MP  
                           (MP  
                            (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                             (SPEC `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                              (SPEC `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (and__ind)))
                            ) (DISCH `((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                               (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)` 
                                (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                )))
                           ) (ASSUME `(mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))`
                           ))))
                     ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point)))`
                     ))))
               ) (ASSUME `(mat_and (((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) ((mat_and (((nCol (A : mat_Point)) (C : mat_Point)) (D : mat_Point))) ((mat_and (((nCol (B : mat_Point)) (C : mat_Point)) (D : mat_Point))) (((nCol (A : mat_Point)) (B : mat_Point)) (D : mat_Point))))`
               ))
             ) (MP  
                (SPEC `(D : mat_Point)` 
                 (SPEC `(C : mat_Point)` 
                  (SPEC `(B : mat_Point)` 
                   (SPEC `(A : mat_Point)` (lemma__parallelNC))))
                ) (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                ))))
        ) (MP  
           (CONV_CONV_rule `((((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) ==> ((((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point))` 
            (MP  
             (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
              (SPEC `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
               (SPEC `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (and__ind)))
             ) (DISCH `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)` 
                (DISCH `(((par (A : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                 (ASSUME `(((par (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
                 ))))
           ) (ASSUME `(((pG (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)`
           )))))))))
 ;;


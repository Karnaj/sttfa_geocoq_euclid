(*proposition__26B :  |- `! A : mat_Point. (! B : mat_Point. (! C : mat_Point. (! D : mat_Point. (! E : mat_Point. (! F : mat_Point. ((((triangle A) B) C) ==> ((((triangle D) E) F) ==> (((((((congA A) B) C) D) E) F) ==> (((((((congA B) C) A) E) F) D) ==> (((((cong A) B) D) E) ==> ((mat_and ((((cong B) C) E) F)) ((mat_and ((((cong A) C) D) F)) ((((((congA B) A) C) E) D) F)))))))))))))`*)
let proposition__26B =

 GEN `(A : mat_Point)` 
 (GEN `(B : mat_Point)` 
  (GEN `(C : mat_Point)` 
   (GEN `(D : mat_Point)` 
    (GEN `(E : mat_Point)` 
     (GEN `(F : mat_Point)` 
      (DISCH `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
       (DISCH `((triangle (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
        (DISCH `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
         (DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
          (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
           (MP  
            (DISCH `mat_not ((((lt (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))` 
             (MP  
              (DISCH `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
               (MP  
                (DISCH `(((((congA (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)` 
                 (MP  
                  (DISCH `(((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)` 
                   (MP  
                    (DISCH `mat_not ((((lt (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                     (MP  
                      (CONV_CONV_rule `(((eq (B : mat_Point)) (C : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))))` 
                       (DISCH `mat_not ((eq (B : mat_Point)) (C : mat_Point))` 
                        (MP  
                         (CONV_CONV_rule `(((eq (E : mat_Point)) (F : mat_Point)) ==> mat_false) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))))` 
                          (DISCH `mat_not ((eq (E : mat_Point)) (F : mat_Point))` 
                           (MP  
                            (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                             (MP  
                              (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                               (MP  
                                (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)))` 
                                 (MP  
                                  (CONV_CONV_rule `((mat_not ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))))) ==> mat_false) ==> ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))))` 
                                   (SPEC `(mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)))` 
                                    (nNPP))
                                  ) (DISCH `mat_not ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))))` 
                                     (MP  
                                      (MP  
                                       (SPEC `mat_false` 
                                        (SPEC `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                         (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                          (and__ind)))
                                       ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                          (DISCH `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point))` 
                                           (MP  
                                            (MP  
                                             (SPEC `mat_false` 
                                              (SPEC `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                               (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                (and__ind)))
                                             ) (DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                (DISCH `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)` 
                                                 (MP  
                                                  (DISCH `((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ==> mat_false)` 
                                                   (MP  
                                                    (DISCH `((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ==> mat_false` 
                                                     (MP  
                                                      (DISCH `((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> mat_false)` 
                                                       (MP  
                                                        (DISCH `((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> mat_false` 
                                                         (MP  
                                                          (DISCH `mat_false` 
                                                           (MP  
                                                            (SPEC `mat_false` 
                                                             (false__ind)
                                                            ) (ASSUME `mat_false`
                                                            ))
                                                          ) (MP  
                                                             (ASSUME `((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> mat_false`
                                                             ) (ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                             )))
                                                        ) (MP  
                                                           (ASSUME `((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> (((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)) ==> mat_false)`
                                                           ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                           )))
                                                      ) (DISCH `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                         (DISCH `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                          (MP  
                                                           (ASSUME `((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ==> mat_false`
                                                           ) (MP  
                                                              (MP  
                                                               (SPEC `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                (SPEC `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)` 
                                                                 (conj))
                                                               ) (ASSUME `(((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                               )
                                                              ) (ASSUME `(((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)`
                                                              ))))))
                                                    ) (MP  
                                                       (ASSUME `((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> (((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ==> mat_false)`
                                                       ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                       )))
                                                  ) (DISCH `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                     (DISCH `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                      (MP  
                                                       (CONV_CONV_rule `((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point)))) ==> mat_false` 
                                                        (ASSUME `mat_not ((mat_and ((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))) ((mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))))`
                                                        )
                                                       ) (MP  
                                                          (MP  
                                                           (SPEC `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))` 
                                                            (SPEC `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                                             (conj))
                                                           ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                                           )
                                                          ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))`
                                                          ))))))))
                                            ) (ASSUME `(mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point))`
                                            ))))
                                      ) (ASSUME `(mat_and ((((cong (A : mat_Point)) (C : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_and ((((((congA (B : mat_Point)) (A : mat_Point)) (C : mat_Point)) (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)))`
                                      ))))
                                ) (MP  
                                   (MP  
                                    (MP  
                                     (SPEC `(F : mat_Point)` 
                                      (SPEC `(D : mat_Point)` 
                                       (SPEC `(E : mat_Point)` 
                                        (SPEC `(C : mat_Point)` 
                                         (SPEC `(A : mat_Point)` 
                                          (SPEC `(B : mat_Point)` 
                                           (proposition__04))))))
                                     ) (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                     )
                                    ) (ASSUME `(((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                    )
                                   ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                   )))
                              ) (MP  
                                 (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                     (SPEC `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                      (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                       (and__ind)))
                                    ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                       (DISCH `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point))` 
                                        (MP  
                                         (MP  
                                          (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                           (SPEC `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                            (SPEC `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                             (and__ind)))
                                          ) (DISCH `(((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point)` 
                                             (DISCH `(((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)` 
                                              (ASSUME `(((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point)`
                                              )))
                                         ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point))`
                                         ))))
                                   ) (ASSUME `(mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (E : mat_Point)) (D : mat_Point))) ((mat_and ((((cong (B : mat_Point)) (A : mat_Point)) (D : mat_Point)) (E : mat_Point))) ((((cong (A : mat_Point)) (B : mat_Point)) (E : mat_Point)) (D : mat_Point)))`
                                   ))
                                 ) (MP  
                                    (SPEC `(E : mat_Point)` 
                                     (SPEC `(D : mat_Point)` 
                                      (SPEC `(B : mat_Point)` 
                                       (SPEC `(A : mat_Point)` 
                                        (lemma__congruenceflip))))
                                    ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                                    ))))
                            ) (MP  
                               (CONV_CONV_rule `(mat_not ((eq (E : mat_Point)) (F : mat_Point))) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))` 
                                (MP  
                                 (CONV_CONV_rule `(mat_not ((eq (B : mat_Point)) (C : mat_Point))) ==> (((neq (E : mat_Point)) (F : mat_Point)) ==> ((((cong (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point)))` 
                                  (MP  
                                   (MP  
                                    (SPEC `(F : mat_Point)` 
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(C : mat_Point)` 
                                       (SPEC `(B : mat_Point)` 
                                        (lemma__trichotomy1))))
                                    ) (ASSUME `mat_not ((((lt (B : mat_Point)) (C : mat_Point)) (E : mat_Point)) (F : mat_Point))`
                                    )
                                   ) (ASSUME `mat_not ((((lt (E : mat_Point)) (F : mat_Point)) (B : mat_Point)) (C : mat_Point))`
                                   ))
                                 ) (ASSUME `mat_not ((eq (B : mat_Point)) (C : mat_Point))`
                                 ))
                               ) (ASSUME `mat_not ((eq (E : mat_Point)) (F : mat_Point))`
                               ))))
                         ) (DISCH `(eq (E : mat_Point)) (F : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `((mat_or ((eq (D : mat_Point)) (E : mat_Point))) ((mat_or ((eq (D : mat_Point)) (F : mat_Point))) ((mat_or ((eq (E : mat_Point)) (F : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((betS (D : mat_Point)) (F : mat_Point)) (E : mat_Point))))))) ==> mat_false` 
                              (DISCH `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                               (MP  
                                (CONV_CONV_rule `(((triangle (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) ==> mat_false` 
                                 (DISCH `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)` 
                                  (MP  
                                   (MP  
                                    (SPEC `(F : mat_Point)` 
                                     (SPEC `(E : mat_Point)` 
                                      (SPEC `(D : mat_Point)` 
                                       (col__nCol__False)))
                                    ) (ASSUME `((nCol (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                    )
                                   ) (ASSUME `((col (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                   )))
                                ) (ASSUME `((triangle (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                                )))
                             ) (MP  
                                (SPEC `(mat_or ((eq (D : mat_Point)) (F : mat_Point))) ((mat_or ((eq (E : mat_Point)) (F : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((betS (D : mat_Point)) (F : mat_Point)) (E : mat_Point)))))` 
                                 (SPEC `(eq (D : mat_Point)) (E : mat_Point)` 
                                  (or__intror))
                                ) (MP  
                                   (SPEC `(mat_or ((eq (E : mat_Point)) (F : mat_Point))) ((mat_or (((betS (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((betS (D : mat_Point)) (F : mat_Point)) (E : mat_Point))))` 
                                    (SPEC `(eq (D : mat_Point)) (F : mat_Point)` 
                                     (or__intror))
                                   ) (MP  
                                      (SPEC `(mat_or (((betS (E : mat_Point)) (D : mat_Point)) (F : mat_Point))) ((mat_or (((betS (D : mat_Point)) (E : mat_Point)) (F : mat_Point))) (((betS (D : mat_Point)) (F : mat_Point)) (E : mat_Point)))` 
                                       (SPEC `(eq (E : mat_Point)) (F : mat_Point)` 
                                        (or__introl))
                                      ) (ASSUME `(eq (E : mat_Point)) (F : mat_Point)`
                                      ))))))))
                      ) (DISCH `(eq (B : mat_Point)) (C : mat_Point)` 
                         (MP  
                          (CONV_CONV_rule `((mat_or ((eq (A : mat_Point)) (B : mat_Point))) ((mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))))) ==> mat_false` 
                           (DISCH `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                            (MP  
                             (CONV_CONV_rule `(((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) ==> mat_false` 
                              (DISCH `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)` 
                               (MP  
                                (MP  
                                 (SPEC `(C : mat_Point)` 
                                  (SPEC `(B : mat_Point)` 
                                   (SPEC `(A : mat_Point)` (col__nCol__False)
                                   ))
                                 ) (ASSUME `((nCol (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                 )
                                ) (ASSUME `((col (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                                )))
                             ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                             )))
                          ) (MP  
                             (SPEC `(mat_or ((eq (A : mat_Point)) (C : mat_Point))) ((mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))))` 
                              (SPEC `(eq (A : mat_Point)) (B : mat_Point)` 
                               (or__intror))
                             ) (MP  
                                (SPEC `(mat_or ((eq (B : mat_Point)) (C : mat_Point))) ((mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point))))` 
                                 (SPEC `(eq (A : mat_Point)) (C : mat_Point)` 
                                  (or__intror))
                                ) (MP  
                                   (SPEC `(mat_or (((betS (B : mat_Point)) (A : mat_Point)) (C : mat_Point))) ((mat_or (((betS (A : mat_Point)) (B : mat_Point)) (C : mat_Point))) (((betS (A : mat_Point)) (C : mat_Point)) (B : mat_Point)))` 
                                    (SPEC `(eq (B : mat_Point)) (C : mat_Point)` 
                                     (or__introl))
                                   ) (ASSUME `(eq (B : mat_Point)) (C : mat_Point)`
                                   )))))))
                    ) (MP  
                       (MP  
                        (MP  
                         (MP  
                          (SPEC `(C : mat_Point)` 
                           (SPEC `(B : mat_Point)` 
                            (SPEC `(A : mat_Point)` 
                             (SPEC `(F : mat_Point)` 
                              (SPEC `(E : mat_Point)` 
                               (SPEC `(D : mat_Point)` (lemma__26helper))))))
                          ) (ASSUME `((triangle (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                          )
                         ) (ASSUME `(((((congA (D : mat_Point)) (E : mat_Point)) (F : mat_Point)) (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                         )
                        ) (ASSUME `(((((congA (E : mat_Point)) (F : mat_Point)) (D : mat_Point)) (B : mat_Point)) (C : mat_Point)) (A : mat_Point)`
                        )
                       ) (ASSUME `(((cong (D : mat_Point)) (E : mat_Point)) (A : mat_Point)) (B : mat_Point)`
                       )))
                  ) (MP  
                     (SPEC `(E : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(A : mat_Point)` 
                        (SPEC `(D : mat_Point)` (lemma__congruencesymmetric))
                       ))
                     ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
                     )))
                ) (MP  
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(F : mat_Point)` 
                     (SPEC `(E : mat_Point)` 
                      (SPEC `(A : mat_Point)` 
                       (SPEC `(C : mat_Point)` 
                        (SPEC `(B : mat_Point)` (lemma__equalanglessymmetric)
                        )))))
                   ) (ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                   )))
              ) (MP  
                 (SPEC `(F : mat_Point)` 
                  (SPEC `(E : mat_Point)` 
                   (SPEC `(D : mat_Point)` 
                    (SPEC `(C : mat_Point)` 
                     (SPEC `(B : mat_Point)` 
                      (SPEC `(A : mat_Point)` (lemma__equalanglessymmetric)))
                    )))
                 ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                 )))
            ) (MP  
               (MP  
                (MP  
                 (MP  
                  (SPEC `(F : mat_Point)` 
                   (SPEC `(E : mat_Point)` 
                    (SPEC `(D : mat_Point)` 
                     (SPEC `(C : mat_Point)` 
                      (SPEC `(B : mat_Point)` 
                       (SPEC `(A : mat_Point)` (lemma__26helper))))))
                  ) (ASSUME `((triangle (A : mat_Point)) (B : mat_Point)) (C : mat_Point)`
                  )
                 ) (ASSUME `(((((congA (A : mat_Point)) (B : mat_Point)) (C : mat_Point)) (D : mat_Point)) (E : mat_Point)) (F : mat_Point)`
                 )
                ) (ASSUME `(((((congA (B : mat_Point)) (C : mat_Point)) (A : mat_Point)) (E : mat_Point)) (F : mat_Point)) (D : mat_Point)`
                )
               ) (ASSUME `(((cong (A : mat_Point)) (B : mat_Point)) (D : mat_Point)) (E : mat_Point)`
               )))))))))))))
 ;;

